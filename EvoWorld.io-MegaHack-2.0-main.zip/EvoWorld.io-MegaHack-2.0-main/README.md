# EvoWorld.io-MegaHack-2.2.0
This is a free & open-source hack
<h2>Attention! Your account may be banned! Play on your fear and risk!</h2>

<h1>How to install & use</h1>

- 1st step. Download <a href="https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en">tampermonkey</a>
- 2nd step. Enable developer mode in chrome extension manager.
- 3rd step. Download code as a zip archive.
- 4th step. Unzip code into any folder.
- 5th step. Open tampermonkey's control panel.
- 6th step. Move "main.js" file in tampermonkey control panel.
- 7th step. Click "Install/Reinstall/Update" button.
- 8th step. Open the game.
- 9th step. Tampermonkey will ask you: "A user script wants to access a third-party resource." press "allow for all time" (this is a safe action, because hack has open source code and you can check safety yourself).
- 10th step. Agree with ban risks.
- 11th step. Press tab or F9 in game.
- 12th step. Enjoy!

<h2>Support me of any amount:</h2>
<h3> UQC2t9bPwMTvB9RBfJV0QDdaIAXZpfFnW2zlTGn4dsJvymMs (TON Cryptocurrency)</h3>
<h3>https://www.donationalerts.com/r/ChyppitauZ (Fiat)</h3>

<p>Warning: CHROME ONLY!</p>
<p>Warning: PC ONLY!</p>
