# Facebook database leak

## Description

2019-08-01

In April 2021, <a href="https://www.bleepingcomputer.com/news/security/533-million-facebook-users-phone-numbers-leaked-on-hacker-forum/" target="_blank" rel="noopener">a large data set of over 500 million Facebook users was made freely available for download</a>. Encompassing approximately 20% of Facebook's subscribers, the data was allegedly obtained by exploiting a vulnerability Facebook advises they rectified in August 2019. The primary value of the data is the association of phone numbers to identities; whilst each record included phone, only 2.5 million contained an email address. Most records contained names and genders with many also including dates of birth, location, relationship status and employer.

## Breached data

Dates of birth, Email addresses, Employers, Genders, Geographic locations, Names, Phone numbers, Relationship statuses

## Free download Link

[Facebook breach Free Download Link](https://tinyurl.com/2b2k277t)