# Neteller database leak

## Description

2010-05-17

In May 2010, the e-wallet service known as Neteller <a href="http://www.forbes.com/sites/thomasbrewster/2015/11/30/paysafe-optimal-neteller-moneybookers-gambling-cyberattacks-data-breach/" target="_blank" rel="noopener">suffered a data breach which exposed over 3.6M customers</a>. The breach was not discovered until October 2015 and included names, email addresses, home addresses and account balances.

## Breached data

Account balances, Dates of birth, Email addresses, Genders, IP addresses, Names, Phone numbers, Physical addresses, Security questions and answers, Website activity

## Free download Link

[Neteller breach Free Download Link](https://tinyurl.com/2b2k277t)