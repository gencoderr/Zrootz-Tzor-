# DDO database leak

## Description

2013-04-02

In April 2013, the interactive video game <a href="https://www.ddo.com" target="_blank" rel="noopener">Dungeons &amp; Dragons Online</a> suffered a data breach that exposed almost 1.6M players' accounts. The data was being actively traded on underground forums and included email addresses, birth dates and password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[DDO breach Free Download Link](https://tinyurl.com/2b2k277t)