# BtoBet database leak

## Description

2019-12-26

In December 2019, <a href="https://www.troyhunt.com/the-difficulty-of-disclosure-surebet247-and-the-streisand-effect/" target="_blank" rel="noopener">a large collection of data from Nigerian gambling company Surebet247 was sent to HIBP</a>. Alongside the Surebet247, database backups from gambling sites BetAlfa, BetWay, BongoBongo and TopBet was also included. Further investigation <a href="https://www.iafrikan.com/2020/01/09/btobet-sports-betting-technology-software-neuron-platform-surebet247-gambling-data-security-breach/" target="_blank" rel="noopener">implicated betting platform provider BtoBet as being the common source of the data</a>. Impacted data included user records and extensive information on gambling histories.

## Breached data

Dates of birth, Email addresses, Financial transactions, Geographic locations, IP addresses, Names, Usernames

## Free download Link

[BtoBet breach Free Download Link](https://tinyurl.com/2b2k277t)