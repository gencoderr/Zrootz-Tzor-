# Dailymotion database leak

## Description

2016-10-20

In October 2016, the video sharing platform <a href="http://thehackernews.com/2016/12/dailymotion-video-hacked.html" target="_blank" rel="noopener">Dailymotion suffered a data breach</a>. The attack led to the exposure of more than 85 million user accounts and included email addresses, usernames and bcrypt hashes of passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Dailymotion breach Free Download Link](https://tinyurl.com/2b2k277t)