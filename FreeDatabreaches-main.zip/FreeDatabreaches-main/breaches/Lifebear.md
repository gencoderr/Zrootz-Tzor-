# Lifebear database leak

## Description

2019-02-28

In early 2019, the Japanese schedule app <a href="https://www.zdnet.com/article/round-4-hacker-returns-and-puts-26mil-user-records-for-sale-on-the-dark-web/" target="_blank" rel="noopener">Lifebear appeared for sale on a dark web marketplace amongst a raft of other hacked websites</a>. The breach exposed almost 3.7M unique email addresses, usernames and passwords stored as salted MD5 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;nano@databases.pw&quot;.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Lifebear breach Free Download Link](https://tinyurl.com/2b2k277t)