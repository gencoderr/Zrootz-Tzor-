# LyricsMania database leak

## Description

2017-12-21

In December 2017, the song lyrics website known as <a href="https://www.lyricsmania.com/" target="_blank" rel="noopener">Lyrics Mania</a> suffered a data breach. The data in the breach included 109k usernames, email addresses and plain text passwords. <a href="https://www.troyhunt.com/streamlining-data-breach-disclosure-a-step-by-step-process" target="_blank" rel="noopener">Numerous attempts were made to contact Lyrics Mania about the incident</a>, however no responses were received.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[LyricsMania breach Free Download Link](https://tinyurl.com/2b2k277t)