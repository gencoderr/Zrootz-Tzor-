# BrandNewTube database leak

## Description

2022-08-14

In August 2022, the streaming website <a href="https://unitynewsnetwork.co.uk/streaming-site-brand-new-tube-sees-massive-data-breach-with-ip-addresses-and-names-of-users-revealed/" target="_blank" rel="noopener">Brand New Tube suffered a data breach that exposed the personal information of almost 350k subscribers</a>. The impacted data included email and IP addresses, usernames, genders,  passwords stored as unsalted SHA-1 hashes and private messages.

## Breached data

Email addresses, Genders, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[BrandNewTube breach Free Download Link](https://tinyurl.com/2b2k277t)