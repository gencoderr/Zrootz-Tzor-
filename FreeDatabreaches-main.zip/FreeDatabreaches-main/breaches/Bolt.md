# Bolt database leak

## Description

2017-03-01

In approximately March 2017, the file sharing website <a href="http://bolt.cd/" target="_blank" rel="noopener">Bolt</a> suffered a data breach resulting in the exposure of 995k unique user records. The data was sourced from their vBulletin forum and contained email and IP addresses, usernames and salted MD5 password hashes. The site was previously reported as compromised on the <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a> breached database directory.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Bolt breach Free Download Link](https://tinyurl.com/2b2k277t)