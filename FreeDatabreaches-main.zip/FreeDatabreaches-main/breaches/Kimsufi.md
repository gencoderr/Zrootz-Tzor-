# Kimsufi database leak

## Description

2015-05-01

In mid-2015, the forum for the providers of affordable dedicated servers known as <a href="https://www.kimsufi.com" target="_blank" rel="noopener">Kimsufi</a> suffered a data breach. The vBulletin forum contained over half a million accounts including usernames, email and IP addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Kimsufi breach Free Download Link](https://tinyurl.com/2b2k277t)