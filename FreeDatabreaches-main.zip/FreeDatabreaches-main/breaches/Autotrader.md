# Autotrader database leak

## Description

2023-01-06

In January 2023, <a href="https://thecyberexpress.com/data1-4-million-autotrader-user-exposed/" target="_blank" rel="noopener">1.4M records from the Autotrader online vehicle marketplace appeared on a popular hacking forum</a>. Autotrader stated that the &quot;data in question relates to aged listing data that was generally publicly available on our site at the time and open to automated collection methods&quot;. The data contained 20k unique email addresses alongside physical addresses and phone numbers of dealers and vehicle details including VIN numbers. The data was provided to HIBP by a source who requested it be attributed to &quot;IntelBroker&quot;.

## Breached data

Email addresses, Phone numbers, Physical addresses, Vehicle details, Vehicle identification numbers (VINs)

## Free download Link

[Autotrader breach Free Download Link](https://tinyurl.com/2b2k277t)