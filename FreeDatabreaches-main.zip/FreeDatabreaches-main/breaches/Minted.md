# Minted database leak

## Description

2020-05-06

In May 2020, the online marketplace for independent artists <a href="https://www.bleepingcomputer.com/news/security/minted-discloses-data-breach-after-5m-user-records-sold-online/" target="_blank" rel="noopener">Minted suffered a data breach</a> that exposed 4.4M unique customer records subsequently sold on a dark web marketplace. Exposed data also included names, physical addresses, phone numbers and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[Minted breach Free Download Link](https://tinyurl.com/2b2k277t)