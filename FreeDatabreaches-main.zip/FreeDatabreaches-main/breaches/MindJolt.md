# MindJolt database leak

## Description

2019-03-18

In March 2019, the online gaming website <a href="https://www.zdnet.com/article/a-hacker-has-dumped-nearly-one-billion-user-records-over-the-past-two-months/" target="_blank" rel="noopener">MindJolt suffered a data breach that exposed 28M unique email addresses</a>. Also impacted were names and dates of birth, but no passwords. The data was provided to HIBP by a source who requested it be attributed to &quot;JimScott.Sec@protonmail.com&quot;.

## Breached data

Dates of birth, Email addresses, Names

## Free download Link

[MindJolt breach Free Download Link](https://tinyurl.com/2b2k277t)