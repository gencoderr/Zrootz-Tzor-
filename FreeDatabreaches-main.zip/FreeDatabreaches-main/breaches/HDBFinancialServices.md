# HDBFinancialServices database leak

## Description

2023-02-22

In March 2023, the Indian non-bank lending unit <a href="https://economictimes.indiatimes.com/industry/banking/finance/banking/hdb-financial-services-flags-data-breach-at-service-provider/articleshow/98483482.cms" target="_blank" rel="noopener">HDB Financial Services suffered a data breach that disclosed over 70M customer records</a>. Containing 1.6M unique email addresses, the breach also disclosed names, dates of birth, phone numbers, genders, post codes and loan information belonging to the customers.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, Loan information, Names, Phone numbers

## Free download Link

[HDBFinancialServices breach Free Download Link](https://tinyurl.com/2b2k277t)