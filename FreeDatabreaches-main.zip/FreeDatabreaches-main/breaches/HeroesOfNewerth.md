# HeroesOfNewerth database leak

## Description

2012-12-17

In December 2012, the multiplayer online battle arena game known as <a href="http://www.heroesofnewerth.com/" target="_blank" rel="noopener">Heroes of Newerth</a> <a href="https://www.reddit.com/r/HeroesofNewerth/comments/14zj2p/i_am_the_guy_who_hacked_hon/" target="_blank" rel="noopener"> was hacked</a> and over 8 million accounts extracted from the system. The compromised data included usernames, email addresses and passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[HeroesOfNewerth breach Free Download Link](https://tinyurl.com/2b2k277t)