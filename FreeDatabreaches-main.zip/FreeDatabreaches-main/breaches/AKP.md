# AKP database leak

## Description

2016-07-19

In July 2016, a hacker known as Phineas Fisher <a href="https://motherboard.vice.com/en_us/article/yp3n55/phineas-fisher-turkish-government-hack" target="_blank" rel="noopener">hacked Turkey's ruling party (Justice and Development Party or &quot;AKP&quot;) and gained access to 300k emails</a>. The full contents of the emails were subsequently <a href="https://wikileaks.org/akp-emails/" target="_blank" rel="noopener">published by WikiLeaks and made searchable</a>. HIBP identified over 917k unique email address patterns in the data set, including message IDs and a number of other non-user addresses.

## Breached data

Email addresses, Email messages

## Free download Link

[AKP breach Free Download Link](https://tinyurl.com/2b2k277t)