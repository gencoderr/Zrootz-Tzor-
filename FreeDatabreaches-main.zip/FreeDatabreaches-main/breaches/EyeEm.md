# EyeEm database leak

## Description

2018-02-28

In February 2018, <a href="https://www.theregister.co.uk/2019/02/11/620_million_hacked_accounts_dark_web/" target="_blank" rel="noopener">photography website EyeEm suffered a data breach</a>. The breach was identified among a collection of other large incidents and exposed almost 20M unique email addresses, names, usernames, bios and password hashes. The data was provided to HIBP by a source who asked for it to be attributed to &quot;Kuroi'sh or Gabriel Kimiaie-Asadi Bildstein&quot;.

## Breached data

Bios, Email addresses, Names, Passwords, Usernames

## Free download Link

[EyeEm breach Free Download Link](https://tinyurl.com/2b2k277t)