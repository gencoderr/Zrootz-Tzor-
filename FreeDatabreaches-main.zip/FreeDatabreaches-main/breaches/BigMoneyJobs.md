# BigMoneyJobs database leak

## Description

2014-04-03

In April 2014, the job site <a href="http://www.bigmoneyjobs.com">bigmoneyjobs.com</a> was <a href="https://twitter.com/ProbablyOnion2/status/451477310319779841" target="_blank" rel="noopener">hacked by an attacker known as &quot;ProbablyOnion&quot;</a>. The attack resulted in the <a href="http://news.softpedia.com/news/BigMoneyJobs-Hacked-Details-of-36-000-Users-Leaked-Online-436250.shtml?utm_source=twitterfeed&utm_medium=twitter&utm_campaign=information_security" target="_blank" rel="noopener">exposure of over 36,000 user accounts</a> including email addresses, usernames and passwords which were stored in plain text. The attack was allegedly mounted by exploiting a SQL injection vulnerability.

## Breached data

Career levels, Education levels, Email addresses, Names, Passwords, Phone numbers, Physical addresses, Salutations, User website URLs, Website activity

## Free download Link

[BigMoneyJobs breach Free Download Link](https://tinyurl.com/2b2k277t)