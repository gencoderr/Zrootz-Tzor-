# BannerBit database leak

## Description

2018-12-29

In approximately December 2018, the online ad platform <a href="https://bannerbit.com/" target="_blank" rel="noopener">BannerBit</a> suffered a data breach. Containing 213k unique email addresses and plain text passwords, the data was provided to HIBP by a third party. Multiple attempts were made to contact BannerBit, but no response was received.

## Breached data

Email addresses, Passwords

## Free download Link

[BannerBit breach Free Download Link](https://tinyurl.com/2b2k277t)