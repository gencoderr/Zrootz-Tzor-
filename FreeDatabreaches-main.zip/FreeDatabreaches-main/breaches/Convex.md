# Convex database leak

## Description

2023-02-01

In February 2023, the Russian telecommunications provider <a href="https://www.hackread.com/anonymous-data-leak-russia-isp-convex/" target="_blank" rel="noopener">Convex was hacked by &quot;Anonymous&quot; who subsequently released 128GB of data publicly</a>, alleging it revealed illegal government surveillance. The leaked data contained 150k unique email, IP and physical addresses, names and phone numbers.

## Breached data

Email addresses, IP addresses, Names, Phone numbers

## Free download Link

[Convex breach Free Download Link](https://tinyurl.com/2b2k277t)