# EuropaJobs database leak

## Description

2019-08-11

In August 2019, the now defunct European jobs website <a href="https://webcache.googleusercontent.com/search?q=cache:Qk_zaGEqx70J:https://en.europa.jobs/+&cd=1&hl=en&ct=clnk&gl=au" target="_blank" rel="noopener">europa.jobs</a> (Google cache link) suffered a data breach. The incident exposed 226k unique email addresses alongside extensive personal information including names, dates of birth, job applications and passwords. The data was subsequently redistributed on a popular hacking forum.

## Breached data

Dates of birth, Email addresses, Geographic locations, Job applications, Names, Passwords, Phone numbers, Spoken languages

## Free download Link

[EuropaJobs breach Free Download Link](https://tinyurl.com/2b2k277t)