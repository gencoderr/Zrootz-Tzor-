# Mappery database leak

## Description

2018-12-11

In December 2018, the mapping website <a href="http://www.mappery.com" target="_blank" rel="noopener">Mappery</a> suffered a data breach that exposed over 205k unique email addresses. The incident also exposed usernames, the geographic location of the user and passwords stored as unsalted SHA-1 hashes. No response was received from Mappery when contacted about the incident.

## Breached data

Email addresses, Geographic locations, Passwords, Usernames

## Free download Link

[Mappery breach Free Download Link](https://tinyurl.com/2b2k277t)