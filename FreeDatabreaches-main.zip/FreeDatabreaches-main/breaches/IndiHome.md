# IndiHome database leak

## Description

2019-11-01

In mid-2021, <a href="https://en.antaranews.com/news/245609/communication-ministry-studying-report-of-indihome-data-leak" target="_blank" rel="noopener">reports emerged of a data breach of Indonesia's telecommunications company, IndiHome</a>. Over 26M rows of data alleged to have been sourced from the company was posted to a popular hacking forum and contained 12.6M unique email addresses alongside names, IP addresses, genders and geographic locations. The most recent data was stamped as being recorded in November 2019.

## Breached data

Device information, Email addresses, Genders, Geographic locations, IP addresses, Names

## Free download Link

[IndiHome breach Free Download Link](https://tinyurl.com/2b2k277t)