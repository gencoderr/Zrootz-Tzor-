# Dymocks database leak

## Description

2023-06-20

In September 2023, the Australian book retailer <a href="https://www.abc.net.au/news/2023-09-08/dymocks-warns-customers-after-information-leaked-to-dark-web/102833430" target="_blank" rel="noopener">Dymocks announced a data breach</a>. The data dated back to June 2023 and contained 1.2M records with 836k unique email addresses. The breach also exposed names, dates of birth, genders, phone numbers and physical addresses.

## Breached data

Dates of birth, Email addresses, Genders, Names, Phone numbers, Physical addresses

## Free download Link

[Dymocks breach Free Download Link](https://tinyurl.com/2b2k277t)