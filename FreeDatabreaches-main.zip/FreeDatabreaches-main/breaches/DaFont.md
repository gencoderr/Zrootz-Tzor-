# DaFont database leak

## Description

2017-05-16

In May 2017, <a href="http://www.zdnet.com/article/font-sharing-site-dafont-hacked-thousands-of-accounts-stolen/" target="_blank" rel="noopener">font sharing site DaFont suffered a data breach</a> resulting in the exposure of 637k records. Allegedly due to a SQL injection vulnerability exploited by multiple parties, the exposed data included usernames, email addresses and passwords stored as MD5 without a salt.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[DaFont breach Free Download Link](https://tinyurl.com/2b2k277t)