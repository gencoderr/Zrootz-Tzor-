# Evony database leak

## Description

2016-06-01

In June 2016, the online multiplayer game <a href="http://securityaffairs.co/wordpress/52260/data-breach/evony-data-breach.html" target="_blank" rel="noopener">Evony was hacked</a> and over 29 million unique accounts were exposed. The attack led to the exposure of usernames, email and IP addresses and MD5 hashes of passwords (without salt).

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Evony breach Free Download Link](https://tinyurl.com/2b2k277t)