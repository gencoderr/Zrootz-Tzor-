# CrossFire database leak

## Description

2016-08-08

In August 2016, <a href="http://www.zdnet.com/article/over-25-million-accounts-stolen-after-mail-ru-forums-raided-by-hackers/" target="_blank" rel="noopener">the Russian gaming forum known as Cross Fire (or cfire.mail.ru) was hacked</a> along with a number of other forums on the Russian mail provider, mail.ru. The vBulletin forum contained 12.8 million accounts including usernames, email addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[CrossFire breach Free Download Link](https://tinyurl.com/2b2k277t)