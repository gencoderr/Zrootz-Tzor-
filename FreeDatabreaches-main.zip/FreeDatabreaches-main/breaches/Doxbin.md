# Doxbin database leak

## Description

2022-01-05

In January 2022, the &quot;doxing&quot; website designed to disclose the personal information of targeted individuals (&quot;doxes&quot;) <a href="https://www.flashpoint-intel.com/blog/doxbin-leak/" target="_blank" rel="noopener">Doxbin suffered a data breach</a>. The breach was subsequently leaked online and included over 370k unique email addresses across user accounts and doxes. User accounts also included usernames, password hashes and browser user agents. The personal information disclosed in the doxes was often extensive including names, physical addresses, phone numbers and more.

## Breached data

Browser user agent details, Email addresses, Passwords, Usernames

## Free download Link

[Doxbin breach Free Download Link](https://tinyurl.com/2b2k277t)