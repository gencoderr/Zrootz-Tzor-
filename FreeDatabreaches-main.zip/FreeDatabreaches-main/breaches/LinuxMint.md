# LinuxMint database leak

## Description

2016-02-21

In February 2016, the website for the Linux distro known as Linux Mint <a href="http://thehackernews.com/2016/02/linux-mint-hack.html" target="_blank" rel="noopener">was hacked and the ISO infected with a backdoor</a>. The site also ran a phpBB forum which was subsequently put up for sale complete with almost 145k email addresses, passwords and other personal subscriber information.

## Breached data

Avatars, Dates of birth, Email addresses, Geographic locations, IP addresses, Passwords, Time zones, Website activity

## Free download Link

[LinuxMint breach Free Download Link](https://tinyurl.com/2b2k277t)