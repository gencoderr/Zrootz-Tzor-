# Bitly database leak

## Description

2014-05-08

In May 2014, the link management company <a href="https://bitly.com/blog/urgent-security-update-regarding-your-bitly-account/" target="_blank" rel="noopener">Bitly announced they'd suffered a data breach</a>. The breach contained over 9.3 million unique email addresses, usernames and hashed passwords, most using SHA1 with a small number using bcrypt.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Bitly breach Free Download Link](https://tinyurl.com/2b2k277t)