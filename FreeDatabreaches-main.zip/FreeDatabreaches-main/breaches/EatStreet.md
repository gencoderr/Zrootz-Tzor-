# EatStreet database leak

## Description

2019-05-03

In May 2019, the online food ordering service <a href="https://www.zdnet.com/article/eatstreet-food-ordering-service-discloses-security-breach/" target="_blank" rel="noopener">EatStreet suffered a data breach affecting 6.4 million customers</a>. An extensive amount of personal data was obtained including names, phone numbers, addresses, partial credit card data and passwords stored as bcrypt hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;JimScott.Sec@protonmail.com&quot;.

## Breached data

Dates of birth, Email addresses, Genders, Names, Partial credit card data, Passwords, Phone numbers, Physical addresses, Social media profiles

## Free download Link

[EatStreet breach Free Download Link](https://tinyurl.com/2b2k277t)