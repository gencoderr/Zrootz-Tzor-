# Hemmakvall database leak

## Description

2015-07-08

In July 2015, the Swedish video store chain <a href="http://www.hemmakvall.se/" target="_blank" rel="noopener">Hemmakväll</a> <a href="http://www.dn.se/ekonomi/hemmakvall-hackat-50000-kunders-uppgifter-pa-vift/" target="_blank" rel="noopener">was hacked</a> and nearly 50k records dumped publicly. The disclosed data included various attributes of their customers including email and physical addresses, names and phone numbers. Passwords were also leaked, stored with a weak MD5 hashing algorithm.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[Hemmakvall breach Free Download Link](https://tinyurl.com/2b2k277t)