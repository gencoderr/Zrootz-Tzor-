# DatPiff database leak

## Description

2021-08-25

In late 2021, <a href="https://www.numerama.com/cyberguerre/784965-la-plateforme-de-rap-datpiff-piratee-les-mots-de-passe-dans-la-nature.html" target="_blank" rel="noopener">email address and plain text password pairs from the rap mixtape website DatPiff appeared for sale on a popular hacking forum</a>. The data allegedly dated back to an earlier breach and in total, contained almost 7.5M email addresses and cracked password pairs. The original data source allegedly contained usernames, security questions and answers and passwords stored as MD5 hashes with a static salt.

## Breached data

Email addresses, Passwords, Security questions and answers, Usernames

## Free download Link

[DatPiff breach Free Download Link](https://tinyurl.com/2b2k277t)