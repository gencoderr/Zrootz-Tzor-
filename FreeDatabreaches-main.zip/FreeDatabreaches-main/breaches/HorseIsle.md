# HorseIsle database leak

## Description

2020-09-19

In June 2020 then again in September that same year, <a href="https://hi1.horseisle.com/web/news.php" target="_blank" rel="noopener">Horse Isle &quot;The Secrent Land of Horses&quot; suffered a data breach</a>. The incident exposed 28k unique email addresses along with names, usernames, IP addresses, genders, purchases and plain text passwords. The system also stored and exposed failed password attempts for each user with the password retained in plain text.

## Breached data

Email addresses, Genders, IP addresses, Names, Passwords, Purchases, Usernames

## Free download Link

[HorseIsle breach Free Download Link](https://tinyurl.com/2b2k277t)