# AnimeLeague database leak

## Description

2024-07-04

In July 2024, <a href="https://www.animeleague.net/forum/viewtopic.php?f=55&t=134675" target="_blank" rel="noopener">AnimeLeague disclosed a data breach of their services</a>. The data was posted for sale on a popular hacking forum and included 2 databases covering both event registration records and a dump of the phpBB bulletin board. The impacted data included passwords in various hashed formats including SHA-1, salted md5 and bcrypt, as well as usernames, private messages, dates of birth, purchases and 192k unique email addresses.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Phone numbers, Private messages, Purchases, Usernames

## Free download Link

[AnimeLeague breach Free Download Link](https://tinyurl.com/2b2k277t)