# Bookchor database leak

## Description

2021-01-28

In January 2021, the Indian book trading website <a href="https://www.opindia.com/2021/04/bookchor-data-breach-information-of-over-5-lakh-users-leaked-what-we-know-so-far/" target="_blank" rel="noopener">Bookchor suffered a data breach that exposed half a million customer records</a>. The exposed data included email and IP addresses, names, genders, dates of birth, phone numbers and passwords stored as unsalted MD5 hashes. The data was subsequently traded on a popular hacking forum.

## Breached data

Dates of birth, Email addresses, Genders, IP addresses, Names, Passwords, Phone numbers, Social media profiles

## Free download Link

[Bookchor breach Free Download Link](https://tinyurl.com/2b2k277t)