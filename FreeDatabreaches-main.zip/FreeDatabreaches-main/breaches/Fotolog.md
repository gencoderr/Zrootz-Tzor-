# Fotolog database leak

## Description

2018-12-01

In December 2018, the photo sharing social network <a href="https://www.theregister.com/2019/02/11/620_million_hacked_accounts_dark_web/" target="_blank" rel="noopener">Fotolog suffered a data breach</a> that exposed 16.7 million unique email addresses. The data also included usernames and unsalted SHA-256 password hashes. The site was dissolved the following year and repurposed as a news website based in Brcko, Bosnia and Herzegovina.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Fotolog breach Free Download Link](https://tinyurl.com/2b2k277t)