# FilmaiIn database leak

## Description

2020-01-01

In approximately 2019 or 2020, the Lithuanian movie streaming service <a href="http://filmai.in/" target="_blank" rel="noopener">Filmai.in</a> suffered a data breach exposing 645k email addresses, usernames and plain text passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[FilmaiIn breach Free Download Link](https://tinyurl.com/2b2k277t)