# Nival database leak

## Description

2016-02-29

In February 2016, the Russian gaming company <a href="http://nival.com" target="_blank" rel="noopener">Nival</a> was the target of an attack which was consequently <a href="https://www.reddit.com/r/pwned/comments/47u1bf/operation_wrath_of_anakin_evolved" target="_blank" rel="noopener">detailed on Reddit</a>. Allegedly protesting &quot;the foreign policy of Russia in regards to Ukraine&quot;, Nival was one of several Russian sites in the breach and impacted over 1.5M accounts including sensitive personal information.

## Breached data

Avatars, Dates of birth, Email addresses, Genders, Names, Spoken languages, Usernames, Website activity

## Free download Link

[Nival breach Free Download Link](https://tinyurl.com/2b2k277t)