# ClashOfKings database leak

## Description

2016-07-14

In July 2016, <a href="https://www.zdnet.com/article/hacker-steals-forums-of-clash-of-kings-mobile-game/" target="_blank" rel="noopener">the forum for the game &quot;Clash of Kings&quot; suffered a data breach</a> that impacted 1.6 million subscribers. The impacted data included usernames, IP and email addresses and passwords stored as MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[ClashOfKings breach Free Download Link](https://tinyurl.com/2b2k277t)