# GoGames database leak

## Description

2015-10-24

In approximately October 2015, the manga website <a href="http://gogames.me" target="_blank" rel="noopener">Go Games</a> suffered a data breach. The exposed data included 3.4M customer records including email and IP addresses, usernames and passwords stored as salted MD5 hashes. Go Games did not respond when contacted about the incident. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GoGames breach Free Download Link](https://tinyurl.com/2b2k277t)