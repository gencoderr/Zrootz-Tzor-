# MobiFriends database leak

## Description

2020-01-06

In January 2020, the Barcelona-based dating app <a href="https://www.zdnet.com/article/dating-app-mobifriends-silent-on-security-breach-impacting-3-6-million-users/" target="_blank" rel="noopener">MobiFriends suffered a data breach</a> that exposed 3.5 million unique email addresses. The data also included usernames, genders, dates of birth and MD5 password hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Dates of birth, Email addresses, Genders, Passwords, Usernames

## Free download Link

[MobiFriends breach Free Download Link](https://tinyurl.com/2b2k277t)