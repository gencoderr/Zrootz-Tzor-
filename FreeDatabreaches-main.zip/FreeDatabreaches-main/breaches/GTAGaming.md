# GTAGaming database leak

## Description

2016-08-01

In August 2016, the Grand Theft Auto forum <a href="https://motherboard.vice.com/read/grand-theft-auto-fan-site-hacked" target="_blank" rel="noopener">GTAGaming was hacked and nearly 200k user accounts were leaked</a>. The vBulletin based forum included usernames, email addresses and password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[GTAGaming breach Free Download Link](https://tinyurl.com/2b2k277t)