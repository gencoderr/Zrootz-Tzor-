# AdultFriendFinder database leak

## Description

2015-05-21

In May 2015, the adult hookup site <a href="http://www.bbc.com/news/business-32839196" target="_blank" rel="noopener">Adult FriendFinder was hacked</a> and nearly 4 million records dumped publicly. The data dump included extremely sensitive personal information about individuals and their relationship statuses and sexual preferences combined with personally identifiable information.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, IP addresses, Races, Relationship statuses, Sexual orientations, Spoken languages, Usernames

## Free download Link

[AdultFriendFinder breach Free Download Link](https://tinyurl.com/2b2k277t)