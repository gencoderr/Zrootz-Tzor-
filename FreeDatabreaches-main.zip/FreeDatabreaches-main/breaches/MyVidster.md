# MyVidster database leak

## Description

2015-08-15

In August 2015, the social video sharing and bookmarking site <a href="https://www.reddit.com/r/pwned/comments/3h4tud/myvidstercom_hacked_1_million_member_database/" target="_blank" rel="noopener">MyVidster was hacked</a> and nearly 20,000 accounts were dumped online. The dump included usernames, email addresses and hashed passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[MyVidster breach Free Download Link](https://tinyurl.com/2b2k277t)