# HongFire database leak

## Description

2015-03-01

In March 2015, the anime and manga forum <a href="http://www.hongfire.com" target="_blank" rel="noopener">HongFire</a> suffered a data breach. The hack of their vBulletin forum led to the exposure of 1 million accounts along with email and IP addresses, usernames, dates of birth and salted MD5 passwords.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[HongFire breach Free Download Link](https://tinyurl.com/2b2k277t)