# Aptoide database leak

## Description

2020-04-13

In April 2020, the independent Android app store <a href="https://blog.aptoide.com/aptoide-credentials-information/" target="_blank" rel="noopener">Aptoide suffered a data breach</a>. The incident resulted in the exposure of 20M customer records which were subsequently shared online via a popular hacking forum. Impacted data included email and IP addresses, names, IP addresses and passwords stored as SHA-1 hashes without a salt.

## Breached data

Browser user agent details, Email addresses, IP addresses, Names, Passwords

## Free download Link

[Aptoide breach Free Download Link](https://tinyurl.com/2b2k277t)