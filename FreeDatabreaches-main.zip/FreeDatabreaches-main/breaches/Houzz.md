# Houzz database leak

## Description

2018-05-23

In mid-2018, the housing design website <a href="https://help.houzz.com/s/article/security-update?language=en_US" target="_blank" rel="noopener">Houzz suffered a data breach</a>. The company learned of the incident later that year then disclosed it to impacted members in February 2019. Almost 49 million unique email addresses were in the breach alongside names, IP addresses, geographic locations and either salted hashes of passwords or links to social media profiles used to authenticate to the service. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Geographic locations, IP addresses, Names, Passwords, Social media profiles, Usernames

## Free download Link

[Houzz breach Free Download Link](https://tinyurl.com/2b2k277t)