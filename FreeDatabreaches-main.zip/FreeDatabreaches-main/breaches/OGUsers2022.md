# OGUsers2022 database leak

## Description

2022-07-13

In July 2022, the account hijacking and SIM swapping forum OGusers suffered a data breach, the fifth since December 2018. The breach contained usernames, email and IP addresses and passwords stored as argon2 hashes. A total of 529k unique email addresses appeared in the breach.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[OGUsers2022 breach Free Download Link](https://tinyurl.com/2b2k277t)