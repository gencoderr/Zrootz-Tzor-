# Experian2020 database leak

## Description

2020-08-19

In August 2020, <a href="https://www.iafrikan.com/2020/09/01/experian-data-breach-database-public-data-information-south-africa/" target="_blank" rel="noopener">Experian South Africa suffered a data breach</a> which exposed the personal information of tens of millions of individuals. Only 1.3M of the records contained email addresses, whilst most contained government issued identity numbers, names, addresses, occupations and employers, amongst other person information.

## Breached data

Email addresses, Employers, Government issued IDs, Names, Occupations, Phone numbers

## Free download Link

[Experian2020 breach Free Download Link](https://tinyurl.com/2b2k277t)