# Flipkart database leak

## Description

2022-09-02

In September 2022, <a href="https://izoologic.com/region/central-asia/a-new-alleged-flipkart-data-breach-was-discovered-on-the-dark-web/" target="_blank" rel="noopener">over 500k customer records alleged to have been sourced from the Indian e-commerce service Flipkart appeared on a popular hacking forum</a>. Flipkart subsequently reviewed the data and concluded there was minimal overlap with their subscriber base and was not sourced from their services. The data included email addresses, latitudes and longitudes, names and phone numbers.

## Breached data

Email addresses, Geographic locations, Names, Phone numbers

## Free download Link

[Flipkart breach Free Download Link](https://tinyurl.com/2b2k277t)