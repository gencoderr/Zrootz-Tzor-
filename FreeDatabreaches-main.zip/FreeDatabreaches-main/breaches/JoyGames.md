# JoyGames database leak

## Description

2019-12-14

In December 2019, the forum for the JoyGames website suffered a data breach that exposed 4.5M unique email addresses. The impacted data also included usernames, IP addresses and salted MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[JoyGames breach Free Download Link](https://tinyurl.com/2b2k277t)