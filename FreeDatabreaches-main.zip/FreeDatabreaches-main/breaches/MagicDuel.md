# MagicDuel database leak

## Description

2023-08-02

In August 2023, <a href="https://magicduel.com/page/Announcement/view/5952" target="_blank" rel="noopener">the MagicDuel Adventure website suffered a data breach that exposed 138k user records</a>. The data included player names, email and IP addresses and bcrypt password hashes.

## Breached data

Email addresses, IP addresses, Nicknames, Passwords

## Free download Link

[MagicDuel breach Free Download Link](https://tinyurl.com/2b2k277t)