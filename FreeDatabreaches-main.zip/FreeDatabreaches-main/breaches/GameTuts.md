# GameTuts database leak

## Description

2015-03-01

Likely in early 2015, the video game website GameTuts suffered a data breach and over 2 million user accounts were exposed. The site later <a href="https://twitter.com/TeamModio/status/756705841168916486" target="_blank" rel="noopener">shut down in July 2016</a> but was identified as having been hosted on a vBulletin forum. The exposed data included usernames, email and IP addresses and salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GameTuts breach Free Download Link](https://tinyurl.com/2b2k277t)