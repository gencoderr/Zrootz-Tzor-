# MarketMoveis database leak

## Description

2023-08-30

In August 2023, the Portuguese home decor company <a href="https://portaldaqueixa.com/brands/market-moveis/complaints/market-moveis-encomenda-atrasada-nao-respondem-emails-nem-chamadas-e-email-fraudulento-98633223" target="_blank" rel="noopener">Market Moveis suffered a data breach</a> that impacted 28k records. The exposed records were limited to names and email addresses.

## Breached data

Email addresses, Names

## Free download Link

[MarketMoveis breach Free Download Link](https://tinyurl.com/2b2k277t)