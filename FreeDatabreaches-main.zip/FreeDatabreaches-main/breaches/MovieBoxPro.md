# MovieBoxPro database leak

## Description

2024-04-15

In April 2024, over 6M records from the streaming service MovieBoxPro were scraped from a vulnerable API. Of questionable legality, the service <a href="https://twitter.com/troyhunt/status/1784701384266543128" target="_blank" rel="noopener">provided no contact information to disclose the incident</a>, although reportedly the vulnerability was rectified after being mass enumerated.

## Breached data

Email addresses, Usernames

## Free download Link

[MovieBoxPro breach Free Download Link](https://tinyurl.com/2b2k277t)