# LeakedReality database leak

## Description

2022-01-31

In January 2022, <a href="https://twitter.com/LeakedReality/status/1531953947216338945" target="_blank" rel="noopener">the now defunct uncensored video website Leaked Reality</a> suffered a data breach that exposed 115k unique email addresses. The data also included usernames, IP addresses and passwords stored as either MD5 or phpass hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[LeakedReality breach Free Download Link](https://tinyurl.com/2b2k277t)