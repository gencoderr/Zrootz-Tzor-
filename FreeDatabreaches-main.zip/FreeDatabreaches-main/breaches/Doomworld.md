# Doomworld database leak

## Description

2022-10-12

In October 2022, <a href="https://www.doomworld.com/announcement/4-doomworld-probably-got-hacked/" target="_blank" rel="noopener">the Doomworld fourm suffered a data breach</a> that exposed 34k member records. The data included email and IP addresses, usernames and bcrypt password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Doomworld breach Free Download Link](https://tinyurl.com/2b2k277t)