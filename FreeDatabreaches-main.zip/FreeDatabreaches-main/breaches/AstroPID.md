# AstroPID database leak

## Description

2013-12-19

In December 2013, the vBulletin forum for the social engineering site known as "AstroPID" was breached and <a href="https://www.sinister.ly/Thread-40-Compromised-databases" target="_blank" rel="noopener">leaked publicly</a>. The site provided tips on fraudulently obtaining goods and services, often by providing a legitimate "PID" or Product Information Description. The breach resulted in nearly 6k user accounts and over 220k private messages between forum members being exposed.

## Breached data

Email addresses, Instant messenger identities, IP addresses, Names, Passwords, Private messages, Usernames, Website activity

## Free download Link

[AstroPID breach Free Download Link](https://tinyurl.com/2b2k277t)