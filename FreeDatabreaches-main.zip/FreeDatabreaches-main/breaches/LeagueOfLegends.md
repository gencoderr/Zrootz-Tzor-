# LeagueOfLegends database leak

## Description

2012-06-11

In June 2012, the multiplayer online game <a href="https://www.cio.com/article/2395205/security0/european-league-of-legends-game-players-have-their-account-data-compromised.html" target="_blank" rel="noopener">League of Legends suffered a data breach</a>. At the time, the service had more than 32 million registered accounts and the breach affected various personal data attributes including &quot;encrypted&quot; passwords. In 2018, a 339k record subset of the data emerged with email addresses, usernames and plain text passwords, likely cracked from the original cryptographically protected ones.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[LeagueOfLegends breach Free Download Link](https://tinyurl.com/2b2k277t)