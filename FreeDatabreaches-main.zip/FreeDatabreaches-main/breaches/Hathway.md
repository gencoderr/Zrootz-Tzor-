# Hathway database leak

## Description

2023-12-17

In December 2023, <a href="https://restoreprivacy.com/hacker-allegedly-holds-data-of-41-million-hathway-customers/" target="_blank" rel="noopener">hundreds of gigabytes of data allegedly taken from Indian ISP and digital TV provider Hathway appeared on a popular hacking website</a>. The incident exposed extensive personal information including 4.7M unique email addresses along with names, physical and IP addresses, phone numbers, password hashes and support ticket logs.

## Breached data

Device information, Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses, Salutations, Support tickets

## Free download Link

[Hathway breach Free Download Link](https://tinyurl.com/2b2k277t)