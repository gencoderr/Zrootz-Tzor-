# JukinMedia database leak

## Description

2021-10-28

In October 2021, the &quot;global leader in user-generated entertainment&quot; <a href="https://www.databreaches.net/jukin-media-hacked-and-data-dumped-while-company-claims-a-password-reset-is-required-due-to-a-security-upgrade/" target="_blank" rel="noopener">Jukin Media suffered a data breach</a>. The breach exposed 13GB of code, configuration and data consisting of 314k unique email addresses along with names, phone numbers, IP addresses and bcrypt password hashes.

## Breached data

Email addresses, Employers, IP addresses, Names, Occupations, Passwords, Phone numbers

## Free download Link

[JukinMedia breach Free Download Link](https://tinyurl.com/2b2k277t)