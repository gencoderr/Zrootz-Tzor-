# Avito database leak

## Description

2022-11-18

In November 2022, the Moroccan e-commerce service <a href="https://ledesk.ma/2022/12/20/avito-sexplique-sur-le-data-breach-ayant-touche-27-millions-dutilisateurs-de-sa-plateforme/" target="_blank" rel="noopener">Avito suffered a data breach that exposed the personal information of 2.7M customers</a>. The data included name, email, phone, IP address and geographic location.

## Breached data

Email addresses, Geographic locations, IP addresses, Names, Phone numbers

## Free download Link

[Avito breach Free Download Link](https://tinyurl.com/2b2k277t)