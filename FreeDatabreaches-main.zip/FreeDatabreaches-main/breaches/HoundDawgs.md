# HoundDawgs database leak

## Description

2017-12-30

In December 2017, the Danish torrent tracker known as <a href="https://torrentfreak.com/popular-danish-torrent-tracker-shuts-down-after-hack-180102/" target="_blank" rel="noopener">HoundDawgs suffered a data breach</a>. More than 55GB of data was dumped publicly and whilst <a href="https://www.flashback.org/p62770812" target="_blank" rel="noopener">there was initially contention as to the severity of the incident</a>, the data did indeed contain more than 45k unique email addresses complete extensive logs of torrenting activity, IP addresses and SHA1 passwords.

## Breached data

Email addresses, IP addresses, Passwords, Website activity

## Free download Link

[HoundDawgs breach Free Download Link](https://tinyurl.com/2b2k277t)