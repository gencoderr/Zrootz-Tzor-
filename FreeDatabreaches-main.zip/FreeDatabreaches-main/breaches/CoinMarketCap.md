# CoinMarketCap database leak

## Description

2021-10-12

During October 2021, 3.1 million email addresses with accounts on the cryptocurrency market capitalisation website <a href="https://coinmarketcap.com/" target="_blank" rel="noopener">CoinMarketCap</a> were discovered being traded on hacking forums. Whilst the email addresses were found to correlate with CoinMarketCap accounts, it's unclear precisely how they were obtained. CoinMarketCap has provided the following statement on the data: &quot;CoinMarketCap has become aware that batches of data have shown up online purporting to be a list of user accounts. While the data lists we have seen are only email addresses (no passwords), we have found a correlation with our subscriber base. We have not found any evidence of a data leak from our own servers — we are actively investigating this issue and will update our subscribers as soon as we have any new information.&quot;

## Breached data

Email addresses

## Free download Link

[CoinMarketCap breach Free Download Link](https://tinyurl.com/2b2k277t)