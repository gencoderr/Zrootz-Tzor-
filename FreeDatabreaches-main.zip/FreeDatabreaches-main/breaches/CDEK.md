# CDEK database leak

## Description

2022-03-09

In early 2022, a collective known as <a href="https://www.bleepingcomputer.com/news/security/ukraine-recruits-it-army-to-hack-russian-entities-lists-31-targets/" target="_blank" rel="noopener">IT Army whose stated goal is to &quot;completely de-anonymise most Russian users by leaking hundreds of gigabytes of databases&quot;</a> published over 30GB of data allegedly sourced from Russian courier service CDEK. The data contained over 19M unique email addresses along with names and phone numbers. The authenticity of the breach could not be independently established and has been flagged as &quot;unverfieid&quot;.

## Breached data

Email addresses, Names, Phone numbers

## Free download Link

[CDEK breach Free Download Link](https://tinyurl.com/2b2k277t)