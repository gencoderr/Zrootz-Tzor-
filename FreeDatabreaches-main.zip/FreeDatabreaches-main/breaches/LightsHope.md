# LightsHope database leak

## Description

2018-06-25

In June 2018, the World of Warcraft service <a href="https://lightshope.org/news/forum-breach-summary-of-investigation-and-final-report" target="_blank" rel="noopener">Light's Hope suffered a data breach</a> which they subsequently self-submitted to HIBP. Over 30K unique users were impacted and their exposed data included email addresses, dates of birth, private messages and passwords stored as bcrypt hashes.

## Breached data

Dates of birth, Email addresses, Geographic locations, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[LightsHope breach Free Download Link](https://tinyurl.com/2b2k277t)