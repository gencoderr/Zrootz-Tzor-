# Dave database leak

## Description

2020-06-28

In June 2020, the digital banking app <a href="https://www.zdnet.com/article/tech-unicorn-dave-admits-to-security-breach-impacting-7-5-million-users/" target="_blank" rel="noopener">Dave suffered a data breach</a> which exposed 7.5 million rows of data and subsequently appeared for public download on a hacking forum. The breach exposed extensive personal information including almost 3 million unique email addresses alongside names, dates of birth, encrypted social security numbers and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, Names, Passwords, Phone numbers, Physical addresses, Social security numbers

## Free download Link

[Dave breach Free Download Link](https://tinyurl.com/2b2k277t)