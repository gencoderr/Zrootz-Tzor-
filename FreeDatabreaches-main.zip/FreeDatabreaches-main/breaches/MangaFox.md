# MangaFox database leak

## Description

2016-06-01

In approximately July 2016, the manga website known as <a href="http://mangafox.me" target="_blank" rel="noopener">mangafox.me</a> suffered a data breach. The vBulletin based forum exposed 1.3 million accounts including usernames, email and IP addresses, dates of birth and salted MD5 password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MangaFox breach Free Download Link](https://tinyurl.com/2b2k277t)