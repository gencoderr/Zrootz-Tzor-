# Avvo database leak

## Description

2019-12-17

In approximately December 2019, an alleged data breach of the lawyer directory service Avvo was published to an online hacking forum and used in an extortion scam (it's possible the exposure dates back earlier than that). The data contained 4.1M unique email addresses alongside SHA-1 hashes, most likely representing user passwords. <a href="https://troyhunt.com/breach-disclosure-blow-by-blow-heres-why-its-so-hard" target="_blank" rel="noopener">Multiple attempts at contacting Avvo over the course of a week were unsuccessful and the authenticity of the data was eventually verified with common Avvo and HIBP subscribers.</a>

## Breached data

Email addresses, Passwords

## Free download Link

[Avvo breach Free Download Link](https://tinyurl.com/2b2k277t)