# CraftRise database leak

## Description

2022-03-05

In May 2023, <a href="https://memoryhackers.org/konular/craftrise-verileri-sizdirilmis.270536/" target="_blank" rel="noopener">news broke of a data breach of the Turkish Minecraft server known as CraftRise</a>. The data of over 2.5M users was subsequently shared on a popular hacking forum and included email addresses, usernames, geographic locations and plain text passwords. The newest records indicate the data was obtained in March 2022.

## Breached data

Email addresses, Geographic locations, Passwords, Usernames

## Free download Link

[CraftRise breach Free Download Link](https://tinyurl.com/2b2k277t)