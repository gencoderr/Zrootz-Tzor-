# AnimalJam database leak

## Description

2020-10-12

In October 2020, the online game for kids <a href="https://www.animaljam.com/en/2020databreach" target="_blank" rel="noopener">Animal Jam suffered a data breach</a> which was subsequently shared through online hacking communities the following month. The data contained 46 million user accounts with over 7 million unique email addresses. Impacted data also included usernames, IP addresses and for some records, dates of birth (sometimes in partial form), physical addresses, parent names and passwords stored as PBKDF2 hashes.

## Breached data

Dates of birth, Email addresses, Genders, IP addresses, Names, Passwords, Physical addresses, Usernames

## Free download Link

[AnimalJam breach Free Download Link](https://tinyurl.com/2b2k277t)