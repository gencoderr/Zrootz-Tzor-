# MCBans database leak

## Description

2016-10-27

In October 2016, the Minecraft banning service known as <a href="https://www.mcbans.com/" target="_blank" rel="noopener">MCBans</a> suffered a data breach resulting in the exposure of 120k unique user records. The data contained email and IP addresses, usernames and password hashes of unknown format. The site was previously reported as compromised on the <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a> breached database directory.

## Breached data

Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[MCBans breach Free Download Link](https://tinyurl.com/2b2k277t)