# FaceUP database leak

## Description

2013-01-01

In 2013, the Danish social media site <a href="https://faceup.dk/" target="_blank" rel="noopener">FaceUP</a> suffered a data breach. The incident exposed 87k unique email addresses alongside genders, dates of birth, names, phone numbers and passwords stored as unsalted MD5 hashes. When notified of the incident, FaceUP advised they had identified a SQL injection vulnerability at the time and forced password resets on impacted customers.

## Breached data

Dates of birth, Email addresses, Genders, Names, Passwords, Phone numbers, Usernames

## Free download Link

[FaceUP breach Free Download Link](https://tinyurl.com/2b2k277t)