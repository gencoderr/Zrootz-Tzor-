# BTCAlpha database leak

## Description

2021-11-02

In November 2021, the crypto exchange platform <a href="https://www.techtarget.com/searchsecurity/news/252509877/Cryptocurrency-exchange-BTC-Alpha-confirms-ransomware-attack" target="_blank" rel="noopener">BTC-Alpha suffered a ransomware attack data breach</a> after which customer data was publicly dumped. The impacted data included 362k email and IP addresses, usernames and passwords stored as PBKDF2 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[BTCAlpha breach Free Download Link](https://tinyurl.com/2b2k277t)