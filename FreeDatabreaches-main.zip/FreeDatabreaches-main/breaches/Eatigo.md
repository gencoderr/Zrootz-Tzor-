# Eatigo database leak

## Description

2018-10-16

In October 2018, the restaurant reservation service <a href="https://www.channelnewsasia.com/singapore/eatigo-data-breach-personal-information-millions-account-1307916" target="_blank" rel="noopener">Eatigo suffered a data breach that exposed 2.8 million accounts</a>. The data included email addresses, names, phone numbers, social media profiles, genders and passwords stored as unsalted MD5 hashes.

## Breached data

Email addresses, Genders, Names, Passwords, Phone numbers, Social media profiles

## Free download Link

[Eatigo breach Free Download Link](https://tinyurl.com/2b2k277t)