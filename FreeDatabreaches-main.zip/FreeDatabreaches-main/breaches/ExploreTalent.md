# ExploreTalent database leak

## Description

2022-02-28

In July 2024, <a href="https://x.com/H4ckManac/status/1813528139881988225" target="_blank" rel="noopener">a data breach attributed to Explore Talent was publicly posted to a popular hacking forum</a>. Containing 5.7M rows with 5.4M unique email addresses, the incident has been described by various sources as occurring between early 2022 to 2023 and also contains names, phone numbers and physical addresses.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[ExploreTalent breach Free Download Link](https://tinyurl.com/2b2k277t)