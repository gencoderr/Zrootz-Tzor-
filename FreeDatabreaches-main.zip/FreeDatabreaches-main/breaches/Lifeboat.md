# Lifeboat database leak

## Description

2016-01-01

In January 2016, the Minecraft community known as Lifeboat <a href="https://motherboard.vice.com/read/another-day-another-hack-7-million-emails-and-hashed-passwords-for-minecraft" target="_blank" rel="noopener">was hacked and more than 7 million accounts leaked</a>. Lifeboat knew of the incident for three months before the breach was made public but elected not to advise customers. The leaked data included usernames, email addresses and passwords stored as straight MD5 hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Lifeboat breach Free Download Link](https://tinyurl.com/2b2k277t)