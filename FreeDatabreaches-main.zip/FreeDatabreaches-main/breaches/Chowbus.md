# Chowbus database leak

## Description

2020-10-05

In October 2020, the Asian food delivery app <a href="https://www.reddit.com/r/UIUC/comments/j5fcjp/chowbus_is_hacked_leaks_800000_entries_of/" target="_blank" rel="noopener">Chowbus suffered a data breach which led to over 800,000 records being emailed to customers</a>. The email contained a link to a CSV file with customer data including physical addresses, names, phone numbers and over 444,000 unique email addresses.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[Chowbus breach Free Download Link](https://tinyurl.com/2b2k277t)