# CERTPolandPhish database leak

## Description

2023-02-25

In August 2023, <a href="https://www.troyhunt.com/68k-polish-phishing-victims-are-now-searchable-in-have-i-been-pwned-courtesy-of-cert-poland" target="_blank" rel="noopener">CERT Poland observed a phishing campaign that collected credentials from 68k victims</a>. The campaign collected email addresses and passwords via a phishing email masquerading as a purchase order confirmation. CERT Poland identified a further 202 other phishing campaigns operating on the same C2 server, which has now been dismantled.

## Breached data

Email addresses, Passwords

## Free download Link

[CERTPolandPhish breach Free Download Link](https://tinyurl.com/2b2k277t)