# NaughtyAmerica database leak

## Description

2016-03-14

In March 2016, the adult website <a href="http://www.forbes.com/sites/thomasbrewster/2016/04/14/naughty-america-fappening-hacked-porn-sites/" target="_blank" rel="noopener">Naughty America was hacked and the data consequently sold online</a>. The breach included data from numerous systems with various personal identity attributes, the largest of which had passwords stored as easily crackable MD5 hashes. There were 1.4 million unique email addresses in the breach.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[NaughtyAmerica breach Free Download Link](https://tinyurl.com/2b2k277t)