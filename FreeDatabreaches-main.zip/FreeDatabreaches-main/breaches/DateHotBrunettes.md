# DateHotBrunettes database leak

## Description

2021-01-12

In January 2021, the now defunct website Date Hot Brunettes which provided a service to &quot;Date Neglected Women Who Can Keep a Secret&quot;, suffered a data breach. The incident exposed 1.5M unique email addresses along with IP addresses, usernames, user-entered bios and MD5 password hashes.

## Breached data

Bios, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[DateHotBrunettes breach Free Download Link](https://tinyurl.com/2b2k277t)