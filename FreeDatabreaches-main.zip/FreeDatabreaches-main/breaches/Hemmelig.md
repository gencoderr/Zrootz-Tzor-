# Hemmelig database leak

## Description

2011-12-21

In December 2011, Norway's largest online sex shop hemmelig.com was <a href="http://www.dazzlepod.com/hemmelig/?page=93" target="_blank" rel="noopener">hacked by a collective calling themselves &quot;Team Appunity&quot;</a>. The attack exposed over 28,000 usernames and email addresses along with nicknames, gender, year of birth and unsalted MD5 password hashes.

## Breached data

Email addresses, Genders, Nicknames, Partial dates of birth, Passwords, Usernames

## Free download Link

[Hemmelig breach Free Download Link](https://tinyurl.com/2b2k277t)