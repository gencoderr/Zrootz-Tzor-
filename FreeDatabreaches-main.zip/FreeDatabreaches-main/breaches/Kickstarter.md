# Kickstarter database leak

## Description

2014-02-16

In February 2014, the crowdfunding platform <a href="https://www.kickstarter.com/blog/important-kickstarter-security-notice" target="_blank" rel="noopener">Kickstarter announced they'd suffered a data breach</a>. The breach contained almost 5.2 million unique email addresses, usernames and salted SHA1 hashes of passwords.

## Breached data

Email addresses, Passwords

## Free download Link

[Kickstarter breach Free Download Link](https://tinyurl.com/2b2k277t)