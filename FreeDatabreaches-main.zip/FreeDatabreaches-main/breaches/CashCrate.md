# CashCrate database leak

## Description

2016-11-17

In June 2017, news broke that <a href="https://motherboard.vice.com/en_us/article/bj8pvq/hackers-steal-6-million-user-accounts-for-cash-for-surveys-site" target="_blank" rel="noopener">CashCrate had suffered a data breach exposing 6.8 million records</a>. The breach of the cash-for-surveys site dated back to November 2016 and exposed names, physical addresses, email addresses and passwords stored in plain text for older accounts along with weak MD5 hashes for newer ones.

## Breached data

Email addresses, Names, Passwords, Physical addresses

## Free download Link

[CashCrate breach Free Download Link](https://tinyurl.com/2b2k277t)