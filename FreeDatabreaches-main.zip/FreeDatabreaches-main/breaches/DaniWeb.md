# DaniWeb database leak

## Description

2015-12-01

In late 2015, the technology and social site <a href="https://www.daniweb.com" target="_blank" rel="noopener">DaniWeb</a> suffered a data breach. The attack resulted in the disclosure of 1.1 million accounts including email and IP addresses which were also accompanied by salted MD5 hashes of passwords. However, DaniWeb have advised that &quot;the breached password hashes and salts are incorrect&quot; and that they have since switched to new infrastructure and software.

## Breached data

Email addresses, IP addresses, Passwords

## Free download Link

[DaniWeb breach Free Download Link](https://tinyurl.com/2b2k277t)