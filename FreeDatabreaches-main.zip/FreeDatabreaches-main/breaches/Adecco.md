# Adecco database leak

## Description

2021-01-03

In March 2021, <a href="https://cybernews.com/security/5-million-adecco-com-users-data-leaked/" target="_blank" rel="noopener">news broke of a massive data breach impacting millions of Adecco customers in South America</a> which was subsequently sold on a popular hacking forum. The breach exposed over 4M unique email addresses as well as genders, dates of birth, marital statuses, phone numbers and passwords stored as bcrypt hashes.

## Breached data

Email addresses, Genders, Geographic locations, Marital statuses, Names, Passwords, Phone numbers

## Free download Link

[Adecco breach Free Download Link](https://tinyurl.com/2b2k277t)