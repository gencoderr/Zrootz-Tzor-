# MMGFusion database leak

## Description

2020-12-20

In December 2020, the dental practice management service <a href="https://www.riskbasedsecurity.com/2021/02/19/dark-web-roundup-january-2021/" target="_blank" rel="noopener">MMG Fusion was the victim of a data breach</a> which exposed 2.6M unique email addresses. The data also included patient appointments, names, phone numbers, dates of birth, genders and physical addresses. A small number of records also included passwords stored as bcrypt hashes.

## Breached data

Appointments, Dates of birth, Email addresses, Genders, Marital statuses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[MMGFusion breach Free Download Link](https://tinyurl.com/2b2k277t)