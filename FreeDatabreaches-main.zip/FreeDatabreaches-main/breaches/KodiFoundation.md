# KodiFoundation database leak

## Description

2023-02-16

In February 2023, <a href="https://www.bleepingcomputer.com/news/security/kodi-discloses-data-breach-after-forum-database-for-sale-online/" target="_blank" rel="noopener">The Kodi Foundation suffered a data breach that exposed more than 400k user records</a>. Attributed to an account belonging to &quot;a trusted but currently inactive member of the forum admin team&quot;, the breach involved the administrator account creating a database backup that was subsequently downloaded before being sold on a hacking forum. The breach exposed email and IP addresses, usernames, genders and passwords stored as MyBB salted hashes. The Kodi Foundation elected to self-submit impacted email addresses to HIBP.

## Breached data

Browser user agent details, Dates of birth, Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[KodiFoundation breach Free Download Link](https://tinyurl.com/2b2k277t)