# LOTR database leak

## Description

2013-08-01

In August 2013, the interactive video game <a href="https://www.lotro.com" target="_blank" rel="noopener">Lord of the Rings Online</a> suffered a data breach that exposed over 1.1M players' accounts. The data was being actively traded on underground forums and included email addresses, birth dates and password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[LOTR breach Free Download Link](https://tinyurl.com/2b2k277t)