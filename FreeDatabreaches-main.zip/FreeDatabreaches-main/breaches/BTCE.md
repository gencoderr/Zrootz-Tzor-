# BTCE database leak

## Description

2014-10-01

In October 2014, <a href="https://www.databreaches.net/bitcoin-exchange-btc-e-and-bitcointalk-forum-breaches/" target="_blank" rel="noopener">the Bitcoin exchange BTC-E was hacked</a> and 568k accounts were exposed. The data included email and IP addresses, wallet balances and hashed passwords.

## Breached data

Account balances, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[BTCE breach Free Download Link](https://tinyurl.com/2b2k277t)