# Estonia database leak

## Description

2018-06-07

In June 2018, <a href="https://www.troyhunt.com/data-provided-by-the-estonian-central-criminal-police-is-now-searchable-on-have-i-been-pwned" target="_blank" rel="noopener">the Cybercrime Bureau of the Estonian Central Criminal Police contacted HIBP</a> and asked for assistance in making a data set of 655k email addresses searchable. The Estonian police suspected the email addresses and passwords they obtained were being used to access mailboxes, cryptocurrency exchanges, cloud service accounts and other similar online assets. They've requested that individuals who find themselves in the data set <b><i>and also identify that cryptocurrency has been stolen</i></b> contact them at <a href="mailto:cybercrime@politsei.ee">cybercrime@politsei.ee</a>.

## Breached data

Email addresses, Passwords

## Free download Link

[Estonia breach Free Download Link](https://tinyurl.com/2b2k277t)