# Lolzteam database leak

## Description

2018-05-13

In May 2018, the Russian hacking forum <a href="https://medium.com/breach-report/data-hacking-news-over-405-000-hackers-from-lolzteam-net-exposed-3121555080cc" target="_blank" rel="noopener">Lolzteam suffered a data breach that exposed 400k members</a>. The impacted data included usernames and email addresses which were later redistributed via another hacking forum. The data was provided to HIBP by a source who requested it be attributed to &quot;ZAN @ BF&quot;.

## Breached data

Email addresses, Usernames

## Free download Link

[Lolzteam breach Free Download Link](https://tinyurl.com/2b2k277t)