# Abandonia2022 database leak

## Description

2022-11-15

In November 2022, the gaming website dedicated to classic DOS games <a href="https://twitter.com/FalconFeedsio/status/1594670215471792130" target="_blank" rel="noopener">Abandonia</a> suffered a data breach resulting in the exposure of 920k unique user records. This breach was in addition to another one 7 years earlier in 2015. The data contained email and IP addresses, usernames and salted MD5 hashes of passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Abandonia2022 breach Free Download Link](https://tinyurl.com/2b2k277t)