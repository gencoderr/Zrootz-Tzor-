# NemoWeb database leak

## Description

2016-09-04

In September 2016, almost 21GB of data from the French website used for &quot;standardised and decentralized means of exchange for publishing newsgroup articles&quot; <a href="http://www.nemoweb.net/" target="_blank" rel="noopener">NemoWeb</a> was leaked from what appears to have been an unprotected Mongo DB. The data consisted of a large volume of emails sent to the service and included almost 3.5M unique addresses, albeit many of them auto-generated. Multiple attempts were made to contact the operators of NemoWeb but no response was received.

## Breached data

Email addresses, Names

## Free download Link

[NemoWeb breach Free Download Link](https://tinyurl.com/2b2k277t)