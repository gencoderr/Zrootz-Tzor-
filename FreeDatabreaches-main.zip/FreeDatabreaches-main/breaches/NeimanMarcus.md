# NeimanMarcus database leak

## Description

2024-04-14

In May 2024, the American luxury retailer Neiman Marcus suffered a data breach <a href="https://www.bleepingcomputer.com/news/security/neiman-marcus-data-breach-31-million-email-addresses-found-exposed/" target="_blank" rel="noopener">which was later posted to a popular hacking forum</a>. The data included 31M unique email addresses, names, phone numbers, dates of birth, physical addresses and partial credit card data (note: this is insufficient to make purchases). The breach was traced back to a series of attacks against the Snowflake cloud service which impacted 165 organisations worldwide.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Partial credit card data, Phone numbers, Physical addresses, Purchases

## Free download Link

[NeimanMarcus breach Free Download Link](https://tinyurl.com/2b2k277t)