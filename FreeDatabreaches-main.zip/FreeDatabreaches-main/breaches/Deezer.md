# Deezer database leak

## Description

2019-04-22

In late 2022, the music streaming service <a href="https://restoreprivacy.com/music-service-deezer-data-breach/" target="_blank" rel="noopener">Deezer disclosed a data breach that impacted over 240M customers</a>. The breach dated back to a mid-2019 backup exposed by a 3rd party partner which was subsequently sold and then broadly redistributed on a popular hacking forum. Impacted data included 229M unique email addresses, IP addresses, names, usernames, genders, DoBs and the geographic location of the customer.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, IP addresses, Names, Spoken languages, Usernames

## Free download Link

[Deezer breach Free Download Link](https://tinyurl.com/2b2k277t)