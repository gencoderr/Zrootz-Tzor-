# MrExcel database leak

## Description

2016-12-05

In December 2016, the forum for the Microsoft Excel tips and solutions site <a href="http://www.mrexcel.com/details-of-data-breach-at-mrexcel-com/" target="_blank" rel="noopener">Mr Excel suffered a data breach</a>. The hack of the vBulletin forum led to the exposure of over 366k accounts along with email and IP addresses, dates of birth and salted passwords hashed with MD5. The owner of the MrExcel forum subsequently self-submitted the data to HIBP.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Social connections, Usernames, Website activity

## Free download Link

[MrExcel breach Free Download Link](https://tinyurl.com/2b2k277t)