# Netlog database leak

## Description

2012-11-01

In July 2018, the Belgian social networking site <a href="https://oag.ca.gov/system/files/Communication%20to%20Users%20-%20FINAL_0.pdf" target="_blank" rel="noopener">Netlog identified a data breach of their systems dating back to November 2012 (PDF)</a>. Although the service was discontinued in 2015, the data breach still impacted 49 million subscribers for whom email addresses and plain text passwords were exposed. The data was provided to HIBP by a source who requested it be attributed to &quot;JimScott.Sec@protonmail.com&quot;.

## Breached data

Email addresses, Passwords

## Free download Link

[Netlog breach Free Download Link](https://tinyurl.com/2b2k277t)