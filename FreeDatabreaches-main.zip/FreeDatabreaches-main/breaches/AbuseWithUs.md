# AbuseWithUs database leak

## Description

2016-07-01

In 2016, the site dedicated to helping people hack email and online gaming accounts known as Abusewith.us suffered multiple data breaches. The site <a href="https://krebsonsecurity.com/2017/02/who-ran-leakedsource-com/" target="_blank" rel="noopener">allegedly had an administrator in common with the nefarious LeakedSource site</a>, both of which have since been shut down. The exposed data included more than 1.3 million unique email addresses, often accompanied by usernames, IP addresses and plain text or hashed passwords retrieved from various sources and intended to be used to compromise the victims' accounts.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[AbuseWithUs breach Free Download Link](https://tinyurl.com/2b2k277t)