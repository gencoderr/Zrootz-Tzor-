# BlackHatWorld database leak

## Description

2014-06-23

In June 2014, the search engine optimisation forum <a href="http://www.blackhatworld.com" target="_blank" rel="noopener">Black Hat World</a> had three quarters of a million accounts breached from their system. The breach included various personally identifiable attributes which were publicly released in a MySQL database script.

## Breached data

Dates of birth, Email addresses, Instant messenger identities, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[BlackHatWorld breach Free Download Link](https://tinyurl.com/2b2k277t)