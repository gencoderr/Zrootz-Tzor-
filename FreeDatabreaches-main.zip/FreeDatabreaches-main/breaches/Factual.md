# Factual database leak

## Description

2017-03-22

In March 2017, a file containing 8M rows of data <a href="https://www.troyhunt.com/when-is-data-public-and-2-5m-public-factual-records" target="_blank" rel="noopener">allegedly sourced from data aggregator Factual</a> was compiled and later exchanged on the premise it was a &quot;breach&quot;. The data contained 2.5M unique email addresses alongside business names, addresses and phone numbers. After consultation with Factual, they advised the data was &quot;publicly available information about businesses and other points of interest that Factual makes available on its website and to customers&quot;.

## Breached data

Email addresses, Employers, Phone numbers, Physical addresses

## Free download Link

[Factual breach Free Download Link](https://tinyurl.com/2b2k277t)