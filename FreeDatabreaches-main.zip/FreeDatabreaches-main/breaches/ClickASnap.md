# ClickASnap database leak

## Description

2022-09-24

In September 2022, the online photo sharing platform <a href="https://blog.clickasnap.com/2022/10/14/clickasnap-website-breach-24-09-22/" target="_blank" rel="noopener">ClickASnap suffered a data breach</a>. The incident exposed almost 3.3M personal records including email addresses, usernames and passwords stored as SHA-512 hashes. Further, a collection of paid subscriptions were also included and contained names, physical addresses and amounts paid.

## Breached data

Email addresses, Names, Passwords, Physical addresses, Purchases, Social media profiles, Usernames

## Free download Link

[ClickASnap breach Free Download Link](https://tinyurl.com/2b2k277t)