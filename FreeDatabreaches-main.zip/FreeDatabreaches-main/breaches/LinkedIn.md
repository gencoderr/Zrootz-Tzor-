# LinkedIn database leak

## Description

2012-05-05

In May 2016, <a href="https://www.troyhunt.com/observations-and-thoughts-on-the-linkedin-data-breach" target="_blank" rel="noopener">LinkedIn had 164 million email addresses and passwords exposed</a>. Originally hacked in 2012, the data remained out of sight until being offered for sale on a dark market site 4 years later. The passwords in the breach were stored as SHA1 hashes without salt, the vast majority of which were quickly cracked in the days following the release of the data.

## Breached data

Email addresses, Passwords

## Free download Link

[LinkedIn breach Free Download Link](https://tinyurl.com/2b2k277t)