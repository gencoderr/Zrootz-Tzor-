# ClubPenguinRewritten database leak

## Description

2018-01-21

In January 2018, the children's gaming site <a href="https://community.cprewritten.net/" target="_blank" rel="noopener">Club Penguin Rewritten</a> (CPRewritten) suffered a data breach (note: CPRewritten is an independent recreation of Disney's Club Penguin game). The incident exposed almost 1.7 million unique email addresses alongside IP addresses, usernames and passwords stored as bcrypt hashes. When contacted, CPRewritten advised they were aware of the breach and had &quot;contacted affected users&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[ClubPenguinRewritten breach Free Download Link](https://tinyurl.com/2b2k277t)