# MechoDownload database leak

## Description

2013-10-31

In October 2013, the (now defunct) downloads website &quot;Mecho Download&quot; suffered a data breach that exposed 438k records. Data from the vBulletin based website included email and IP addresses, usernames and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MechoDownload breach Free Download Link](https://tinyurl.com/2b2k277t)