# Battlefy database leak

## Description

2016-01-11

In January 2016, the esports website <a href="https://dotesports.com/general/news/battlefy-hack-data-breach-user-credentials-2800" target="_blank" rel="noopener">Battlefy suffered a data breach that exposed 83k customer records</a>. The impacted data included email addresses, usernames and passwords stored as bcrypt hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Battlefy breach Free Download Link](https://tinyurl.com/2b2k277t)