# LittleMonsters database leak

## Description

2017-01-01

In approximately January 2017, <a href="https://www.heise.de/security/meldung/Little-Monsters-Nutzerdaten-aus-Lady-Gagas-Social-Network-sollen-geleakt-sein-3646447.html" target="_blank" rel="noopener">the Lady Gaga fan site known as &quot;Little Monsters&quot; suffered a data breach that impacted 1 million accounts</a>. The data contained usernames, email addresses, dates of birth and bcrypt hashes of passwords.

## Breached data

Dates of birth, Email addresses, Passwords, Usernames

## Free download Link

[LittleMonsters breach Free Download Link](https://tinyurl.com/2b2k277t)