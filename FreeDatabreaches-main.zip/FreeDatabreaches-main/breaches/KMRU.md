# KMRU database leak

## Description

2016-02-29

In February 2016, the Russian portal and email service <a href="http://km.ru" target="_blank" rel="noopener">KM.RU</a> was the target of an attack which was consequently <a href="https://www.reddit.com/r/pwned/comments/47u1bf/operation_wrath_of_anakin_evolved" target="_blank" rel="noopener">detailed on Reddit</a>. Allegedly protesting &quot;the foreign policy of Russia in regards to Ukraine&quot;, KM.RU was one of several Russian sites in the breach and impacted almost 1.5M accounts including sensitive personal information.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, Recovery email addresses, Security questions and answers, Usernames

## Free download Link

[KMRU breach Free Download Link](https://tinyurl.com/2b2k277t)