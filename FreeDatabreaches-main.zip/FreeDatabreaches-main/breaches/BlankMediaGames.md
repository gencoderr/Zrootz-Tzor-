# BlankMediaGames database leak

## Description

2018-12-28

In December 2018, the Town of Salem website produced by <a href="https://blog.dehashed.com/town-of-salem-blankmediagames-hacked/" target="_blank" rel="noopener">BlankMediaGames suffered a data breach</a>. Reported to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">DeHashed</a>, the data contained 7.6M unique user email addresses alongside usernames, IP addresses, purchase histories and passwords stored as phpass hashes. DeHashed made multiple attempts to contact BlankMediaGames over various channels and many days but had yet to receive a response at the time of publishing.

## Breached data

Browser user agent details, Email addresses, IP addresses, Passwords, Purchases, Usernames, Website activity

## Free download Link

[BlankMediaGames breach Free Download Link](https://tinyurl.com/2b2k277t)