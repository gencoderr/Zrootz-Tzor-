# Coachella database leak

## Description

2017-02-22

In February 2017, <a href="https://motherboard.vice.com/en_us/article/mgkzkp/someone-is-selling-coachella-user-accounts-on-the-dark-web" target="_blank" rel="noopener">hundreds of thousands of records from the Coachella music festival were discovered being sold online</a>. Allegedly taken from a combination of the main Coachella website and their vBulletin-based message board, the data included almost 600k usernames, IP and email addresses and salted hashes of passwords (MD5 in the case of the message board).

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Coachella breach Free Download Link](https://tinyurl.com/2b2k277t)