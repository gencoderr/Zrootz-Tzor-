# Duowan database leak

## Description

2011-01-01

In approximately 2011, data was allegedly obtained from the Chinese gaming website known as <a href="http://www.duowan.com" target="_blank" rel="noopener">Duowan.com</a> and contained 2.6M accounts. Whilst there is evidence that the data is legitimate, due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email addresses, user names and plain text passwords. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Duowan breach Free Download Link](https://tinyurl.com/2b2k277t)