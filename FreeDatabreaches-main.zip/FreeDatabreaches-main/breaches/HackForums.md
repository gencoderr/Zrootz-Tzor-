# HackForums database leak

## Description

2011-06-25

In June 2011, the hacktivist group known as "LulzSec" leaked <a href="http://www.forbes.com/sites/andygreenberg/2011/06/25/lulzsec-says-goodbye-dumping-nato-att-gamer-data/" target="_blank" rel="noopener">one final large data breach they titled "50 days of lulz"</a>. The compromised data came from sources such as AT&T, Battlefield Heroes and the <a href="http://hackforums.net" target="_blank" rel="noopener">hackforums.net website</a>. The leaked Hack Forums data included credentials and personal information of nearly 200,000 registered forum users.

## Breached data

Dates of birth, Email addresses, Instant messenger identities, IP addresses, Passwords, Social connections, Spoken languages, Time zones, User website URLs, Usernames, Website activity

## Free download Link

[HackForums breach Free Download Link](https://tinyurl.com/2b2k277t)