# AdultFanFiction database leak

## Description

2018-05-30

In May 2018, the website for sharing adult-orientated works of fiction known as <a href="http://www.adult-fanfiction.org" target="_blank" rel="noopener">Adult-FanFiction.Org</a> had 186k records exposed in a data breach. The data contained names, email addresses, dates of birth and passwords stored as <em>both</em> MD5 hashes and plain text. AFF did not respond when contacted about the breach and the site was previously reported as compromised on the <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a> breached database directory.

## Breached data

Dates of birth, Email addresses, Names, Passwords

## Free download Link

[AdultFanFiction breach Free Download Link](https://tinyurl.com/2b2k277t)