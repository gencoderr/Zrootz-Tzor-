# ManipulatedCaiman database leak

## Description

2023-07-16

In July 2023, <a href="https://perception-point.io/blog/manipulated-caiman-the-sophisticated-snare-of-mexicos-banking-predators-technical-edition/" target="_blank" rel="noopener">Perception Point reported on a phishing operation dubbed &quot;Manipulated Caiman&quot;</a>. Targeting primarily the citizens of Mexico, the campaign attempted to gain access to victims' bank accounts via spear phishing attacks using malicious attachments. Researchers obtained almost 40M email addresses targeted in the campaign and provided the data to HIBP to alert potential victims.

## Breached data

Email addresses

## Free download Link

[ManipulatedCaiman breach Free Download Link](https://tinyurl.com/2b2k277t)