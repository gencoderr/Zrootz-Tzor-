# Avast database leak

## Description

2014-05-26

In May 2014, <a href="https://www.grahamcluley.com/2014/05/avast-forum-hacked/" target="_blank" rel="noopener">the Avast anti-virus forum was hacked</a> and 423k member records were exposed. The Simple Machines Based forum included usernames, emails and password hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Avast breach Free Download Link](https://tinyurl.com/2b2k277t)