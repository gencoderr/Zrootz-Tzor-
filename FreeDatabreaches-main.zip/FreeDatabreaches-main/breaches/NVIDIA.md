# NVIDIA database leak

## Description

2022-02-23

In February 2022, microchip company <a href="https://www.zdnet.com/article/nvidia-says-employee-credentials-proprietary-information-stolen-during-cyberattack/" target="_blank" rel="noopener">NVIDIA suffered a data breach that exposed employee credentials and proprietary code</a>. Impacted data included over 70k employee email addresses and NTLM password hashes, many of which were subsequently cracked and circulated within the hacking community.

## Breached data

Email addresses, Passwords

## Free download Link

[NVIDIA breach Free Download Link](https://tinyurl.com/2b2k277t)