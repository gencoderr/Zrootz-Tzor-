# GeniusU database leak

## Description

2020-10-02

In November 2020, <a href="https://www.databreaches.net/more-drama-on-a-forum-and-a-slew-of-new-databases-dumped/" target="_blank" rel="noopener">a collection of data breaches were made public including the &quot;Entrepreneur Success Platform&quot;, GeniusU</a>. Dating back to the previous month, the data included 1.3M names, email and IP addresses, genders, links to social media profiles and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Genders, IP addresses, Names, Passwords, Social media profiles

## Free download Link

[GeniusU breach Free Download Link](https://tinyurl.com/2b2k277t)