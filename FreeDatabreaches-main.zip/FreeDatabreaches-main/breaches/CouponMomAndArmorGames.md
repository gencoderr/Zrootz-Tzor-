# CouponMomAndArmorGames database leak

## Description

2014-02-08

In 2014, a file allegedly containing data hacked from <a href="https://www.couponmom.com" target="_blank" rel="noopener">Coupon Mom</a> was created and included 11 million email addresses and plain text passwords. On further investigation, the file was also found to contain data indicating it had been sourced from <a href="https://armorgames.com" target="_blank" rel="noopener">Armor Games</a>. Subsequent verification with HIBP subscribers confirmed the passwords had previously been used and many subscribers had used either Coupon Mom or Armor Games in the past. On disclosure to both organisations, each found that the data did not represent their entire customer base and possibly includes records from other sources with common subscribers. The breach has subsequently been flagged as &quot;unverified&quot; as the source cannot be emphatically proven. In July 2020, <a href="https://www.troyhunt.com/how-beeradvocate-learned-theyd-been-pwned/" target="_blank" rel="noopener">the data was also found to contain BeerAdvocate accounts sourced from a previously unknown breach</a>.

## Breached data

Email addresses, Passwords

## Free download Link

[CouponMomAndArmorGames breach Free Download Link](https://tinyurl.com/2b2k277t)