# MeetMindful database leak

## Description

2020-01-26

In early 2020, the online dating service <a href="https://www.zdnet.com/article/hacker-leaks-data-of-2-28-million-dating-site-users/" target="_blank" rel="noopener">MeetMindful suffered a data breach</a> that exposed 1.4 million unique customer email addresses. Included in the data was an extensive array of personal information used to find romantic matches including physical attributes, use of alcohol, drugs and cigarettes, marital statuses, birthdates, genders and the gender being sought. Additional personal information such as names, geographical locations and IP addresses were also exposed, along with passwords stored as bcrypt hashes.

## Breached data

Dates of birth, Drinking habits, Drug habits, Email addresses, Genders, Geographic locations, IP addresses, Marital statuses, Names, Passwords, Physical attributes, Religions, Sexual orientations, Smoking habits, Social media profiles, Usernames

## Free download Link

[MeetMindful breach Free Download Link](https://tinyurl.com/2b2k277t)