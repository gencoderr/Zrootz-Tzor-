# Activision database leak

## Description

2022-12-04

In December 2022, <a href="https://www.bleepingcomputer.com/news/security/hacker-leaks-alleged-activision-employee-data-on-cybercrime-forum/" target="_blank" rel="noopener">attackers socially engineered an Activision HR employee into disclosing information which led to the breach of almost 20k employee records</a>. The data contained 16k unique email addresses along with names, phone numbers, job titles and the office location of the employee. Activision advised that no sensitive employee information was included in the breach.

## Breached data

Email addresses, Geographic locations, Job titles, Names, Phone numbers

## Free download Link

[Activision breach Free Download Link](https://tinyurl.com/2b2k277t)