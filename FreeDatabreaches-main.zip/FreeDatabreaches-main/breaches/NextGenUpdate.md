# NextGenUpdate database leak

## Description

2014-04-22

Early in 2014, the video game website <a href="http://www.nextgenupdate.com" target="_blank" rel="noopener">NextGenUpdate</a> reportedly <a href="https://leakforums.org/thread-265363" target="_blank" rel="noopener">suffered a data breach</a> that disclosed almost 1.2 million accounts. Amongst the data breach was usernames, email addresses, IP addresses and salted and hashed passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[NextGenUpdate breach Free Download Link](https://tinyurl.com/2b2k277t)