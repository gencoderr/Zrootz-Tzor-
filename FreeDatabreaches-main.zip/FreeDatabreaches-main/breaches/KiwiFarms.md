# KiwiFarms database leak

## Description

2019-09-10

In September 2019, the forum for discussing &quot;lolcows&quot; (people who can be milked for laughs) <a href="https://kiwifarms.net/threads/dealing-with-the-compromise.60767/" target="_blank" rel="noopener">Kiwi Farms suffered a data breach</a>. The disclosure notice advised that email and IP addresses, dates of birth and content created by members were all exposed in the incident.

## Breached data

Avatars, Dates of birth, Email addresses, IP addresses, Website activity

## Free download Link

[KiwiFarms breach Free Download Link](https://tinyurl.com/2b2k277t)