# Ajarn database leak

## Description

2018-12-13

In September 2021, the Thai-based English language teaching website <a href="https://www.ajarn.com/data-breach" target="_blank" rel="noopener">Ajarn discovered they'd been the victim of a data breach dating back to December 2018</a>. The breach was self-submitted to HIBP and included 266k email addresses, names, genders, phone numbers and other personal information. Hashed passwords were also impacted in the breach.

## Breached data

Dates of birth, Education levels, Email addresses, Genders, Geographic locations, Job applications, Marital statuses, Names, Nationalities, Passwords, Phone numbers, Profile photos

## Free download Link

[Ajarn breach Free Download Link](https://tinyurl.com/2b2k277t)