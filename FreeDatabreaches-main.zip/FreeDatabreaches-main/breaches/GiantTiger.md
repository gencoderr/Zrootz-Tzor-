# GiantTiger database leak

## Description

2024-03-04

In March 2024, <a href="https://cybernews.com/news/giant-tiger-customers-exposed/#google_vignette" target="_blank" rel="noopener">Canadian discount store Giant Tiger suffered a data breach that exposed 2.8M customer records</a>. Attributed to a vendor of the retailer, the breach included physical and email addresses, names and phone numbers.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[GiantTiger breach Free Download Link](https://tinyurl.com/2b2k277t)