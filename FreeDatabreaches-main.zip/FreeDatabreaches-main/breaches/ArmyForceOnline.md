# ArmyForceOnline database leak

## Description

2016-05-18

In May 2016, the online gaming site <a href="http://armyforceonline.com" target="_blank" rel="noopener">Army Force Online</a> suffered a data breach that exposed 1.5M accounts. The breached data was found being regularly traded online and included usernames, email and IP addresses and MD5 passwords.

## Breached data

Avatars, Email addresses, Geographic locations, IP addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[ArmyForceOnline breach Free Download Link](https://tinyurl.com/2b2k277t)