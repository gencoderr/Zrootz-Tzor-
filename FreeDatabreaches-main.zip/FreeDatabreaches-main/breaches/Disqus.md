# Disqus database leak

## Description

2012-07-01

In October 2017, the blog commenting service <a href="https://blog.disqus.com/security-alert-user-info-breach" target="_blank" rel="noopener">Disqus announced they'd suffered a data breach</a>. The breach dated back to July 2012 but wasn't identified until years later when the data finally surfaced. The breach contained over 17.5 million unique email addresses and usernames. Users who created logins on Disqus had salted SHA1 hashes of passwords whilst users who logged in via social providers only had references to those accounts.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Disqus breach Free Download Link](https://tinyurl.com/2b2k277t)