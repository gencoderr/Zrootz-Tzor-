# Flashback database leak

## Description

2015-02-11

In February 2015, <a href="http://www.flashback.se/" target="_blank" rel="noopener">the Swedish forum known as Flashback</a> had sensitive internal data on 40k members published via the tabloid newspaper <a href="http://www.aftonbladet.se/" target="_blank" rel="noopener">Aftonbladet</a>. The data was <a href="http://swedishsurveyor.com/2015/02/11/the-inquisition/">allegedly sold to them via Researchgruppen</a> (The Research Group) <a href="http://www.technologyreview.com/photoessay/533426/the-troll-hunters/" target="_blank" rel="noopener">who have a history of exposing otherwise anonymous users</a>, primarily those who they believe participate in &quot;troll like&quot; behaviour. The compromised data includes social security numbers, home and email addresses.

## Breached data

Email addresses, Government issued IDs, Physical addresses

## Free download Link

[Flashback breach Free Download Link](https://tinyurl.com/2b2k277t)