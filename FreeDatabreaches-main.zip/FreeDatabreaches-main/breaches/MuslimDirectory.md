# MuslimDirectory database leak

## Description

2014-02-17

In February 2014, the UK guide to services and business known as the Muslim Directory was <a href="http://www.cyberwarnews.info/2014/02/17/muslim-directory-hacked-38903-user-credentials-leaked/" target="_blank" rel="noopener">attacked by the hacker known as @th3inf1d3l</a>. The data was consequently dumped publicly and included the web accounts of tens of thousands of users which contained data including their names, home address, age group, email, website activity and password in plain text.

## Breached data

Age groups, Email addresses, Employers, Names, Passwords, Phone numbers, Physical addresses, Website activity

## Free download Link

[MuslimDirectory breach Free Download Link](https://tinyurl.com/2b2k277t)