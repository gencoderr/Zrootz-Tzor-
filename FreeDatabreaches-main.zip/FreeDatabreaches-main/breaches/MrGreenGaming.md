# MrGreenGaming database leak

## Description

2024-03-01

In March 2024, the online games community Mr. Green Gaming suffered a data breach that exposed 27k user records. Acknowledged on their Discord server, the incident exposed email and IP addresses, usernames, geographic locations and dates of birth.

## Breached data

Dates of birth, Email addresses, Geographic locations, IP addresses, Usernames

## Free download Link

[MrGreenGaming breach Free Download Link](https://tinyurl.com/2b2k277t)