# NulledCH database leak

## Description

2020-05-20

In May 2020, the hacking forum <a href="https://www.nulled.ch/" target="_blank" rel="noopener">Nulled.ch</a> was breached and the data published to a rival hacking forum. Over 43k records were compromised and included IP and email addresses, usernames and passwords stored as salted MD5 hashes alongside the private message history of the website's admin. The data was provided to HIBP by a source who requested it be attributed to &quot;Split10&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[NulledCH breach Free Download Link](https://tinyurl.com/2b2k277t)