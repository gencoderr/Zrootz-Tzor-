# GFAN database leak

## Description

2016-10-10

In October 2016, data surfaced that was allegedly obtained from the Chinese website known as <a href="http://www.gfan.com" target="_blank" rel="noopener">GFAN</a> and contained 22.5M accounts. Whilst there is evidence that the data is legitimate, due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email and IP addresses, user names and salted and hashed passwords. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GFAN breach Free Download Link](https://tinyurl.com/2b2k277t)