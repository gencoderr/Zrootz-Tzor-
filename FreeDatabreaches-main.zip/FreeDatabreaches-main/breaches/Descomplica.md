# Descomplica database leak

## Description

2021-03-14

In March 2021, the Brazilian EdTech company <a href="https://atendimento.descomplica.com.br/hc/pt-br/articles/1500003993042-FAQ-Ataque-cibern%C3%A9tico-14-03" target="_blank" rel="noopener">Descomplica suffered a data breach</a> which was subsequently posted to a popular hacking forum. The data included almost 5 million email addresses, names, the first 6 and last 4 digits and the expiry date of credit cards, purchase histories and password hashes.

## Breached data

Email addresses, Names, Partial credit card data, Passwords, Purchases

## Free download Link

[Descomplica breach Free Download Link](https://tinyurl.com/2b2k277t)