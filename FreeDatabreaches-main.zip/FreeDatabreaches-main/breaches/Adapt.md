# Adapt database leak

## Description

2018-11-05

In November 2018, <a href="https://blog.hackenproof.com/industry-news/another-decision-makers-database-leaked/" target="_blank" rel="noopener">security researcher Bob Diachenko identified an unprotected database hosted by data aggregator &quot;Adapt&quot;</a>. A provider of &quot;Fresh Quality Contacts&quot;, the service exposed over 9.3M unique records of individuals and employer information including their names, employers, job titles, contact information and data relating to the employer including organisation description, size and revenue. No response was received from Adapt when contacted.

## Breached data

Email addresses, Employers, Job titles, Names, Phone numbers, Physical addresses, Social media profiles

## Free download Link

[Adapt breach Free Download Link](https://tinyurl.com/2b2k277t)