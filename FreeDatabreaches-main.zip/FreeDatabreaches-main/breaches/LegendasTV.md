# LegendasTV database leak

## Description

2017-10-01

In October 2017, the now defunct Brazilian service for retrieving subtitles in Portuguese <a href="https://www.hackread.com/dark-web-hacker-selling-accounts-on-dream-market/" target="_blank" rel="noopener">Legendas.TV suffered a data breach that exposed nearly 4M customer records</a>. The impacted data included names, usernames, email and IP addresses and unsalted SHA-1 hashes.

## Breached data

Email addresses, IP addresses, Names, Passwords, Usernames

## Free download Link

[LegendasTV breach Free Download Link](https://tinyurl.com/2b2k277t)