# AhaShare database leak

## Description

2013-05-30

In May 2013, the torrent site <a href="http://www.ahashare.com">AhaShare.com</a> suffered a breach which resulted in more than 180k user accounts being published publicly. The breach included a raft of personal information on registered users plus despite assertions of not distributing personally identifiable information, the site also leaked the IP addresses used by the registered identities.

## Breached data

Email addresses, Genders, Geographic locations, IP addresses, Partial dates of birth, Passwords, Usernames, Website activity

## Free download Link

[AhaShare breach Free Download Link](https://tinyurl.com/2b2k277t)