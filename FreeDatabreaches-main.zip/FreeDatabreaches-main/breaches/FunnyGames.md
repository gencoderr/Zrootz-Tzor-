# FunnyGames database leak

## Description

2018-04-28

In April 2018, the online entertainment site <a href="https://www.funny-games.biz/" target="_blank" rel="noopener">Funny Games</a> suffered a data breach that disclosed 764k records including usernames, email and IP addresses and salted MD5 password hashes. The incident was disclosed to Funny Games in July who acknowledged the breach and identified it had been caused by legacy code no longer in use. The record count in the breach constitute approximately half of the user base.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[FunnyGames breach Free Download Link](https://tinyurl.com/2b2k277t)