# CrackingForum database leak

## Description

2016-07-01

In approximately mid-2016, the cracking community forum known as <a href="http://crackingforum.com" target="_blank" rel="noopener">CrackingForum</a> suffered a data breach. The vBulletin based forum exposed 660k email and IP addresses, usernames and salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[CrackingForum breach Free Download Link](https://tinyurl.com/2b2k277t)