# Mate1 database leak

## Description

2016-02-29

In February 2016, the dating site <a href="http://motherboard.vice.com/read/hacker-claims-to-have-sold-27m-dating-site-passwords-mate1-com-hell-forum" target="_blank" rel="noopener">mate1.com suffered a huge data breach</a> resulting in the disclosure of over 27 million subscribers' information. The data included deeply personal information about their private lives including drug and alcohol habits, incomes levels and sexual fetishes as well as passwords stored in plain text.

## Breached data

Astrological signs, Dates of birth, Drinking habits, Drug habits, Education levels, Email addresses, Ethnicities, Fitness levels, Genders, Geographic locations, Income levels, Job titles, Names, Parenting plans, Passwords, Personal descriptions, Physical attributes, Political views, Relationship statuses, Religions, Sexual fetishes, Travel habits, Usernames, Website activity, Work habits

## Free download Link

[Mate1 breach Free Download Link](https://tinyurl.com/2b2k277t)