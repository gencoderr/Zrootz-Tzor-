# Abandonia database leak

## Description

2015-11-01

In November 2015, the gaming website dedicated to classic DOS games <a href="http://www.abandonia.com" target="_blank" rel="noopener">Abandonia</a> suffered a data breach resulting in the exposure of 776k unique user records. The data contained email and IP addresses, usernames and salted MD5 hashes of passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Abandonia breach Free Download Link](https://tinyurl.com/2b2k277t)