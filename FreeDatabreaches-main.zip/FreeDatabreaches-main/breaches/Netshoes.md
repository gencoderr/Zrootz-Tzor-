# Netshoes database leak

## Description

2017-12-07

In December 2017, the online Brazilian retailer known as <a href="https://www.databreaches.net/netshoes-customer-data-possibly-hacked-500k-customers-order-info-dumped/" target="_blank" rel="noopener">Netshoes had half a million records allegedly hacked from their system posted publicly</a>. The company was contacted by local Brazilian media outlet Tecmundo and subsequently advised that <a href="https://www.tecmundo.com.br/seguranca/125038-netshoes-invadida-meio-milhao-dados-clientes-vazam-internet.htm" target="_blank" rel="noopener">no indications have been identified of an invasion of the company's systems</a>. However, Netshoes' own systems successfully confirm the presence of matching identifiers and email addresses from the data set, indicating a high likelihood that the data originated from them.

## Breached data

Dates of birth, Email addresses, Names, Purchases

## Free download Link

[Netshoes breach Free Download Link](https://tinyurl.com/2b2k277t)