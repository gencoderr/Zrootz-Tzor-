# Adobe database leak

## Description

2013-10-04

In October 2013, 153 million Adobe accounts were breached with each containing an internal ID, username, email, <em>encrypted</em> password and a password hint in plain text. The password cryptography was poorly done and many were quickly resolved back to plain text. The unencrypted hints also <a href="http://www.troyhunt.com/2013/11/adobe-credentials-and-serious.html" target="_blank" rel="noopener">disclosed much about the passwords</a> adding further to the risk that hundreds of millions of Adobe customers already faced.

## Breached data

Email addresses, Password hints, Passwords, Usernames

## Free download Link

[Adobe breach Free Download Link](https://tinyurl.com/2b2k277t)