# FFShrine database leak

## Description

2015-09-18

In September 2015, <a href="http://ffshrine.org" target="_blank" rel="noopener">the Final Fantasy discussion forum known as FFShrine</a> was breached and the data dumped publicly. Approximately 620k records were released containing email addresses, IP addresses and salted hashes of passwords.

## Breached data

Email addresses, Passwords, Usernames, Website activity

## Free download Link

[FFShrine breach Free Download Link](https://tinyurl.com/2b2k277t)