# DemonForums database leak

## Description

2019-02-20

In February 2019, the hacking forum <a href="https://demonforums.net/" target="_blank" rel="noopener">Demon Forums</a> suffered a data breach. The compromise of the vBulletin forum exposed 52k unique email addresses alongside usernames and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[DemonForums breach Free Download Link](https://tinyurl.com/2b2k277t)