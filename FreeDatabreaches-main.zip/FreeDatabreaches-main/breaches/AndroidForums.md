# AndroidForums database leak

## Description

2011-10-30

In October 2011, the Android Forums website <a href="http://www.pcworld.com/article/259201/online_android_forum_hacked_user_data_accessed.html" target="_blank" rel="noopener">was hacked</a> and 745k user accounts were subsequently leaked publicly. The compromised data included email addresses, user birth dates and passwords stored as a salted MD5 hash.

## Breached data

Dates of birth, Email addresses, Homepage URLs, Instant messenger identities, IP addresses, Passwords

## Free download Link

[AndroidForums breach Free Download Link](https://tinyurl.com/2b2k277t)