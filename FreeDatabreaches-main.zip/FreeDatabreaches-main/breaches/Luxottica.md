# Luxottica database leak

## Description

2021-03-16

In March 2021, the world's largest eyewear company <a href="https://www.bleepingcomputer.com/news/security/luxottica-confirms-2021-data-breach-after-info-of-70m-leaks-online/" target="_blank" rel="noopener">Luxoticca suffered a data breach via one of their partners that exposed the personal information of more than 70M people</a>. The data was subsequently sold via a popular hacking forum in late 2022 and included email and physical addresses, names, genders, dates of birth and phone numbers. In a statement from Luxottica, they advised they were aware of the incident and are currently &quot;considering other notification obligations&quot;.

## Breached data

Dates of birth, Email addresses, Genders, Names, Phone numbers, Physical addresses

## Free download Link

[Luxottica breach Free Download Link](https://tinyurl.com/2b2k277t)