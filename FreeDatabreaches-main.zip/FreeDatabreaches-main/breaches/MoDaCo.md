# MoDaCo database leak

## Description

2016-01-01

In approximately January 2016, the UK based Android community known as <a href="http://www.modaco.com" target="_blank" rel="noopener">MoDaCo</a> suffered a data breach which exposed 880k subscriber identities. The data included email and IP addresses, usernames and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MoDaCo breach Free Download Link](https://tinyurl.com/2b2k277t)