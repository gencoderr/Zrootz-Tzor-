# GameSalad database leak

## Description

2019-02-24

In February 2019, the education and game creation website <a href="https://www.zdnet.com/article/round-4-hacker-returns-and-puts-26mil-user-records-for-sale-on-the-dark-web/" target="_blank" rel="noopener">Game Salad suffered a data breach</a>. The incident impacted 1.5M accounts and exposed email addresses, usernames, IP addresses and passwords stored as SHA-256 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;JimScott.Sec@protonmail.com&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GameSalad breach Free Download Link](https://tinyurl.com/2b2k277t)