# NonNudeGirls database leak

## Description

2013-05-21

In May 2013, the non-consensual voyeurism site <a href="http://www.ibtimes.co.uk/upskirt-porn-website-hit-massive-data-leak-exposing-nearly-180000-voyeurs-1602756" target="_blank" rel="noopener">&quot;Non Nude Girls&quot; suffered a data breach</a>. The hack of the vBulletin forum led to the exposure of over 75k accounts along with email and IP addresses, names and plain text passwords.

## Breached data

Email addresses, IP addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[NonNudeGirls breach Free Download Link](https://tinyurl.com/2b2k277t)