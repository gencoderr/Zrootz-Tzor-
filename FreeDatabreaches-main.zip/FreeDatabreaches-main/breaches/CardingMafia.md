# CardingMafia database leak

## Description

2021-03-18

In March 2021, the Carding Mafia forum suffered a data breach that exposed almost 300k members' email addresses. Dedicated to the theft and trading of stolen credit cards, the forum breach also exposed usernames, IP addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[CardingMafia breach Free Download Link](https://tinyurl.com/2b2k277t)