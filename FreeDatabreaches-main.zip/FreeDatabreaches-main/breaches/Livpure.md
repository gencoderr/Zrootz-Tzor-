# Livpure database leak

## Description

2020-08-29

In August 2020, the Indian retailer <a href="https://cloudsek.com/threatintelligence/over-a-million-pii-of-livpure-customers-leak-on-cybercrime-forum/" target="_blank" rel="noopener">Livpure suffered a data breach</a> which exposed over 1 million customer purchases with 270 thousand unique email addresses. The data also included names, phone numbers, physical addresses and details of purchased items. The data was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses, Purchases, Salutations

## Free download Link

[Livpure breach Free Download Link](https://tinyurl.com/2b2k277t)