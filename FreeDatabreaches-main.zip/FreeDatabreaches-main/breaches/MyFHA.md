# MyFHA database leak

## Description

2015-02-18

In approximately February 2015, the home financing website <a href="https://web.archive.org/web/20180324231131/http://myfha.net/" target="_blank" rel="noopener">MyFHA</a> suffered a data breach which disclosed the personal information of nearly 1 million people. The data included extensive personal information relating to home financing including personal contact info, credit statuses, household incomes, loan amounts and notes on personal circumstances, often referring to legal issues, divorces and health conditions. Multiple parties contacted HIBP with the data after which MyFHA was alerted in mid-July and acknowledged the legitimacy of the breach then took the site offline.

## Breached data

Credit status information, Email addresses, Income levels, IP addresses, Loan information, Names, Passwords, Personal descriptions, Physical addresses

## Free download Link

[MyFHA breach Free Download Link](https://tinyurl.com/2b2k277t)