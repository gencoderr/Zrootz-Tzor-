# Forbes database leak

## Description

2014-02-15

In February 2014, the Forbes website <a href="http://news.cnet.com/8301-1009_3-57618945-83/syrian-electronic-army-hacks-forbes-steals-user-data" target="_blank" rel="noopener">succumbed to an attack that leaked over 1 million user accounts</a>. The attack was attributed to the Syrian Electronic Army, allegedly as retribution for a perceived "Hate of Syria". The attack not only leaked user credentials, but also resulted in the posting of fake news stories to forbes.com.

## Breached data

Email addresses, Passwords, User website URLs, Usernames

## Free download Link

[Forbes breach Free Download Link](https://tinyurl.com/2b2k277t)