# 2844Breaches database leak

## Description

2018-02-19

In February 2018, <a href="https://www.troyhunt.com/ive-just-added-2844-new-data-breaches-with-80m-records-to-have-i-been-pwned/" target="_blank" rel="noopener">a massive collection of almost 3,000 alleged data breaches was found online</a>. Whilst some of the data had previously been seen in Have I Been Pwned, 2,844 of the files consisting of more than 80 million unique email addresses had not previously been seen. Each file contained both an email address and plain text password and were consequently loaded as a single &quot;unverified&quot; data breach.

## Breached data

Email addresses, Passwords

## Free download Link

[2844Breaches breach Free Download Link](https://tinyurl.com/2b2k277t)