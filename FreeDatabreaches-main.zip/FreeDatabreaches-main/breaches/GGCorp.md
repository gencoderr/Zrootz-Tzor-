# GGCorp database leak

## Description

2022-08-11

In August 2022, the MMORPG website <a href="https://twitter.com/FalconFeedsio/status/1558362615067250688" target="_blank" rel="noopener">GGCorp suffered a data breach that exposed almost 2.4M unique email addresses</a>. The data also included IP addresses, usernames and MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GGCorp breach Free Download Link](https://tinyurl.com/2b2k277t)