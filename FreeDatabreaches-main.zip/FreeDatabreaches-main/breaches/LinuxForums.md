# LinuxForums database leak

## Description

2018-05-01

In May 2018, <a href="https://web.archive.org/web/20180502093437/http://www.linuxforums.org/forum" target="_blank" rel="noopener">the Linux Forums website</a> suffered a data breach which resulted in the disclosure of 276k unique email addresses. Running on an old version of vBulletin, the breach also disclosed usernames, IP addresses and salted MD5 password hashes. Linux Forums did not respond to multiple attempts to contact them about the breach.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[LinuxForums breach Free Download Link](https://tinyurl.com/2b2k277t)