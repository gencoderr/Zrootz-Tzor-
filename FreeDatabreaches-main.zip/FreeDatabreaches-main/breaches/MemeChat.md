# MemeChat database leak

## Description

2022-06-01

In mid-2022, &quot;the ultimate hub of memes&quot; <a href="https://twitter.com/search?q=memechat%20breach&src=typed_query&f=media" target="_blank" rel="noopener">MemeChat suffered a data breach that exposed 7.4M records</a>. Alleged to be due to a misconfigured Elasticsearch instance, the data contained 4.3M unique email addresses alongside usernames.

## Breached data

Email addresses, Usernames

## Free download Link

[MemeChat breach Free Download Link](https://tinyurl.com/2b2k277t)