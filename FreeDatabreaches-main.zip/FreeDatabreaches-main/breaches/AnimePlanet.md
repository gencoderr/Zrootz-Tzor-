# AnimePlanet database leak

## Description

2016-01-01

In approximately 2016, the anime website <a href="https://www.anime-planet.com/" target="_blank" rel="noopener">Anime-Planet</a> suffered a data breach that impacted 369k subscribers. The exposed data included usernames, IP and email addresses, dates of birth and passwords stored as unsalted MD5 hashes and for newer accounts, bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[AnimePlanet breach Free Download Link](https://tinyurl.com/2b2k277t)