# EpicNPC database leak

## Description

2016-01-02

In January 2016, the hacked account reseller <a href="https://www.epicnpc.com" target="_blank" rel="noopener">EpicNPC</a> suffered a data breach that impacted 409k subscribers. The impacted data included usernames, IP and email addresses and passwords stored as salted MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[EpicNPC breach Free Download Link](https://tinyurl.com/2b2k277t)