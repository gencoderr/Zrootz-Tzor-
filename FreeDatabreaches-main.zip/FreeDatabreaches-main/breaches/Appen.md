# Appen database leak

## Description

2020-06-22

In June 2020, the AI training data company <a href="https://www.bleepingcomputer.com/news/security/hacker-leaks-386-million-user-records-from-18-companies-for-free/" target="_blank" rel="noopener">Appen suffered a data breach</a> exposing the details of almost 5.9 million users which were subsequently sold online. Included in the breach were names, email addresses and passwords stored as bcrypt hashes. Some records also contained phone numbers, employers and IP addresses. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Employers, IP addresses, Names, Passwords, Phone numbers

## Free download Link

[Appen breach Free Download Link](https://tinyurl.com/2b2k277t)