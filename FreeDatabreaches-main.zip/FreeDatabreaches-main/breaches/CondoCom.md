# CondoCom database leak

## Description

2019-06-01

In June 2019, now defunct website Condo.com suffered a data breach <a href="https://cybernews.com/security/billions-passwords-credentials-leaked-mother-of-all-breaches/" target="_blank" rel="noopener">that was later redistributed as part of a larger corpus of data</a>. The impacted data included 1.5M email addresses alongside names, phone numbers and for a small number of records, physical addresses.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[CondoCom breach Free Download Link](https://tinyurl.com/2b2k277t)