# Insanelyi database leak

## Description

2014-07-22

In July 2014, the iOS forum <a href="http://insanelyi.com" target="_blank" rel="noopener">Insanelyi</a> was <a href="http://securityaffairs.co/wordpress/26835/hacking/hacked-bigboss-cydia.html?utm_content=bufferc7e16" target="_blank" rel="noopener">hacked by an attacker known as Kim Jong-Cracks</a>. A popular source of information for users of jailbroken iOS devices running Cydia, the Insanelyi breach disclosed over 104k users' emails addresses, user names and weakly hashed passwords (salted MD5).

## Breached data

Email addresses, Passwords, Usernames, Website activity

## Free download Link

[Insanelyi breach Free Download Link](https://tinyurl.com/2b2k277t)