# AgusiQTorrents database leak

## Description

2019-09-24

In September 2019, Polish torrent site <a href="http://agusiq-torrents.pl/" target="_blank" rel="noopener">AgusiQ-Torrents.pl</a> suffered a data breach. The incident exposed 90k member records including email and IP addresses, usernames and passwords stored as MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[AgusiQTorrents breach Free Download Link](https://tinyurl.com/2b2k277t)