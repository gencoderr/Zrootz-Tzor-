# Bestialitysextaboo database leak

## Description

2018-03-19

In March 2018, the animal bestiality website known as <a href="https://motherboard.vice.com/en_us/article/evqvpz/bestiality-website-hacked-troy-hunt-have-i-been-pwned" target="_blank" rel="noopener">Bestialitysextaboo was hacked</a>. A collection of various sites running on the same service were also compromised and details of the hack (including links to the data) were posted on a popular forum. In all, more than 3.2k unique email addresses were included alongside usernames, IP addresses, dates of birth, genders and bcrypt hashes of passwords.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[Bestialitysextaboo breach Free Download Link](https://tinyurl.com/2b2k277t)