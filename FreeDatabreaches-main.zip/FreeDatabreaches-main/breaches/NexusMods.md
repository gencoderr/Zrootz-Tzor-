# NexusMods database leak

## Description

2013-07-22

In December 2015, the game modding site Nexus Mods <a href="http://www.nexusmods.com/games/news/12670/" target="_blank" rel="noopener">released a statement notifying users that they had been hacked</a>. They subsequently dated the hack as having occurred in July 2013 although there is evidence to suggest the data was being traded months in advance of that. The breach contained usernames, email addresses and passwords stored as a salted hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[NexusMods breach Free Download Link](https://tinyurl.com/2b2k277t)