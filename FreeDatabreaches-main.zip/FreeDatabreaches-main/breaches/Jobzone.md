# Jobzone database leak

## Description

2023-04-15

In April 2023, <a href="https://twitter.com/PalCyberNews/status/1647208008806461440" target="_blank" rel="noopener">data from the Israeli jobs website Jobzone was posted online</a>. The data included 30k records of email addresses, names, social security numbers, genders, dates of birth, fathers' names and physical addresses.

## Breached data

Dates of birth, Email addresses, Family members' names, Genders, Government issued IDs, Names, Phone numbers, Physical addresses

## Free download Link

[Jobzone breach Free Download Link](https://tinyurl.com/2b2k277t)