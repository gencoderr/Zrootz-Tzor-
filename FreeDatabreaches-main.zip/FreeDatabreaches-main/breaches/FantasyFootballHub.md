# FantasyFootballHub database leak

## Description

2021-10-02

In October 2021, the fantasy premier league (soccer) website <a href="https://fantasyfootballhub.co.uk/we-have-suffered-a-cyber-attack/" target="_blank" rel="noopener">Fantasy Football Hub suffered a data breach that exposed 66 thousand unique email addresses</a>. The data included names, usernames, IP addresses, transactions and passwords stored as WordPress MD5 hashes.

## Breached data

Email addresses, IP addresses, Names, Passwords, Purchases, Usernames

## Free download Link

[FantasyFootballHub breach Free Download Link](https://tinyurl.com/2b2k277t)