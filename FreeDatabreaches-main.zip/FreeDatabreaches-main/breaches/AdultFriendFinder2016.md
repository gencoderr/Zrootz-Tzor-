# AdultFriendFinder2016 database leak

## Description

2016-10-16

In October 2016, the adult entertainment company <a href="https://www.zdnet.com/article/adultfriendfinder-network-hack-exposes-secrets-of-412-million-users/" target="_blank" rel="noopener">Friend Finder Networks suffered a massive data breach</a>. The incident impacted multiple separate online assets owned by the company, the largest of which was the Adult FriendFinder website alleged to be &quot;the world's largest sex &amp; swinger community&quot;. Exposed data included usernames, passwords stored as SHA-1 hashes and 170 million unique email addresses. This incident is separate to the 2015 data breach Adult FriendFinder also suffered. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Passwords, Spoken languages, Usernames

## Free download Link

[AdultFriendFinder2016 breach Free Download Link](https://tinyurl.com/2b2k277t)