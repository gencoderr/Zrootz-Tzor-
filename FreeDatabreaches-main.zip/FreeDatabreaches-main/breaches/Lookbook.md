# Lookbook database leak

## Description

2012-08-24

In August 2012, the fashion site <a href="https://www.hackread.com/hacker-selling-million-lookbook-accounts/" target="_blank" rel="noopener">Lookbook suffered a data breach</a>. The data later appeared listed for sale in June 2016 and included 1.1 million usernames, email and IP addresses, birth dates and plain text passwords.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[Lookbook breach Free Download Link](https://tinyurl.com/2b2k277t)