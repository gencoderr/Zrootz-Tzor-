# NetEase database leak

## Description

2015-10-19

In October 2015, the Chinese site known as <a href="http://www.163.com" target="_blank" rel="noopener">NetEase</a> (located at <a href="http://www.163.com" target="_blank" rel="noopener">163.com</a>) was <a href="http://news.mydrivers.com/1/452/452173.htm" target="_blank" rel="noopener">reported as having suffered a data breach that impacted hundreds of millions of subscribers</a>. Whilst there is evidence that the data itself is legitimate (multiple HIBP subscribers confirmed a password they use is in the data), due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email addresses and plain text passwords. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, Passwords

## Free download Link

[NetEase breach Free Download Link](https://tinyurl.com/2b2k277t)