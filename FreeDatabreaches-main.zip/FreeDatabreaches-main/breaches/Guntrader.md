# Guntrader database leak

## Description

2021-07-17

In July 2021, the United Kingdom based website <a href="https://www.fieldsportschannel.tv/guntrader-co-uk-hacked-not-much-lost/" target="_blank" rel="noopener">Guntrader suffered a data breach that exposed 112k unique email addresses</a>. Extensive personal information was also exposed including names, phone numbers, geolocation data, IP addresses and various physical address attributes (cities for all users, complete addresses for some). Passwords stored as bcrypt hashes were also exposed.

## Breached data

Browser user agent details, Email addresses, Geographic locations, IP addresses, Names, Passwords, Phone numbers, Physical addresses, Salutations

## Free download Link

[Guntrader breach Free Download Link](https://tinyurl.com/2b2k277t)