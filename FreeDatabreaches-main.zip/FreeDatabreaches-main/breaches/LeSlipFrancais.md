# LeSlipFrancais database leak

## Description

2024-04-13

In April 2024, the French underwear maker <a href="https://twitter.com/troyhunt/status/1780856574787064075" target="_blank" rel="noopener">Le Slip Français suffered a data breach</a>. The breach included 1.5M email addresses, physical addresses, names and phone numbers.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[LeSlipFrancais breach Free Download Link](https://tinyurl.com/2b2k277t)