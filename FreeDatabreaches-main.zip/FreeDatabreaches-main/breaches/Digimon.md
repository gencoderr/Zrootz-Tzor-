# Digimon database leak

## Description

2016-09-05

In September 2016, over 16GB of logs from a service indicated to be digimon.co.in were obtained, most likely from an unprotected Mongo DB instance. The service ceased running shortly afterwards and no information remains about the precise nature of it. Based on <a href="https://twitter.com/troyhunt/status/1045178309926051840" target="_blank" rel="noopener">enquiries made via Twitter</a>, it appears to have been a mail service possibly based on PowerMTA and used for delivering spam. The logs contained information including 7.7M unique email recipients (names and addresses), mail server IP addresses, email subjects and tracking information including mail opens and clicks.

## Breached data

Email addresses, Email messages, IP addresses, Names

## Free download Link

[Digimon breach Free Download Link](https://tinyurl.com/2b2k277t)