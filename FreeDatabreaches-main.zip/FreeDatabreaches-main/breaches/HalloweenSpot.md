# HalloweenSpot database leak

## Description

2019-09-27

In September 2019, the Halloween costume store <a href="https://www.thehalloweenspot.com/" target="_blank" rel="noopener">The Halloween Spot</a> suffered a data breach. Originally misattributed to fancy dress store <a href="https://www.smiffys.com/" target="_blank" rel="noopener">Smiffys</a>, the breach contained 13GB of data with over 10k unique email addresses alongside names, physical and IP addresses, phone numbers and order histories. The Halloween Spot advised customers the breach was traced back to &quot;an old shipping information database&quot;.

## Breached data

Email addresses, IP addresses, Names, Phone numbers, Physical addresses, Purchases

## Free download Link

[HalloweenSpot breach Free Download Link](https://tinyurl.com/2b2k277t)