# Edmodo database leak

## Description

2017-05-11

In May 2017, the education platform <a href="https://motherboard.vice.com/en_us/article/hacker-steals-millions-of-user-account-details-from-education-platform-edmodo" target="_blank" rel="noopener">Edmodo was hacked</a> resulting in the exposure of 77 million records comprised of over 43 million unique customer email addresses. The data was consequently published to a popular hacking forum and made freely available. The records in the breach included usernames, email addresses and bcrypt hashes of passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Edmodo breach Free Download Link](https://tinyurl.com/2b2k277t)