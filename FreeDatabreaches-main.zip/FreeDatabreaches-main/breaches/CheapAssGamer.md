# CheapAssGamer database leak

## Description

2015-07-01

In approximately mid-2015, the forum for <a href="https://www.cheapassgamer.com" target="_blank" rel="noopener">CheapAssGamer.com</a> suffered a data breach. The database from the IP.Board based forum contained 445k accounts including usernames, email and IP addresses and salted MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[CheapAssGamer breach Free Download Link](https://tinyurl.com/2b2k277t)