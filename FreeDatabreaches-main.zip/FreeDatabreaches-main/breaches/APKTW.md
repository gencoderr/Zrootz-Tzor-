# APKTW database leak

## Description

2022-09-03

In September 2022, the Taiwanese Android forum APK.TW suffered a data breach <a href="https://cybernews.com/security/billions-passwords-credentials-leaked-mother-of-all-breaches/" target="_blank" rel="noopener">that was later redistributed as part of a larger corpus of data</a>. The breach exposed 2.5M unique email addresses along with IP addresses, usernames and salted MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[APKTW breach Free Download Link](https://tinyurl.com/2b2k277t)