# Nitro database leak

## Description

2020-09-28

In September 2020, <a href="https://www.bleepingcomputer.com/news/security/massive-nitro-data-breach-impacts-microsoft-google-apple-more/" target="_blank" rel="noopener">the Nitro PDF service suffered a massive data breach which exposed over 70 million unique email addresses</a>. The breach also exposed names, bcrypt password hashes and the titles of converted documents. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Names, Passwords

## Free download Link

[Nitro breach Free Download Link](https://tinyurl.com/2b2k277t)