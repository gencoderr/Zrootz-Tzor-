# MEO database leak

## Description

2020-12-24

In early 2023, a corpus of data sourced from the New Zealand based face mask company <a href="https://www.meoair.com/" target="_blank" rel="noopener">MEO</a> was discovered. Dating back to December 2020, the data contained over 8k customer records including names, addresses, phone numbers and passwords stored as MD5 Wordpress hashes. MEO did not respond to multiple attempts to report the breach.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses, Purchases, Usernames

## Free download Link

[MEO breach Free Download Link](https://tinyurl.com/2b2k277t)