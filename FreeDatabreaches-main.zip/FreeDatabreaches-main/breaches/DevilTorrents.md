# DevilTorrents database leak

## Description

2021-01-04

In early 2021, the Polish torrents website Devil-Torrents.pl suffered a data breach. A subset of the data including 63k unique email addresses and cracked passwords were subsequently socialised on a popular data breach sharing service.

## Breached data

Email addresses, Passwords

## Free download Link

[DevilTorrents breach Free Download Link](https://tinyurl.com/2b2k277t)