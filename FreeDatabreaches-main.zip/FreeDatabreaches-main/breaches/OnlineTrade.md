# OnlineTrade database leak

## Description

2022-09-19

In September 2022, the Russian e-commerce website <a href="https://xakep.ru/2022/09/21/new-leaks/" target="_blank" rel="noopener">Online Trade (Онлайн Трейд) suffered a data breach</a> that exposed 3.8M customer records. The data included email and IP addresses, names, phone numbers, dates of birth and MD5 password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Passwords, Phone numbers

## Free download Link

[OnlineTrade breach Free Download Link](https://tinyurl.com/2b2k277t)