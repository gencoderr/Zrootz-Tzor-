# MultiplayerIt database leak

## Description

2018-09-01

In April 2024, <a href="https://twitter.com/DarkWebInformer/status/1779593190141554871" target="_blank" rel="noopener">over half a million records taken from the Italian gaming website Multiplayer.it were posted to a popular hacking forum</a>.  The impacted data included email addresses, usernames and salted MD5 password hashes. Multiplayer.it subsequently confirmed the breach dated back 6 years to September 2018 and was merely re-posted in 2024.

## Breached data

Email addresses, Passwords

## Free download Link

[MultiplayerIt breach Free Download Link](https://tinyurl.com/2b2k277t)