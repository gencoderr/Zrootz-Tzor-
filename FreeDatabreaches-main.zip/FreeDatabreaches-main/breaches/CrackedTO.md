# CrackedTO database leak

## Description

2019-07-21

In July 2019, the hacking website <a href="https://cracked.to" target="_blank" rel="noopener">Cracked.to</a> suffered a data breach. There were 749k unique email addresses spread across 321k forum users and other tables in the database. A rival hacking website claimed responsibility for breaching the MyBB based forum which disclosed email and IP addresses, usernames, private messages and passwords stored as bcrypt hashes.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[CrackedTO breach Free Download Link](https://tinyurl.com/2b2k277t)