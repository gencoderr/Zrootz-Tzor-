# B2BUSABusinesses database leak

## Description

2017-07-18

In mid-2017, a spam list of over 105 million individuals in corporate America was discovered online. Referred to as &quot;B2B USA Businesses&quot;, the list categorised email addresses by employer, providing information on individuals' job titles plus their work phone numbers and physical addresses. <a href="https://www.troyhunt.com/have-i-been-pwned-and-spam-lists-of-personal-information" target="_blank" rel="noopener">Read more about spam lists in HIBP.</a>

## Breached data

Email addresses, Employers, Job titles, Names, Phone numbers, Physical addresses

## Free download Link

[B2BUSABusinesses breach Free Download Link](https://tinyurl.com/2b2k277t)