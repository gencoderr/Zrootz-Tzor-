# CrimeAgencyVBulletin database leak

## Description

2017-01-19

In January 2016, <a href="http://news.softpedia.com/news/vbulletin-hack-exposes-820-000-accounts-from-126-forums-513416.shtml" target="_blank" rel="noopener">a large number of unpatched vBulletin forums were compromised by an actor known as &quot;CrimeAgency&quot;</a>. A total of 140 forums had data including usernames, email addresses and passwords (predominantly stored as salted MD5 hashes), extracted and then distributed. Refer to <a href="https://troyhunt.com/i-just-added-another-140-data-breaches-to-have-i-been-pwned" target="_blank" rel="noopener">the complete list of the forums</a> for further information on which sites were impacted.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[CrimeAgencyVBulletin breach Free Download Link](https://tinyurl.com/2b2k277t)