# Aipai database leak

## Description

2016-09-27

In September 2016, data allegedly obtained from the Chinese gaming website known as <a href="http://aipai.com" target="_blank" rel="noopener">Aipai.com</a> and containing 6.5M accounts was leaked online. Whilst there is evidence that the data is legitimate, due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email addresses and MD5 password hashes. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, Passwords

## Free download Link

[Aipai breach Free Download Link](https://tinyurl.com/2b2k277t)