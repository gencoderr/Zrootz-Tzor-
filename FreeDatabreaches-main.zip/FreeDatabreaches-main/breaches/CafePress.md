# CafePress database leak

## Description

2019-02-20

In February 2019, the custom merchandise retailer <a href="https://www.cafepress.com/" target="_blank" rel="noopener">CafePress</a> suffered a data breach. The exposed data included 23 million unique email addresses with some records also containing names, physical addresses, phone numbers and passwords stored as SHA-1 hashes. The data was provided to HIBP by a source who requested it be attributed to "JimScott.Sec@protonmail.com".

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[CafePress breach Free Download Link](https://tinyurl.com/2b2k277t)