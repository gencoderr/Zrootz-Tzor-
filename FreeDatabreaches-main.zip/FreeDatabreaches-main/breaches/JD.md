# JD database leak

## Description

2013-01-01

In 2013 (exact date unknown), the Chinese e-commerce service <a href="https://ecommercechinaagency.com/jd-ecommerce-giant-made-apology-user-data-leakage/" target="_blank" rel="noopener">JD suffered a data breach</a> that exposed 13GB of data containing 77 million unique email addresses. The data also included usernames, phone numbers and passwords stored as SHA-1 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Email addresses, Passwords, Phone numbers, Usernames

## Free download Link

[JD breach Free Download Link](https://tinyurl.com/2b2k277t)