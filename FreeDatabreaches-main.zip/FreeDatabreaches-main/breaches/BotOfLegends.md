# BotOfLegends database leak

## Description

2014-11-13

In November 2014, the forum for <a href="http://botoflegends.com" target="_blank" rel="noopener">Bot of Legends</a> suffered a data breach. The IP.Board forum contained 238k accounts including usernames, email and IP addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[BotOfLegends breach Free Download Link](https://tinyurl.com/2b2k277t)