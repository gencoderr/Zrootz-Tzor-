# Famm database leak

## Description

2020-10-08

In late 2020, the Japanese family photos website <a href="https://www.riskbasedsecurity.com/2021/01/25/shinyhunters-wave-3-one-hacker-exposes-over-125-million-credentials/" target="_blank" rel="noopener">Famm suffered a data breach that subsequently exposed 1.3M customer records</a>, including 535k unique email addresses. Impacted data also included names, dates of birth, genders and passwords stored as SHA-256 hashes.

## Breached data

Dates of birth, Email addresses, Genders, Names, Passwords

## Free download Link

[Famm breach Free Download Link](https://tinyurl.com/2b2k277t)