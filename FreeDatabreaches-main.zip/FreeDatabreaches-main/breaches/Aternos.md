# Aternos database leak

## Description

2015-12-06

In December 2015, the service for creating and running free Minecraft servers known as <a href="https://twitter.com/AternosStatus/status/696121828360716288" target="_blank" rel="noopener">Aternos suffered a data breach that impacted 1.4 million subscribers</a>. The data included usernames, email and IP addresses and hashed passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[Aternos breach Free Download Link](https://tinyurl.com/2b2k277t)