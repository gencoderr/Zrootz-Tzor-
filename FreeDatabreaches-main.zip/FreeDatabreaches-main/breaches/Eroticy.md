# Eroticy database leak

## Description

2015-06-01

In mid-2016, it's alleged that the adult website known as  <a href="http://eroticy.com" target="_blank" rel="noopener">Eroticy</a> was hacked. Almost 1.4 million unique accounts were found circulating in late 2016 which contained a raft of personal information ranging from email addresses to phone numbers to plain text passwords. Whilst many HIBP subscribers confirmed their data was legitimate, the actual source of the breach remains inconclusive. <a href="https://www.troyhunt.com/a-data-breach-investigation-blow-by-blow" target="_blank" rel="noopener">A detailed account of the data has been published</a> in the hope of identifying the origin of the breach.

## Breached data

Email addresses, IP addresses, Names, Passwords, Payment histories, Phone numbers, Physical addresses, Usernames, Website activity

## Free download Link

[Eroticy breach Free Download Link](https://tinyurl.com/2b2k277t)