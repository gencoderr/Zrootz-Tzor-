# Intelimost database leak

## Description

2019-03-10

In March 2019, <a href="https://techcrunch.com/2019/04/02/inside-a-spam-operation/" target="_blank" rel="noopener">a spam operation known as &quot;Intelimost&quot; sent millions of emails appearing to come from people the recipients knew</a>. Security researcher <a href="https://securitydiscovery.com/massive-spam-operation-uncovered-in-a-database-leak/" target="_blank" rel="noopener">Bob Diachenko found over 3 million unique email addresses in an exposed Elasticsearch database</a>, alongside plain text passwords used to access the victim's mailbox and customise the spam.

## Breached data

Email addresses, Passwords

## Free download Link

[Intelimost breach Free Download Link](https://tinyurl.com/2b2k277t)