# OVH database leak

## Description

2015-05-01

In mid-2015, the forum for the hosting provider known as <a href="https://www.ovh.com" target="_blank" rel="noopener">OVH</a> suffered a data breach. The vBulletin forum contained 453k accounts including usernames, email and IP addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[OVH breach Free Download Link](https://tinyurl.com/2b2k277t)