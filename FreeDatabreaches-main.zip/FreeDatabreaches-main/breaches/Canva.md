# Canva database leak

## Description

2019-05-24

In May 2019, the graphic design tool website <a href="https://support.canva.com/contact/customer-support/may-24-security-incident-faqs/" target="_blank" rel="noopener">Canva suffered a data breach</a> that impacted 137 million subscribers. The exposed data included email addresses, usernames, names, cities of residence and passwords stored as bcrypt hashes for users not using social logins. The data was provided to HIBP by a source who requested it be attributed to "JimScott.Sec@protonmail.com".

## Breached data

Email addresses, Geographic locations, Names, Passwords, Usernames

## Free download Link

[Canva breach Free Download Link](https://tinyurl.com/2b2k277t)