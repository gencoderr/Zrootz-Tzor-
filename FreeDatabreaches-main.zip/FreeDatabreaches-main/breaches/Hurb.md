# Hurb database leak

## Description

2019-03-14

In approximately March 2019, the online Brazilian travel agency <a href="https://cybleinc.com/2020/07/24/around-43-million-user-records-belonging-to-two-online-platforms-leaked-on-darknet-for-free/" target="_blank" rel="noopener">Hurb (formerly Hotel Urbano) suffered a data breach</a>. The data subsequently appeared online for download the following year and included over 20 million customer records with email and IP addresses, names, dates of birth, phone numbers and passwords stored as unsalted MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Passwords, Phone numbers, Social media profiles

## Free download Link

[Hurb breach Free Download Link](https://tinyurl.com/2b2k277t)