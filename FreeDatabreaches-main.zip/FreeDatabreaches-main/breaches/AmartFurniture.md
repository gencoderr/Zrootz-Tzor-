# AmartFurniture database leak

## Description

2022-05-16

In May 2022, the Australian retailer <a href="https://www.ozbargain.com.au/node/701231" target="_blank" rel="noopener">Amart Furniture advised that their warranty claims database hosted on Amazon Web Services had been the target of a cyber attack</a>. Over 100k records containing email and physical address, names, phone numbers and passwords stored as bcrypt hashes were exposed and shared online by the attacker.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[AmartFurniture breach Free Download Link](https://tinyurl.com/2b2k277t)