# CoinTracker database leak

## Description

2022-12-01

In December 2022, the Crypto & NFT taxes service <a href="https://www.databreaches.net/important-cointracker-security-update/" target="_blank" rel="noopener">CoinTracker reported a data breach that impacted over 1.5M of their customers</a>. The company <a href="https://www.cointracker.io/blog/sendgrid-data-breach" target="_blank" rel="noopener">later attributed the breach to a compromise SendGrid</a> in an attack that targeted multiple customers of the email provider. The breach exposed email addresses and partially redacted phone numbers, with CoinTracker advising that the later did not originate from their service.

## Breached data

Email addresses, Partial phone numbers

## Free download Link

[CoinTracker breach Free Download Link](https://tinyurl.com/2b2k277t)