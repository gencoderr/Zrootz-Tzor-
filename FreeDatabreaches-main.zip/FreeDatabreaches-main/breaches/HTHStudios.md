# HTHStudios database leak

## Description

2018-08-24

In August 2018, the adult furry interactive game creator <a href="https://hthstudios.com/" target="_blank" rel="noopener">HTH Studios</a> suffered a data breach impacting multiple repositories of customer data. Several months later, the data surfaced on a popular hacking forum and included 411k unique email addresses along with physical and IP addresses, names, orders, salted SHA-1 and salted MD5 hashes. HTH Studios is aware of the incident.

## Breached data

Browser user agent details, Dates of birth, Email addresses, IP addresses, Names, Phone numbers, Physical addresses, Purchases, Usernames

## Free download Link

[HTHStudios breach Free Download Link](https://tinyurl.com/2b2k277t)