# GenesisMarket database leak

## Description

2023-04-05

In April 2023, the stolen identity marketplace <a href="https://www.troyhunt.com/seized-genesis-market-data-is-now-searchable-in-have-i-been-pwned-courtesy-of-the-fbi-and-operation-cookie-monster/" target="_blank" rel="noopener">Genesis Market was shut down by the FBI and a coalition of law enforcement agencies across the globe in &quot;Operation Cookie Monster&quot;</a>. The service traded in &quot;browser fingerprints&quot; which enabled criminals to impersonate victims and access their online services. As many of the impacted accounts did not include email addresses, &quot;8M&quot; is merely an approximation intended to indicate scale. Other personal data compromised by the service included names, addresses and credit card information, although not all individuals had each of these fields exposed.

## Breached data

Browser user agent details, Credit card CVV, Credit cards, Dates of birth, Email addresses, Names, Passwords, Phone numbers, Physical addresses, Usernames

## Free download Link

[GenesisMarket breach Free Download Link](https://tinyurl.com/2b2k277t)