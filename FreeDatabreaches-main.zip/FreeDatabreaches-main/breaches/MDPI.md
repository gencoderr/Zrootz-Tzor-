# MDPI database leak

## Description

2016-08-30

In August 2016, the Swiss scholarly open access publisher known as <a href="http://mdpi.com" target="_blank" rel="noopener">MDPI</a> had 17.5GB of data obtained from an unprotected Mongo DB instance. The data contained email exchanges between MDPI and their authors and reviewers which included 845k unique email addresses. MDPI have confirmed that the system has since been protected and that no data of a sensitive nature was impacted. As such, they concluded that notification to their subscribers was not necessary due to the fact that all their authors and reviewers are available online on their website.

## Breached data

Email addresses, Email messages, IP addresses, Names

## Free download Link

[MDPI breach Free Download Link](https://tinyurl.com/2b2k277t)