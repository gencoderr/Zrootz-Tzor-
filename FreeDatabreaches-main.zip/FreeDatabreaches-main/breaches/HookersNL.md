# HookersNL database leak

## Description

2019-10-10

In October 2019, the Dutch prostitution forum <a href="https://www.forbes.com/sites/thomasbrewster/2019/10/10/dutch-prostitution-site-hookersnl-hacked--250000-users-data-leaked/#3e3f231522f8" target="_blank" rel="noopener">Hookers.nl suffered a data breach</a> which exposed the personal information of sex workers and their customers. The IP and email addresses, usernames and either bcrypt or salted MD5 password hashes of 291k members were accessed via an unpatched vulnerability in the vBulletin forum software.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[HookersNL breach Free Download Link](https://tinyurl.com/2b2k277t)