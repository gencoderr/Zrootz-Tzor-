# BlackBerryFans database leak

## Description

2022-05-06

In May 2022, the Chinese BlackBerry enthusiasts website <a href="http://blackberryfans.org/" target="_blank" rel="noopener">BlackBerry Fans</a> suffered a data breach that exposed 174k member records. The impacted data included usernames, email and IP addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[BlackBerryFans breach Free Download Link](https://tinyurl.com/2b2k277t)