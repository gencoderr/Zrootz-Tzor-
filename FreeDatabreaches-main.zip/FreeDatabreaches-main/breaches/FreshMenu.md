# FreshMenu database leak

## Description

2016-07-01

In July 2016, the India-based food delivery service <a href="https://www.freshmenu.com/" target="_blank" rel="noopener">FreshMenu</a> suffered a data breach. The incident exposed the personal data of over 110k customers and included their names, email addresses, phone numbers, home addresses and order histories. When advised of the incident, FreshMenu acknowledged being already aware of the breach but stated they had decided not to notify impacted customers.

## Breached data

Device information, Email addresses, Names, Phone numbers, Physical addresses, Purchases

## Free download Link

[FreshMenu breach Free Download Link](https://tinyurl.com/2b2k277t)