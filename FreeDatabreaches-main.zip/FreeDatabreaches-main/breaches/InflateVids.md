# InflateVids database leak

## Description

2023-12-12

In December 2023, the inflatable and balloon fetish videos website <a href="https://twitter.com/InflateVids/status/1734114873317925294" target="_blank" rel="noopener">InflateVids suffered a data breach</a>. The incident exposed over 13k unique email addresses alongside usernames, IP addresses, genders and SHA-1 password hashes.

## Breached data

Email addresses, Genders, IP addresses, Passwords, Usernames

## Free download Link

[InflateVids breach Free Download Link](https://tinyurl.com/2b2k277t)