# LinkedInScrape2023 database leak

## Description

2023-11-04

In November 2023, <a href="https://troyhunt.com/hackers-scrapers-fakers-whats-really-inside-the-latest-linkedin-dataset" target="_blank" rel="noopener">a post to a popular hacking forum alleged that millions of LinkedIn records had been scraped and leaked</a>. On investigation, the data turned out to be a combination of legitimate data scraped from LinkedIn and email addresses constructed from impacted individuals' names.

## Breached data

Email addresses, Genders, Geographic locations, Job titles, Names, Professional skills, Social media profiles

## Free download Link

[LinkedInScrape2023 breach Free Download Link](https://tinyurl.com/2b2k277t)