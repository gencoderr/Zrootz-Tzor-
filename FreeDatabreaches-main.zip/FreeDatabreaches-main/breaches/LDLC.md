# LDLC database leak

## Description

2024-02-28

In March 2024, <a href="https://www.groupe-ldlc.com/information-relative-a-un-incident-de-cybersecurite-2/" target="_blank" rel="noopener">French retailer LDLC disclosed a data breach that impacted customers of their physical stores</a>. The data was <a href="https://x.com/H4ckManac/status/1763100569810420017" target="_blank" rel="noopener">previously listed for sale on a popular hacking forum</a> and contained 1.26M unique email addresses along with names, phone numbers and physical addresses. The data was provided to HIBP by a source who requested it be attributed to &quot;oathnet.ru&quot;.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses, Salutations

## Free download Link

[LDLC breach Free Download Link](https://tinyurl.com/2b2k277t)