# COMELEC database leak

## Description

2016-03-27

In March 2016, <a href="http://www.comelec.gov.ph/" target="_blank" rel="noopener">the Philippines Commission of Elections website</a> (COMELEC) was <a href="http://www.rappler.com/nation/politics/elections/2016/127256-comelec-website-hacked-anonymous-philippines" target="_blank" rel="noopener">attacked and defaced</a>, allegedly by Anonymous Philippines. Shortly after, <a href="http://www.theregister.co.uk/2016/04/07/philippine_voter_data_breach/" target="_blank" rel="noopener">data on 55 million Filipino voters was leaked publicly</a> and included sensitive information such as genders, marital statuses, height and weight and biometric fingerprint data. The breach only included 228k email addresses.

## Breached data

Biometric data, Dates of birth, Email addresses, Family members' names, Genders, Job titles, Marital statuses, Names, Passport numbers, Phone numbers, Physical addresses, Physical attributes

## Free download Link

[COMELEC breach Free Download Link](https://tinyurl.com/2b2k277t)