# BeautifulPeople database leak

## Description

2015-11-11

In November 2015, the dating website <a href="http://www.forbes.com/sites/thomasbrewster/2016/04/25/beautiful-people-hack-sexual-preference-location-addresses/#26a2cdf7559f" target="_blank" rel="noopener">Beautiful People was hacked</a> and over 1.1M accounts were leaked. The data was being traded in underground circles and included a huge amount of personal information related to dating.

## Breached data

Beauty ratings, Car ownership statuses, Dates of birth, Drinking habits, Education levels, Email addresses, Genders, Geographic locations, Home ownership statuses, Income levels, IP addresses, Job titles, Names, Passwords, Personal descriptions, Personal interests, Physical attributes, Sexual orientations, Smoking habits, Website activity

## Free download Link

[BeautifulPeople breach Free Download Link](https://tinyurl.com/2b2k277t)