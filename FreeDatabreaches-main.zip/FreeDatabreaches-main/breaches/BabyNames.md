# BabyNames database leak

## Description

2008-10-24

In approximately 2008, the site to help parents name their children known as <a href="https://www.babynames.com/" target="_blank" rel="noopener">Baby Names</a> suffered a data breach. The incident exposed 846k email addresses and passwords stored as salted MD5 hashes. When contacted in October 2018, Baby Names advised that &quot;the breach happened at least ten years ago&quot; and that members were notified at the time.

## Breached data

Email addresses, Passwords

## Free download Link

[BabyNames breach Free Download Link](https://tinyurl.com/2b2k277t)