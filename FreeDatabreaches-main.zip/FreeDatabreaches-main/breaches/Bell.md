# Bell database leak

## Description

2014-02-01

In February 2014, <a href="http://news.softpedia.com/news/Hackers-Claim-to-Have-Breached-Bell-Canada-s-Systems-422952.shtml?utm_medium=twitter&utm_source=FredToadster" target="_blank" rel="noopener">Bell Canada suffered a data breach via the hacker collective known as NullCrew</a>. The breach included data from multiple locations within Bell and exposed email addresses, usernames, user preferences and a number of unencrypted passwords and credit card data from 40,000 records containing just over 20,000 unique email addresses and usernames.

## Breached data

Credit cards, Genders, Passwords, Usernames

## Free download Link

[Bell breach Free Download Link](https://tinyurl.com/2b2k277t)