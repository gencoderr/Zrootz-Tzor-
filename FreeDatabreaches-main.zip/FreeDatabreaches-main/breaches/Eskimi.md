# Eskimi database leak

## Description

2020-09-25

In late 2020, the AdTech platform <a href="https://www.riskbasedsecurity.com/2021/01/25/shinyhunters-wave-3-one-hacker-exposes-over-125-million-credentials/" target="_blank" rel="noopener">Eskimi suffered a data breach that exposed 26M records with 1.2M unique email addresses</a>. The data included usernames, dates of birth, genders and passwords stored as unsalted MD5 hashes.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, Passwords, Usernames

## Free download Link

[Eskimi breach Free Download Link](https://tinyurl.com/2b2k277t)