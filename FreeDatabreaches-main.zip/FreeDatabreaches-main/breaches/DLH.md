# DLH database leak

## Description

2016-07-31

In July 2016, the gaming news site <a href="http://www.zdnet.com/article/millions-of-steam-game-keys-stolen-after-site-hack/" target="_blank" rel="noopener">DLH.net suffered a data breach</a> which exposed 3.3M subscriber identities. Along with the keys used to redeem and activate games on the Steam platform, the breach also resulted in the exposure of email addresses, birth dates and salted MD5 password hashes. The data was donated to Have I Been Pwned by data breach monitoring service <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a>.

## Breached data

Dates of birth, Email addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[DLH breach Free Download Link](https://tinyurl.com/2b2k277t)