# ECCIE database leak

## Description

2021-07-01

In January 2021, the adult escort forum <a href="https://www.eccie.net/showthread.php?p=1062479958" target="_blank" rel="noopener">ECCIE suffered a data breach</a> which was later posted to a popular hacking forum. The data included 536k user records with email and IP addresses, usernames, dates of birth and salted MD5 password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[ECCIE breach Free Download Link](https://tinyurl.com/2b2k277t)