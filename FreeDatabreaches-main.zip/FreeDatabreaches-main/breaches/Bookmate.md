# Bookmate database leak

## Description

2018-07-08

In mid-2018, the social ebook subscription service <a href="https://www.theregister.co.uk/2019/02/11/620_million_hacked_accounts_dark_web/" target="_blank" rel="noopener">Bookmate was among a raft of sites that were breached and their data then sold in early-2019</a>. The data included almost 4 million unique email addresses alongside names, genders, dates of birth and passwords stored as salted SHA-512 hashes. The data was provided to HIBP by a source who requested it to be attributed to &quot;BenjaminBlue@exploit.im&quot;.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, Names, Passwords, Usernames

## Free download Link

[Bookmate breach Free Download Link](https://tinyurl.com/2b2k277t)