# LuLu database leak

## Description

2024-07-06

In July 2024, <a href="https://www.csoonline.com/article/2516119/hackers-steal-data-of-200k-lulu-customers-in-an-alleged-breach.html" target="_blank" rel="noopener">the Emirati-based LuLu retail store suffered a data breach</a>. The impacted data included 190k email addresses and associated phone numbers which were subsequently shared on a popular hacking forum. The data was provided to HIBP by a source who requested it be attributed to &quot;IntelBroker&quot;. The following month, the threat of leaking the full database was carried out and a backup from October 2022 with a further 2.6M unique email addresses appeared. This data also included names, physical addresses, orders and PBKDF2 password hashes.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[LuLu breach Free Download Link](https://tinyurl.com/2b2k277t)