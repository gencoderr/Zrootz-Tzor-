# MovieForums database leak

## Description

2022-11-24

In December 2022, <a href="https://www.movieforums.com/community/showthread.php?t=67897" target="_blank" rel="noopener">the Movie Forums website suffered a data breach</a> that affected 40k users. The breach exposed email and IP addresses, usernames, dates of birth and passwords stored as easily crackable salted MD5 hashes. The data was subsequently posted a popular clear web hacking forum.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MovieForums breach Free Download Link](https://tinyurl.com/2b2k277t)