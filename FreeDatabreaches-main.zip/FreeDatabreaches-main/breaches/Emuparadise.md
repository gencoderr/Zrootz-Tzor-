# Emuparadise database leak

## Description

2018-04-01

In April 2018, the self-proclaimed &quot;biggest retro gaming website on earth&quot;, Emuparadise, suffered a data breach. The compromised vBulletin forum exposed 1.1 million email addresses, IP address, usernames and passwords stored as salted MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Emuparadise breach Free Download Link](https://tinyurl.com/2b2k277t)