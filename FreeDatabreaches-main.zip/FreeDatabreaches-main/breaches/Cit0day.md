# Cit0day database leak

## Description

2020-11-04

In November 2020, <a href="https://www.troyhunt.com/inside-the-cit0day-breach-collection" target="_blank" rel="noopener">a collection of more than 23,000 allegedly breached websites known as Cit0day were made available for download on several hacking forums</a>. The data consisted of 226M unique email address alongside password pairs, often represented as both password hashes and the cracked, plain text versions. Independent verification of the data established it contains many legitimate, previously undisclosed breaches. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Passwords

## Free download Link

[Cit0day breach Free Download Link](https://tinyurl.com/2b2k277t)