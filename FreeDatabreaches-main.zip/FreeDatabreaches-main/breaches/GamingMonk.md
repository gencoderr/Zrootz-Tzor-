# GamingMonk database leak

## Description

2020-12-02

In December 2020, India's &quot;largest esports community&quot; <a href="http://gamingmonk.com/" target="_blank" rel="noopener">GamingMonk</a> (since acquired by and redirected to MPL Esports), suffered a data breach. The incident exposed 655k unique email addresses along with names, usernames, phone numbers, dates of birth and bcrypt password hashes.

## Breached data

Dates of birth, Email addresses, Names, Passwords, Phone numbers, Usernames

## Free download Link

[GamingMonk breach Free Download Link](https://tinyurl.com/2b2k277t)