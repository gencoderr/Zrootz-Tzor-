# Dodonew database leak

## Description

2011-12-01

In late 2011, data was allegedly obtained from the Chinese website known as <a href="http://dodonew.com" target="_blank" rel="noopener">Dodonew.com</a> and contained 8.7M accounts. Whilst there is evidence that the data is legitimate, due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email addresses and user names. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, Usernames

## Free download Link

[Dodonew breach Free Download Link](https://tinyurl.com/2b2k277t)