# Imavex database leak

## Description

2021-08-20

In August 2021, the website development company <a href="https://www.imavex.com/breach-information/" target="_blank" rel="noopener">Imavex suffered a data breach that exposed 878 thousand unique email addresses</a>. The data included user records containing names, usernames and password material with some records also containing genders and partial credit card data, including the last 4 digits of the card and expiry date. Hundreds of thousands of form submissions and orders via Imavex customers were also exposed and contained further personal information of submitters and the contents of the form.

## Breached data

Email addresses, Genders, Names, Partial credit card data, Passwords, Phone numbers, Physical addresses, Purchases, Usernames

## Free download Link

[Imavex breach Free Download Link](https://tinyurl.com/2b2k277t)