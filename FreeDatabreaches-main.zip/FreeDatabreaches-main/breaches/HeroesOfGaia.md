# HeroesOfGaia database leak

## Description

2013-01-04

In early 2013, the online fantasy multiplayer game <a href="http://hog.playsnail.com" target="_blank" rel="noopener">Heroes of Gaia</a> suffered a data breach. The newest records in the data set indicate a breach date of 4 January 2013 and include usernames, IP and email addresses but no passwords.

## Breached data

Browser user agent details, Email addresses, IP addresses, Usernames, Website activity

## Free download Link

[HeroesOfGaia breach Free Download Link](https://tinyurl.com/2b2k277t)