# MyPertamina database leak

## Description

2022-11-01

In November 2022, the Indonesian oil and gas company <a href="https://voi.id/en/technology/226367" target="_blank" rel="noopener">Pertamina suffered a data breach of their MyPertamina service</a>. The incident exposed 44M records with 6M unique email addresses along with names, dates of birth, genders, physical addresses and purchases.

## Breached data

Dates of birth, Email addresses, Genders, Names, Phone numbers, Physical addresses, Purchases

## Free download Link

[MyPertamina breach Free Download Link](https://tinyurl.com/2b2k277t)