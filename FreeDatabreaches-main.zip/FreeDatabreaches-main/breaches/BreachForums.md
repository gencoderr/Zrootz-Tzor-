# BreachForums database leak

## Description

2022-11-29

In November 2022, the well-known hacking forum &quot;BreachForums&quot; was itself, breached. Later the following year, <a href="https://www.bleepingcomputer.com/news/security/fbi-seizes-breachforums-after-arresting-its-owner-pompompurin-in-march/" target="_blank" rel="noopener">the operator of the website was arrested and the site seized by law enforcement agencies</a>. The breach exposed 212k records including usernames, IP and email addresses, private messages between site members and passwords stored as argon2 hashes. The data was provided to HIBP by a source who requested it be attributed to <a href="http://t.me/breached_db_person" target="_blank" rel="noopener">&quot;breached_db_person&quot;</a>.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[BreachForums breach Free Download Link](https://tinyurl.com/2b2k277t)