# Autocentrum database leak

## Description

2018-02-04

In February 2018, <a href="https://niebezpiecznik.pl/post/wyciek-hasel-144-000-uzytkownikow-autocentrum-pl/" target="_blank" rel="noopener">data belonging to the Polish motoring website autocentrum.pl was found online</a>. The data contained 144k email addresses and plain text passwords.

## Breached data

Email addresses, Passwords

## Free download Link

[Autocentrum breach Free Download Link](https://tinyurl.com/2b2k277t)