# GamesBox database leak

## Description

2020-09-21

In September 2020, now defunct website Games Box suffered a data breach <a href="https://cybernews.com/security/billions-passwords-credentials-leaked-mother-of-all-breaches/" target="_blank" rel="noopener">that was later redistributed as part of a larger corpus of data</a>. The impacted data included 1.4M email addresses alongside usernames, genders, ages and passwords stored as either a hash or plain text.

## Breached data

Ages, Email addresses, Genders, Passwords, Usernames

## Free download Link

[GamesBox breach Free Download Link](https://tinyurl.com/2b2k277t)