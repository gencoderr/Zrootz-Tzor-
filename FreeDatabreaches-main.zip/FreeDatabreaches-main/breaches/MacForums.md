# MacForums database leak

## Description

2016-07-03

In July 2016, the self-proclaimed &quot;Ultimate Source For Your Mac&quot; website <a href="https://www.mac-forums.com/" target="_blank" rel="noopener">Mac Forums</a> suffered a data breach. The vBulletin-based system exposed over 326k usernames, email and IP addresses, dates of birth and passwords stored as salted MD5 hashes. The data was later discovered being traded on a popular hacking forum. Mac Forums did not respond when contacted about the incident via their contact us form.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MacForums breach Free Download Link](https://tinyurl.com/2b2k277t)