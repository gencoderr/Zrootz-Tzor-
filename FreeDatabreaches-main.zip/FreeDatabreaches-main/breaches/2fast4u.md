# 2fast4u database leak

## Description

2017-12-20

In December 2017, the Belgian motorcycle forum <a href="https://www.2fast4u.be" target="_blank" rel="noopener">2fast4u</a> discovered a data breach of their system. The breach of the vBulletin message board impacted over 17k individual users and exposed email addresses, usersnames and salted MD5 passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[2fast4u breach Free Download Link](https://tinyurl.com/2b2k277t)