# Gawker database leak

## Description

2010-12-11

In December 2010, Gawker was attacked by the hacker collective &quot;Gnosis&quot; in retaliation for what was reported to be a feud between Gawker and 4Chan. Information about Gawkers 1.3M users was published along with the data from Gawker's other web presences including Gizmodo and Lifehacker. Due to the prevalence of password reuse, many victims of the breach <a href="http://www.troyhunt.com/2011/01/why-your-apps-security-design-could.html" target="_blank" rel="noopener">then had their Twitter accounts compromised to send Acai berry spam</a>.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Gawker breach Free Download Link](https://tinyurl.com/2b2k277t)