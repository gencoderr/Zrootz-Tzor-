# CityBee database leak

## Description

2021-02-05

In February 2021, the Lithuanian car-sharing service <a href="https://www.reuters.com/article/us-baltic-dataprotection-idUSKBN2AG2BW" target="_blank" rel="noopener">CityBee announced they'd suffered a data breach that exposed 110k customers' personal information</a>. The breach exposed names, email addresses, government issued IDs and passwords stored as unsalted SHA-1 hashes.

## Breached data

Email addresses, Government issued IDs, Names, Passwords

## Free download Link

[CityBee breach Free Download Link](https://tinyurl.com/2b2k277t)