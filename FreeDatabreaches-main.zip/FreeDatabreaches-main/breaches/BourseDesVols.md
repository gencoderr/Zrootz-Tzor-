# BourseDesVols database leak

## Description

2021-01-12

In January 2021, the French travel company <a href="https://www.riskbasedsecurity.com/2021/02/19/dark-web-roundup-january-2021/" target="_blank" rel="noopener">Bourse des Vols suffered a data breach that exposed 1.46M unique email addresses</a> across more than 1.2k .sql files and over 9GB of data. The impacted data exposed personal information and travel histories including names, phone numbers, IP and physical addresses, dates of birth along with flights taken and purchases.

## Breached data

Dates of birth, Email addresses, Flights taken, IP addresses, Names, Phone numbers, Physical addresses, Purchases

## Free download Link

[BourseDesVols breach Free Download Link](https://tinyurl.com/2b2k277t)