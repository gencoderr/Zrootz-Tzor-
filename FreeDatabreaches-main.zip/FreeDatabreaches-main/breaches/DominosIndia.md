# DominosIndia database leak

## Description

2021-03-24

In April 2021, <a href="https://www.bleepingcomputer.com/news/security/dominos-india-discloses-data-breach-after-hackers-sell-data-online/" target="_blank" rel="noopener">13TB of compromised Domino's India appeared for sale on a hacking forum</a> after which the company acknowledged a major data breach they dated back to March. The compromised data included 22.5 million unique email addresses, names, phone numbers, order histories and physical addresses.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses, Purchases

## Free download Link

[DominosIndia breach Free Download Link](https://tinyurl.com/2b2k277t)