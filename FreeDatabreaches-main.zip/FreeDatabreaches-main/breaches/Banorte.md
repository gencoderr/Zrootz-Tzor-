# Banorte database leak

## Description

2014-08-18

In August 2022, <a href="https://krebsonsecurity.com/2022/08/when-efforts-to-contain-a-data-breach-backfire/" target="_blank" rel="noopener">millions of records from Mexican bank &quot;Banorte&quot; were publicly dumped on a popular hacking forum</a> including 2.1M unique email addresses, physical addresses, names, phone numbers, RFC (tax) numbers, genders and bank balances. Banorte have stated that the data is &quot;outdated&quot;, although have not yet indicated how far back it dates to. Anecdotal feedback from HIBP subscribers suggests the data may date back 8 years to 2014.

## Breached data

Account balances, Email addresses, Genders, Government issued IDs, Names, Phone numbers, Physical addresses

## Free download Link

[Banorte breach Free Download Link](https://tinyurl.com/2b2k277t)