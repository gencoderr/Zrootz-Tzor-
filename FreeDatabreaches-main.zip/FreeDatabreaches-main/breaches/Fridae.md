# Fridae database leak

## Description

2014-05-02

In May 2014, over 25,000 user accounts were breached from the Asian lesbian, gay, bisexual and transgender website known as "Fridae". The attack which was <a href="https://twitter.com/Survela/status/463327706361659392" target="_blank" rel="noopener">announced on Twitter</a> appears to have been <a href="http://pastebin.com/ipFKjv6z" target="_blank" rel="noopener">orchestrated by Deletesec</a> who claim that "Digital weapons shall annihilate all secrecy within governments and corporations". The exposed data included password stored in plain text. 

## Breached data

Email addresses, Passwords, Usernames, Website activity

## Free download Link

[Fridae breach Free Download Link](https://tinyurl.com/2b2k277t)