# Minefield database leak

## Description

2015-06-28

In June 2015, the French Minecraft server known as <a href="https://www.minefield.fr" target="_blank" rel="noopener">Minefield</a> was hacked and 188k member records were exposed. The IP.Board forum included email and IP addresses, birth dates and passwords stored as salted hashes using a weak implementation enabling many to be rapidly cracked.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[Minefield breach Free Download Link](https://tinyurl.com/2b2k277t)