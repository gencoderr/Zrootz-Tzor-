# Moneycontrol database leak

## Description

2017-09-07

In April 2021, <a href="https://www.opindia.com/2021/04/personal-details-of-over-seven-lakh-moneycontrol-users-up-for-sale/" target="_blank" rel="noopener">hackers posted data for sale originating from the online Indian financial platform, Moneycontrol</a>. The data included 763 thousand unique email addresses (allegedly a subset of a larger 40 million account breach), alongside geographic locations, phone numbers, genders, dates of birth and plain text passwords. The date of the original breach is unclear, although the breached data indicates the file was created in September 2017 and Moneycontrol has stated that the breach is &quot;an old data set&quot;.

## Breached data

Email addresses, Genders, Geographic locations, Passwords, Phone numbers

## Free download Link

[Moneycontrol breach Free Download Link](https://tinyurl.com/2b2k277t)