# AdvanceAutoParts database leak

## Description

2024-06-05

In June 2024, <a href="https://www.bleepingcomputer.com/news/security/advance-auto-parts-confirms-data-breach-exposed-employee-information/" target="_blank" rel="noopener">Advance Auto Parts confirmed they had suffered a data breach</a> which was posted for sale to a popular hacking forum. Linked to unauthorised access to Snowflake cloud services, the breach exposed a large number of records related to both customers and employees. In total, 79M unique email addresses were included in the breach, alongside names, phone numbers, addresses and further data attributes related to company employees.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[AdvanceAutoParts breach Free Download Link](https://tinyurl.com/2b2k277t)