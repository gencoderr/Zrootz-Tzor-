# Coinmama database leak

## Description

2017-08-03

In August 2017, the crypto coin brokerage service <a href="https://cointelegraph.com/news/major-crypto-brokerage-coinmama-reports-450-000-users-affected-by-data-breach" target="_blank" rel="noopener">Coinmama suffered a data breach</a> that impacted 479k subscribers. The breach was discovered in February 2019 with exposed data including email addresses, usernames and passwords stored as MD5 WordPress hashes. The data was provided to HIBP by white hat security researcher and data analyst Adam Davies.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Coinmama breach Free Download Link](https://tinyurl.com/2b2k277t)