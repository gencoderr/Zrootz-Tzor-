# Boxee database leak

## Description

2014-03-29

In March 2014, the home theatre PC software maker Boxee had their forums compromised in an attack. The attackers obtained the entire vBulletin MySQL database and promptly posted it for download on the Boxee forum itself. The data included 160k users, password histories, private messages and a variety of other data exposed across nearly 200 publicly exposed tables.

## Breached data

Dates of birth, Email addresses, Geographic locations, Historical passwords, Instant messenger identities, IP addresses, Passwords, Private messages, User website URLs, Usernames

## Free download Link

[Boxee breach Free Download Link](https://tinyurl.com/2b2k277t)