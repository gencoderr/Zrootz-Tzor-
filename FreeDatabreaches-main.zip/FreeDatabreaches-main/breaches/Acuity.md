# Acuity database leak

## Description

2020-06-18

In mid-2020, <a href="https://www.troyhunt.com/acuity-who-attempts-and-failures-to-attribute-437gb-of-breached-data" target="_blank" rel="noopener">a 437GB corpus of data attributed to an entity named &quot;Acuity&quot; was created and later extensively distributed</a>. However, the source could not be confidently verified as any known companies named Acuity. The data totalled over 14M unique email addresses with each row containing extensive personal information across more than 400 columns of data including names, phone numbers, physical addresses, genders and dates of birth.

## Breached data

Dates of birth, Email addresses, Genders, IP addresses, Names, Phone numbers, Physical addresses, Salutations

## Free download Link

[Acuity breach Free Download Link](https://tinyurl.com/2b2k277t)