# BreachForumsClone database leak

## Description

2023-06-17

In June 2023, <a href="https://www.hackread.com/breachforums-data-breach-members-data-leak/" target="_blank" rel="noopener">a clone of the previously shuttered popular hacking forum &quot;BreachForums&quot; suffered a data breach that exposed over 4k records</a>. The breach was due to an exposed backup of the MyBB database which included email and IP addresses, usernames and Argon2 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[BreachForumsClone breach Free Download Link](https://tinyurl.com/2b2k277t)