# JamTangan database leak

## Description

2021-07-06

In July 2021, the online Indonesian watch store, Jam Tangan (AKA Machtwatch), suffered a data breach that exposed over 400k customer records which were subsequently posted to a popular hacking forum. The data included email and IP addresses, names, phone numbers, physical addresses and passwords stored as either unsalted MD5 or bcrypt hashes.

## Breached data

Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[JamTangan breach Free Download Link](https://tinyurl.com/2b2k277t)