# Dota2 database leak

## Description

2016-07-10

In July 2016, <a href="https://news.softpedia.com/news/data-of-nearly-2-million-users-exposed-in-dota2-forum-hack-507162.shtml" target="_blank" rel="noopener">the Dota2 official developers forum suffered a data breach that exposed almost 2 million users</a>. The hack of the vBulletin forum led to the disclosure of email and IP addresses, usernames and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Dota2 breach Free Download Link](https://tinyurl.com/2b2k277t)