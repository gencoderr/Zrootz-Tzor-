# Lanwar database leak

## Description

2018-07-28

In July 2018, staff of <a href="https://lanwar.com/" target="_blank" rel="noopener">the Lanwar gaming site</a> discovered a data breach they believe dates back to sometime over the previous several months. The data contained 45k names, email addresses, usernames and plain text passwords. A Lanwar staff member self-submitted the breach to HIBP and has also contacted the relevant authorities about the incident after identifying a phishing attempt to extort Bitcoin from a user.

## Breached data

Email addresses, Names, Passwords, Physical addresses, Usernames

## Free download Link

[Lanwar breach Free Download Link](https://tinyurl.com/2b2k277t)