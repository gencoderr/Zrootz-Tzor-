# MGM database leak

## Description

2019-07-25

In July 2019, <a href="https://www.zdnet.com/article/exclusive-details-of-10-6-million-of-mgm-hotel-guests-posted-on-a-hacking-forum/" target="_blank" rel="noopener">MGM Resorts discovered a data breach of one of their cloud services</a>. The breach included 10.6M guest records with 3.1M unique email addresses stemming back to 2017. The exposed data included email and physical addresses, names, phone numbers and dates of birth and was subsequently shared on a popular hacking forum in February 2020 where it was extensively redistributed. The data was provided to HIBP by <a href="https://underthebreach.com/" target="_blank" rel="noopener">Under The Breach</a>.

## Breached data

Dates of birth, Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[MGM breach Free Download Link](https://tinyurl.com/2b2k277t)