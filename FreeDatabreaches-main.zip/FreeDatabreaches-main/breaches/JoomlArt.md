# JoomlArt database leak

## Description

2018-01-30

In January 2018, the Joomla template website <a href="https://www.joomlart.com/" target="_blank" rel="noopener">JoomlArt</a> inadvertently exposed more than 22k unique customer records in a Jira ticket. The exposed data was from iJoomla and JomSocial, both services that <a href="https://www.joomlart.com/blog/joomlart-acquires-ijoomla-and-jomsocial" target="_blank" rel="noopener">JoomlArt acquired the previous year</a>. The data included usernames, email addresses, purchases and passwords stored as MD5 hashes. When contacted, JoomlArt advised they were aware of the incident and had previously notified impacted parties.

## Breached data

Email addresses, Names, Passwords, Payment histories, Usernames

## Free download Link

[JoomlArt breach Free Download Link](https://tinyurl.com/2b2k277t)