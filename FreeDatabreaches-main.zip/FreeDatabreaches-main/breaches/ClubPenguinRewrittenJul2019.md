# ClubPenguinRewrittenJul2019 database leak

## Description

2019-07-27

In July 2019, the children's gaming site <a href="https://community.cprewritten.net/" target="_blank" rel="noopener">Club Penguin Rewritten</a> (CPRewritten) suffered a data breach (note: CPRewritten is an independent recreation of Disney's Club Penguin game). In addition to an earlier data breach that impacted 1.7 million accounts, the subsequent breach exposed 4 million unique email addresses alongside IP addresses, usernames and passwords stored as bcrypt hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[ClubPenguinRewrittenJul2019 breach Free Download Link](https://tinyurl.com/2b2k277t)