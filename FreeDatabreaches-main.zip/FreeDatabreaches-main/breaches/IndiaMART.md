# IndiaMART database leak

## Description

2021-05-23

In August 2021, <a href="https://economictimes.indiatimes.com/industry/services/retail/data-breach-or-data-scraping-with-over-38-million-records-up-for-grabs-indiamart-has-some-answering-to-do/articleshow/85563628.cms" target="_blank" rel="noopener">38 million records from Indian e-commerce company IndiaMART were found being traded on a popular hacking forum</a>. Dated several months earlier, the data included over 20 million unique email addresses alongside names, phone numbers and physical addresses. It's unclear whether IndiaMART intentionally exposed the data attributes as part of the intended design of the platform or whether the data was obtained by exploiting a vulnerability in the service.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[IndiaMART breach Free Download Link](https://tinyurl.com/2b2k277t)