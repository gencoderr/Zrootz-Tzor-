# Life360 database leak

## Description

2024-03-01

In July 2024, <a href="https://www.bleepingcomputer.com/news/security/over-400-000-life360-user-phone-numbers-leaked-via-unsecured-android-api/" target="_blank" rel="noopener">data scraped from a misconfigured Life360 API was posted online after being obtained several months earlier</a>. The records included 443k unique email addresses and in most cases, corresponding names and phone numbers (some records were null or obfuscated). Life360 promptly notified impacted users after the incident was discovered.

## Breached data

Email addresses, Names, Phone numbers

## Free download Link

[Life360 breach Free Download Link](https://tinyurl.com/2b2k277t)