# BitTorrent database leak

## Description

2016-01-01

In January 2016, the forum for the popular torrent software <a href="https://motherboard.vice.com/read/another-day-another-hack-user-accounts-for-bittorrents-forum-hacking" target="_blank" rel="noopener">BitTorrent was hacked</a>. The IP.Board based forum stored passwords as weak SHA1 salted hashes and the breached data also included usernames, email and IP addresses.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[BitTorrent breach Free Download Link](https://tinyurl.com/2b2k277t)