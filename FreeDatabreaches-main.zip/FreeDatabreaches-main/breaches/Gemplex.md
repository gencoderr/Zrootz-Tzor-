# Gemplex database leak

## Description

2021-02-18

In February 2021, the Indian streaming platform Gemplex suffered a data breach that exposed 4.6M user accounts. The impacted data included device information, names, phone numbers, email addresses and bcrypt password hashes.

## Breached data

Device information, Email addresses, Names, Passwords, Phone numbers

## Free download Link

[Gemplex breach Free Download Link](https://tinyurl.com/2b2k277t)