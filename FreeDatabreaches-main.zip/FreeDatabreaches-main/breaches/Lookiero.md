# Lookiero database leak

## Description

2024-03-27

In August 2024, <a href="https://x.com/DailyDarkWeb/status/1825895814385856678" target="_blank" rel="noopener">a data breach from the online styling service Lookiero was posted to a popular hacking forum</a>. Dating back to March 2024, the data included 5M unique email addresses, with many of the records also including name, phone number and physical address. When contacted about the incident, Lookiero advised that they would &quot;look into it and get back to you if necessary&quot;. The data was provided to HIBP by a source who requested it be attributed to &quot;oathnet.ru&quot;.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses

## Free download Link

[Lookiero breach Free Download Link](https://tinyurl.com/2b2k277t)