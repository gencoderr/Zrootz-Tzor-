# NotAcxiom database leak

## Description

2020-06-21

In 2020, <a href="https://www.troyhunt.com/data-breach-misattribution-acxiom-live-ramp/" target="_blank" rel="noopener">a corpus of data containing almost a quarter of a billion records spanning over 400 different fields was misattributed to database marketing company Acxiom</a> and subsequently circulated within the hacking community. On review, Acxiom concluded that &quot;the claims are indeed false and that the data, which has been readily available across multiple environments, does not come from Acxiom and is in no way the subject of an Acxiom breach&quot;. The data contained almost 52M unique email addresses.

## Breached data

Email addresses, IP addresses, Names, Phone numbers, Physical addresses

## Free download Link

[NotAcxiom breach Free Download Link](https://tinyurl.com/2b2k277t)