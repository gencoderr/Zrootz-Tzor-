# FoxyBingo database leak

## Description

2008-04-04

In April 2007, the online gambling site <a href="https://www.foxybingo.com" target="_blank" rel="noopener">Foxy Bingo</a> was hacked and 252,000 accounts were obtained by the hackers. The breached records <a href="http://www.itpro.co.uk/637279/gambler-busted-flogging-stolen-data-to-gaming-firms" target="_blank" rel="noopener">were subsequently sold and traded</a> and included personal information data such as plain text passwords, birth dates and home addresses.

## Breached data

Account balances, Browser user agent details, Dates of birth, Email addresses, Genders, Names, Passwords, Phone numbers, Physical addresses, Usernames, Website activity

## Free download Link

[FoxyBingo breach Free Download Link](https://tinyurl.com/2b2k277t)