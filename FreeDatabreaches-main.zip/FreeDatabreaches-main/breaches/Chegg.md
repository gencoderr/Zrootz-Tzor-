# Chegg database leak

## Description

2018-04-28

In April 2018, the textbook rental service <a href="https://techcrunch.com/2018/09/26/chegg-resets-40-million-user-passwords-after-data-breach/" target="_blank" rel="noopener">Chegg suffered a data breach</a> that impacted 40 million subscribers. The exposed data included email addresses, usernames, names and passwords stored as unsalted MD5 hashes. A small number of records also contained physical address or phone number. The data was provided to HIBP by a source who requested it be attributed to "JimScott.Sec@protonmail.com".

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses, Usernames

## Free download Link

[Chegg breach Free Download Link](https://tinyurl.com/2b2k277t)