# Gamigo database leak

## Description

2012-03-01

In March 2012, the German online game publisher Gamigo <a href="http://www.zdnet.com/article/8-24-million-gamigo-passwords-leaked-after-hack/" target="_blank" rel="noopener">was hacked</a> and more than 8 million accounts publicly leaked. The breach included email addresses and passwords stored as weak MD5 hashes with no salt.

## Breached data

Email addresses, Passwords

## Free download Link

[Gamigo breach Free Download Link](https://tinyurl.com/2b2k277t)