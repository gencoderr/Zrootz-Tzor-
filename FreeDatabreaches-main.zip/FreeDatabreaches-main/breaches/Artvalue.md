# Artvalue database leak

## Description

2019-06-19

In June 2019, the France-based art valuation website <a href="http://artvalue.com/" target="_blank" rel="noopener">Artvalue.com</a> left their 158k member subscriber base publicly exposed in a text file on their website. The exposed data included names, usernames, email addresses and passwords stored as MD5 hashes. The site operator did not respond when contacted about the incident, although the exposed file was subsequently removed.

## Breached data

Email addresses, Names, Passwords, Salutations, Usernames

## Free download Link

[Artvalue breach Free Download Link](https://tinyurl.com/2b2k277t)