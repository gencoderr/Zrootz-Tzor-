# Bhinneka database leak

## Description

2020-01-27

In early 2020, the Indonesian consumer electronics website <a href="https://www.thejakartapost.com/news/2020/05/13/e-commerce-platform-bhinneka-com-reported-to-be-latest-target-of-data-theft.html" target="_blank" rel="noopener">Bhinneka suffered a data breach that exposed almost 1.3M customer records</a>. The data included email and physical addresses, names, genders, dates of birth, phone numbers and salted password hashes.

## Breached data

Dates of birth, Email addresses, Genders, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[Bhinneka breach Free Download Link](https://tinyurl.com/2b2k277t)