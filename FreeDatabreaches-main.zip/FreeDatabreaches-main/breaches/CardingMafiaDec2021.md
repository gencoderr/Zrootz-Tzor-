# CardingMafiaDec2021 database leak

## Description

2021-12-28

In December 2021, the Carding Mafia forum suffered a data breach that exposed over 300k members' email addresses. Dedicated to the theft and trading of stolen credit cards, the forum breach also exposed usernames, IP addresses and passwords stored as salted MD5 hashes. This breach came only 9 months after another breach of the forum in March 2021.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[CardingMafiaDec2021 breach Free Download Link](https://tinyurl.com/2b2k277t)