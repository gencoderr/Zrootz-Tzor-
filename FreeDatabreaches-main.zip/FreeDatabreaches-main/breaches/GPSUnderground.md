# GPSUnderground database leak

## Description

2016-07-01

In early 2017, <a href="https://www.hackread.com/vbulletin-forums-hacked-accounts-sold-on-dark-web/" target="_blank" rel="noopener">GPS Underground was amongst a collection of compromised vBulletin websites that were found being sold online</a>. The breach dated back to mid-2016 and included 670k records with usernames, email and IP addresses, dates of birth and salted MD5 password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GPSUnderground breach Free Download Link](https://tinyurl.com/2b2k277t)