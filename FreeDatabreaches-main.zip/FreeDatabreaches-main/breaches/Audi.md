# Audi database leak

## Description

2019-08-14

In August 2019, <a href="https://techcrunch.com/2021/06/11/volkswagen-says-a-vendors-security-lapse-exposed-3-3-million-drivers-details/" target="_blank" rel="noopener">Audi USA suffered a data breach after a vendor left data unsecured and exposed on the internet</a>. The data contained 2.7M unique email addresses along with names, phone numbers, physical addresses and vehicle information including VIN. In <a href="https://techcrunch.com/2021/06/11/volkswagen-says-a-vendors-security-lapse-exposed-3-3-million-drivers-details/" target="_blank" rel="noopener">a disclosure statement from Audi</a>, they also advised some customers had driver's licenses, dates of birth, social security numbers and other personal information exposed.

## Breached data

Dates of birth, Driver's licenses, Email addresses, Names, Phone numbers, Physical addresses, Social security numbers, Vehicle details

## Free download Link

[Audi breach Free Download Link](https://tinyurl.com/2b2k277t)