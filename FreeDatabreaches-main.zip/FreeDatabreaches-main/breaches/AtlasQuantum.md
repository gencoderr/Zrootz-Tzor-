# AtlasQuantum database leak

## Description

2018-08-25

In August 2018, the cryptocurrency investment platform <a href="https://www.facebook.com/notes/atlas-quantum/comunicado-importante/2196456297259749/" target="_blank" rel="noopener">Atlas Quantum suffered a data breach</a>. The breach leaked the personal data of 261k investors on the platform including their names, phone numbers, email addresses and account balances.

## Breached data

Account balances, Email addresses, Names, Phone numbers

## Free download Link

[AtlasQuantum breach Free Download Link](https://tinyurl.com/2b2k277t)