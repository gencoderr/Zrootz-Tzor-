# Nulled database leak

## Description

2016-05-06

In May 2016, the cracking community forum known as <a href="http://nulled.cr/" target="_blank" rel="noopener">Nulled.cr</a> was hacked and 599k user accounts were leaked publicly. The compromised data included email and IP addresses, weak salted MD5 password hashes and hundreds of thousands of private messages between members.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Private messages, Usernames, Website activity

## Free download Link

[Nulled breach Free Download Link](https://tinyurl.com/2b2k277t)