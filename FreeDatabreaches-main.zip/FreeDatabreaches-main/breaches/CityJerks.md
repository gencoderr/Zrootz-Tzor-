# CityJerks database leak

## Description

2023-02-27

In early 2023, the &quot;mutual masturbation&quot; website <a href="https://techcrunch.com/2023/04/27/hackers-steal-emails-private-messages-from-hookup-websites/" target="_blank" rel="noopener">CityJerks suffered a data breach that exposed 177k unique email addresses</a>. The breach also included data from the TruckerSucker &quot;dating app for REAL TRUCKERS and REAL MEN&quot; with the combined corpus of data also exposing usernames, IP addresses, dates of birth, sexual orientations, geo locations, private messages between members and passwords stored as salted MD5 hashes. The data was listed on a public hacking site and provided to HIBP by a source who requested it be attributed to &quot;discord.gg/gN9C9em&quot;.

## Breached data

Bios, Dates of birth, Email addresses, Geographic locations, IP addresses, Passwords, Private messages, Profile photos, Sexual orientations, Usernames

## Free download Link

[CityJerks breach Free Download Link](https://tinyurl.com/2b2k277t)