# Exvagos database leak

## Description

2022-07-21

In July 2022, the direct download website Exvagos suffered a data breach <a href="https://cybernews.com/security/billions-passwords-credentials-leaked-mother-of-all-breaches/" target="_blank" rel="noopener">that was later redistributed as part of a larger corpus of data</a>. The breach exposed 2.1M unique email addresses along with IP addresses, usernames, dates of birth and MD5 password hashes.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Exvagos breach Free Download Link](https://tinyurl.com/2b2k277t)