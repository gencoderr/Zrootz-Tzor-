# Gaadi database leak

## Description

2015-05-14

In May 2015, the Indian motoring website known as <a href="https://www.gaadi.com/" target="_blank" rel="noopener">Gaadi</a> had 4.3 million records exposed in a data breach. The data contained usernames, email and IP addresses, genders, the city of users as well as passwords stored in both plain text and as MD5 hashes. The site was previously reported as compromised on the <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a> breached database directory.

## Breached data

Email addresses, Genders, Geographic locations, IP addresses, Names, Passwords, Phone numbers, Usernames

## Free download Link

[Gaadi breach Free Download Link](https://tinyurl.com/2b2k277t)