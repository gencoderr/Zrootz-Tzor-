# Appartoo database leak

## Description

2017-03-25

In March 2017, the French Flatsharing site known as <a href="https://www.appartoo.com" target="_blank" rel="noopener">Appartoo</a> suffered a data breach. The incident exposed an extensive amount of personal information on almost 50k members including email addresses, genders, ages, private messages sent between users of the service and passwords stored as SHA-256 hashes. Appartoo advised that all subscribers were notified of the incident in early 2017.

## Breached data

Ages, Auth tokens, Email addresses, Employment statuses, Genders, IP addresses, Marital statuses, Names, Passwords, Physical addresses, Private messages, Social media profiles

## Free download Link

[Appartoo breach Free Download Link](https://tinyurl.com/2b2k277t)