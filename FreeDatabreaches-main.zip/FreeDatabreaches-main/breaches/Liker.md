# Liker database leak

## Description

2021-03-08

In March 2021, the self-proclaimed &quot;kinder, smarter social network&quot; <a href="https://liker.com/" target="_blank" rel="noopener">Liker</a> suffered a data breach, allegedly in retaliation for the Gab data breach and scraping of data from Parler. The site remained offline after the breach which exposed 465k email addresses in addition to names, dates of birth, education levels, private messages, security questions and answers in plain text, passwords stored as bcrypt hashes and other personal data attributes. Liker did not respond when contacted about the breach.

## Breached data

Auth tokens, Dates of birth, Education levels, Email addresses, Geographic locations, IP addresses, Names, Passwords, Phone numbers, Private messages, Security questions and answers, Social media profiles, Usernames

## Free download Link

[Liker breach Free Download Link](https://tinyurl.com/2b2k277t)