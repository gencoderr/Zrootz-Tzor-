# LoungeBoard database leak

## Description

2013-08-01

At some point in 2013, 45k accounts were <a href="http://leak.sx/thread-186921" target="_blank" rel="noopener">breached from the Lounge Board "General Discussion Forum" and then dumped publicly</a>. Lounge Board was a MyBB forum launched in 2012 and discontinued in mid 2013 (the last activity in the logs was from August 2013).

## Breached data

Email addresses, IP addresses, Names, Passwords, Private messages, Usernames, Website activity

## Free download Link

[LoungeBoard breach Free Download Link](https://tinyurl.com/2b2k277t)