# 8fit database leak

## Description

2018-07-01

In July 2018, the health and fitness service <a href="https://8fit.zendesk.com/hc/en-us/articles/360017746394-Notice" target="_blank" rel="noopener">8fit suffered a data breach</a>. The data subsequently appeared for sale on a dark web marketplace in February 2019 and included over 15M unique email addresses alongside names, genders, IP addresses and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Genders, Geographic locations, IP addresses, Names, Passwords

## Free download Link

[8fit breach Free Download Link](https://tinyurl.com/2b2k277t)