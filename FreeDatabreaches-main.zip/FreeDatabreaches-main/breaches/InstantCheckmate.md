# InstantCheckmate database leak

## Description

2019-04-12

In 2019, the public records search service <a href="https://www.instantcheckmate.com/security-incident-alert/" target="_blank" rel="noopener">Instant Checkmate suffered a data breach that later came to light in early 2023</a>. The data included almost 12M unique customer email addresses, names, phone numbers and passwords stored as scrypt hashes.

## Breached data

Email addresses, Names, Passwords, Phone numbers

## Free download Link

[InstantCheckmate breach Free Download Link](https://tinyurl.com/2b2k277t)