# MediaWorks database leak

## Description

2023-03-15

In March 2024, <a href="https://www.rnz.co.nz/news/national/512042/mediaworks-data-breach-hackers-email-victims-demanding-820" target="_blank" rel="noopener">millions of rows of data from the New Zealand media company MediaWorks was publicly posted to a popular hacking forum</a>. The incident exposed 163k unique email addresses provided by visitors who filled out online competitions and included names, physical addresses, phone numbers, dates of birth, genders and the responses to questions in the competition. Some victims of the breach subsequently received ransom demands requesting payment to have their data deleted.

## Breached data

Dates of birth, Email addresses, Genders, Phone numbers, Physical addresses

## Free download Link

[MediaWorks breach Free Download Link](https://tinyurl.com/2b2k277t)