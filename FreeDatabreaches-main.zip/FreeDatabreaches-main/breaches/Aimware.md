# Aimware database leak

## Description

2019-04-28

In mid-2019, the video game cheats website &quot;Aimware&quot; suffered a data breach that exposed hundreds of thousands of subscribers' personal information. Data included email and IP addresses, usernames, forum posts, private messages, website activity and passwords stored as salted MD5 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;clerk/anthrax/soontoberichh&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames, Website activity

## Free download Link

[Aimware breach Free Download Link](https://tinyurl.com/2b2k277t)