# Ancestry database leak

## Description

2015-11-07

In November 2015, an Ancestry service known as <a href="https://blogs.ancestry.com/ancestry/2017/12/23/rootsweb-security-update/" target="_blank" rel="noopener">RootsWeb suffered a data breach</a>. The breach was not discovered until late 2017 when a file containing almost 300k email addresses and plain text passwords was identified. 

## Breached data

Email addresses, Passwords

## Free download Link

[Ancestry breach Free Download Link](https://tinyurl.com/2b2k277t)