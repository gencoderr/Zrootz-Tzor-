# NazApi database leak

## Description

2023-09-20

In September 2023, <a href="https://www.troyhunt.com/inside-the-massive-naz-api-credential-stuffing-list/" target="_blank" rel="noopener">over 100GB of stealer logs and credential stuffing lists titled &quot;Naz.API&quot; was posted to a popular hacking forum</a>. The incident contained a combination of email address and plain text password pairs alongside the service they were entered into, and standalone credential pairs obtained from unnamed sources. In total, the corpus of data included 71M unique email addresses and 100M unique passwords.

## Breached data

Email addresses, Passwords

## Free download Link

[NazApi breach Free Download Link](https://tinyurl.com/2b2k277t)