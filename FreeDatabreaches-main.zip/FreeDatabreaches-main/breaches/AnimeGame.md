# AnimeGame database leak

## Description

2020-02-27

In February 2020, the gaming website <a href="http://animegame.me/" target="_blank" rel="noopener">AnimeGame</a> suffered a data breach. The incident affected 1.4M subscribers and exposed email addresses, usernames and passwords stored as salted MD5 hashes. The data was subsequently shared on a popular hacking forum and was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[AnimeGame breach Free Download Link](https://tinyurl.com/2b2k277t)