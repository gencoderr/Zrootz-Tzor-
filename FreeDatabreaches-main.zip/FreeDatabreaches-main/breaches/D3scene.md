# D3scene database leak

## Description

2016-01-01

In January 2016, the gaming website D3Scene, suffered a data breach. The compromised vBulletin forum exposed 569k million email addresses, IP address, usernames and passwords stored as salted MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[D3scene breach Free Download Link](https://tinyurl.com/2b2k277t)