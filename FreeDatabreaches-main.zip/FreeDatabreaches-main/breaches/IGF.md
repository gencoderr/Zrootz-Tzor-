# IGF database leak

## Description

2014-02-20

In February 2014, the Internet Governance Forum (formed by the United Nations for policy dialogue on issues of internet governance) was <a href="http://www.cyberwarnews.info/2014/02/20/united-nations-internet-governance-forum-hacked-3215-accounts-leaked/" target="_blank" rel="noopener">attacked by hacker collective known as Deletesec</a>. Although tasked with &quot;ensuring the security and stability of the Internet&quot;, the IGF’s website was still breached and resulted in the leak of 3,200 email addresses, names, usernames and cryptographically stored passwords.

## Breached data

Email addresses, Names, Passwords, Usernames

## Free download Link

[IGF breach Free Download Link](https://tinyurl.com/2b2k277t)