# EpicGames database leak

## Description

2016-08-11

In August 2016, <a href="http://www.zdnet.com/article/epic-games-unreal-engine-forums-hacked-in-latest-data-breach" target="_blank" rel="noopener">the Epic Games forum suffered a data breach</a>, allegedly due to a SQL injection vulnerability in vBulletin. The attack resulted in the exposure of 252k accounts including usernames, email addresses and salted MD5 hashes of passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[EpicGames breach Free Download Link](https://tinyurl.com/2b2k277t)