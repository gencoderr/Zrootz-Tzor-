# James database leak

## Description

2020-03-25

In June 2020, <a href="https://www.binarydefense.com/threat_watch/seller-floods-forums-with-stolen-data/" target="_blank" rel="noopener">14 previously undisclosed data breaches appeared for sale</a> including the Brazilian delivery service, &quot;James&quot;. The breach occurred in March 2020 and exposed 1.5M unique email addresses, customer locations expressed in longitude and latitude and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Geographic locations, Passwords

## Free download Link

[James breach Free Download Link](https://tinyurl.com/2b2k277t)