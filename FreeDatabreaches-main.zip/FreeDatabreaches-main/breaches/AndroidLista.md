# AndroidLista database leak

## Description

2021-07-28

In July 2021, the Android applications and games review site <a href="https://www.androidlista.com/" target="_blank" rel="noopener">AndroidLista</a> suffered a data breach. The incident exposed 6.6M user records containing email addresses, names, usernames and passwords stored as salted SHA-1 hashes, all of which were subsequently posted to a popular hacking forum. AndroidLista did not respond when contacted about the breach.

## Breached data

Email addresses, Names, Passwords, Usernames

## Free download Link

[AndroidLista breach Free Download Link](https://tinyurl.com/2b2k277t)