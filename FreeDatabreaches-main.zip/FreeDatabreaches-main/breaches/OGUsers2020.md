# OGUsers2020 database leak

## Description

2020-04-02

In April 2020, the account hijacking and SIM swapping forum <a href="https://www.zdnet.com/article/hacking-forum-gets-hacked-for-the-second-time-in-a-year/" target="_blank" rel="noopener">OGUsers suffered their second data breach in less than a year</a>. As with the previous breach, the exposed data included email and IP addresses, usernames, private messages and passwords stored as salted MD5 hashes. A total of 263k email addresses across user accounts and other tables were posted to a rival hacking forum.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[OGUsers2020 breach Free Download Link](https://tinyurl.com/2b2k277t)