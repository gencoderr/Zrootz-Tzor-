# LeadHunter database leak

## Description

2020-03-04

In March 2020, <a href="https://www.troyhunt.com/the-unattributable-lead-hunter-data-breach" target="_blank" rel="noopener">a massive trove of personal information referred to as &quot;Lead Hunter&quot;</a> was provided to HIBP after being found left exposed on a publicly facing Elasticsearch server. The data contained 69 million unique email addresses across 110 million rows of data accompanied by additional personal information including names, phone numbers, genders and physical addresses. At the time of publishing, the breach could not be attributed to those responsible for obtaining and exposing it. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Genders, IP addresses, Names, Phone numbers, Physical addresses

## Free download Link

[LeadHunter breach Free Download Link](https://tinyurl.com/2b2k277t)