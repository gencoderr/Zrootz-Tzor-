# CloudPets database leak

## Description

2017-01-01

In January, the maker of teddy bears that record children's voices and sends them to family and friends via the internet <a href="https://www.troyhunt.com/data-from-connected-cloudpets-teddy-bears-leaked-and-ransomed-exposing-kids-voice-messages" target="_blank" rel="noopener">CloudPets left their database publicly exposed and it was subsequently downloaded by external parties</a> (the data was also subject to 3 different ransom demands). 583k records were provided to HIBP via a data trader and included email addresses and bcrypt hashes, but the full extent of user data exposed by the system was over 821k records and also included children's names and references to portrait photos and voice recordings.

## Breached data

Email addresses, Family members' names, Passwords

## Free download Link

[CloudPets breach Free Download Link](https://tinyurl.com/2b2k277t)