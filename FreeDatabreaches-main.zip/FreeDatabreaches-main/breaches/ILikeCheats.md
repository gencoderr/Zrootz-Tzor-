# ILikeCheats database leak

## Description

2014-10-18

In October 2014, the game cheats website known as ILikeCheats suffered a data breach that exposed 189k accounts. The vBulletin based forum leaked usernames, IP and email addresses and weak MD5 hashes of passwords. The data was provided with support from <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[ILikeCheats breach Free Download Link](https://tinyurl.com/2b2k277t)