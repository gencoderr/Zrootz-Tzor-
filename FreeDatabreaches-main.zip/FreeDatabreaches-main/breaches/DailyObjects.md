# DailyObjects database leak

## Description

2018-01-01

In approximately January 2018, a collection of more than 464k customer records from the Indian online retailer <a href="https://www.dailyobjects.com/" target="_blank" rel="noopener">DailyObjects</a> were leaked online. The data included names, physical and email addresses, phone numbers and &quot;pincodes&quot; stored in plain text. After multiple attempts to contact them, DailyObjects responded and received a copy of the data for verification, however failed to respond to multiple contact attempts following that.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[DailyObjects breach Free Download Link](https://tinyurl.com/2b2k277t)