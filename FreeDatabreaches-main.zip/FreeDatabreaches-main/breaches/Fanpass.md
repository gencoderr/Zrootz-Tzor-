# Fanpass database leak

## Description

2022-04-30

In April 2022, the UK based website for buying and selling soccer tickets <a href="https://milled.com/fanpass/fanpass-incident-notification-V6odeYPOxOTPZFq-" target="_blank" rel="noopener">Fanpass suffered a data breach</a> which exposed 112k customer records. Impacted data includes names, phone numbers, physical addresses, purchase histories and salted password hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;<a href="https://breaches.net/" target="_blank" rel="noopener">breaches.net</a>&quot;.

## Breached data

Email addresses, Genders, Names, Partial dates of birth, Passwords, Phone numbers, Physical addresses, Purchases, Social media profiles

## Free download Link

[Fanpass breach Free Download Link](https://tinyurl.com/2b2k277t)