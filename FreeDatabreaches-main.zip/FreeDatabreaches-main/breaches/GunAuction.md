# GunAuction database leak

## Description

2022-12-03

In December 2022, the online firearms auction website <a href="https://techcrunch.com/2023/03/02/hackers-steal-gun-owners-data-from-firearm-auction-website/" target="_blank" rel="noopener">GunAuction.com suffered a data breach which was later discovered left unprotected on the hacker's server</a>. The data included over 565k user records with extensive personal data including email, IP and physical addresses, names, phone numbers, genders, years of birth, credit card type and passwords stored in plain text. The leaked identities could subsequently be matched to firearms listed for sale on the website.

## Breached data

Browser user agent details, Email addresses, Genders, IP addresses, Partial credit card data, Partial dates of birth, Passwords, Phone numbers, Physical addresses, Usernames

## Free download Link

[GunAuction breach Free Download Link](https://tinyurl.com/2b2k277t)