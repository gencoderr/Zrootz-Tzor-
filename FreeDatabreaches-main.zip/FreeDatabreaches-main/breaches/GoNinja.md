# GoNinja database leak

## Description

2019-12-17

In December 2019, the now defunct German gaming website Go Ninja suffered a data breach that exposed 5M unique email addresses. The impacted data included usernames, email and IP addresses and salted MD5 password hashes. More than 4M of the email addresses appeared to have been generated as opposed to organically provided by the user.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GoNinja breach Free Download Link](https://tinyurl.com/2b2k277t)