# DailyQuiz database leak

## Description

2021-01-13

In January 2021, the quiz website <a href="https://dailyquiz.me/" target="_blank" rel="noopener">Daily Quiz</a> suffered a data breach that exposed over 8 million unique email addresses. The data also included usernames, IP addresses and passwords stored in plain text.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[DailyQuiz breach Free Download Link](https://tinyurl.com/2b2k277t)