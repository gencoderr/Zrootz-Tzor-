# DecoratingTheHouse database leak

## Description

2020-03-27

In March 2020, the Korean interior decoration website <a href="https://www.bleepingcomputer.com/news/security/hacker-leaks-386-million-user-records-from-18-companies-for-free/" target="_blank" rel="noopener">???? (Decorating the House) suffered a data breach</a> which impacted almost 1.3 million members. Served via the URL <a href="https://www.ggumim.co.kr/" target="_blank" rel="noopener">ggumim.co.kr</a>, the exposed data included email addresses, names, usernames and phone numbers, all of which was subsequently shared extensively throughout online hacking communities. The data was provided to HIBP by <a href="https://breachbase.pw/" target="_blank" rel="noopener">breachbase.pw</a>.

## Breached data

Email addresses, Names, Phone numbers, Usernames

## Free download Link

[DecoratingTheHouse breach Free Download Link](https://tinyurl.com/2b2k277t)