# BitcoinTalk database leak

## Description

2015-05-22

In May 2015, the Bitcoin forum <a href="https://www.cryptocoinsnews.com/bitcoin-exchange-btc-e-bitcointalk-forum-breaches-details-revealed/" target="_blank" rel="noopener">Bitcoin Talk was hacked</a> and over 500k unique email addresses were exposed. The attack led to the exposure of a raft of personal data including usernames, email and IP addresses, genders, birth dates, security questions and MD5 hashes of their answers plus hashes of the passwords themselves.

## Breached data

Dates of birth, Email addresses, Genders, IP addresses, Passwords, Security questions and answers, Usernames, Website activity

## Free download Link

[BitcoinTalk breach Free Download Link](https://tinyurl.com/2b2k277t)