# AerServ database leak

## Description

2018-04-01

In April 2018, the ad management platform known as <a href="https://www.aerserv.com/" target="_blank" rel="noopener">AerServ</a> suffered a data breach. Acquired by InMobi earlier in the year, the AerServ breach impacted over 66k unique email addresses and also included contact information and passwords stored as salted SHA-512 hashes. The data was publicly posted to Twitter later in 2018 after which InMobi was notified and advised they were aware of the incident.

## Breached data

Email addresses, Employers, Job titles, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[AerServ breach Free Download Link](https://tinyurl.com/2b2k277t)