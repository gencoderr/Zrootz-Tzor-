# Habibs database leak

## Description

2021-08-05

In August 2021, an allegation was made that the Brazilian fast food company &quot;Habib's&quot; had suffered a data breach <a href="https://cybernews.com/security/billions-passwords-credentials-leaked-mother-of-all-breaches/" target="_blank" rel="noopener">that was later redistributed as part of a larger corpus of data</a>. Upon thorough investigation, parent company Gennius concluded that the information in the breach was not related to any databases that hold their customers' personal information and had been misattributed to Habib's. The corpus of data contained 3.5M unique email addresses along with IP addresses, names, phone numbers, dates of birth and links to social media profiles.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Phone numbers, Social media profiles

## Free download Link

[Habibs breach Free Download Link](https://tinyurl.com/2b2k277t)