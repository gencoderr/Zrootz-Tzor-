# BattlefieldHeroes database leak

## Description

2011-06-26

In June 2011 as part of a final breached data dump, the hacker collective &quot;LulzSec&quot; <a href="http://www.rockpapershotgun.com/2011/06/26/lulzsec-over-release-battlefield-heroes-data" target="_blank" rel="noopener">obtained and released over half a million usernames and passwords from the game Battlefield Heroes</a>. The passwords were stored as MD5 hashes with no salt and many were easily converted back to their plain text versions.

## Breached data

Passwords, Usernames

## Free download Link

[BattlefieldHeroes breach Free Download Link](https://tinyurl.com/2b2k277t)