# Glofox database leak

## Description

2020-03-27

In March 2020, the Irish gym management software company <a href="https://www.irishtimes.com/business/technology/irish-start-up-glofox-investigates-possible-data-breach-1.4414837" target="_blank" rel="noopener">Glofox suffered a data breach which exposed 2.3M membership records</a>. The data included email addresses, names, phone numbers, genders, dates of birth and passwords stored as unsalted MD5 hashes.

## Breached data

Dates of birth, Email addresses, Genders, Names, Passwords, Phone numbers

## Free download Link

[Glofox breach Free Download Link](https://tinyurl.com/2b2k277t)