# EstanteVirtual database leak

## Description

2019-02-28

In February 2019, the Brazilian book store <a href="https://www.zdnet.com/article/round-4-hacker-returns-and-puts-26mil-user-records-for-sale-on-the-dark-web/" target="_blank" rel="noopener">Estante Virtual suffered a data breach that impacted 5.4M customers</a>. The exposed data included names, usernames, email and physical addresses, phone numbers, dates of birth and unsalted SHA-1 password hashes.

## Breached data

Dates of birth, Email addresses, Names, Passwords, Phone numbers, Physical addresses, Usernames

## Free download Link

[EstanteVirtual breach Free Download Link](https://tinyurl.com/2b2k277t)