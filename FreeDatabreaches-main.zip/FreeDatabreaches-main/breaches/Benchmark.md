# Benchmark database leak

## Description

2019-11-01

In November 2019, the Serbian technology news website <a href="https://forum.benchmark.rs/threads/benchmark-forum-kompromitovan.489760/" target="_blank" rel="noopener">Benchmark suffered a breach of its forum</a> that exposed 93k customer records. The breach exposed IP and email addresses, usernames and passwords stored as salted MD5 hashes. <a href="https://forum.benchmark.rs/threads/benchmark-forum-kompromitovan.489760/#post-6758095" target="_blank" rel="noopener">A forum administrator subsequently advised that the breach was due to the forum previously running on an outdated vBulletin instance</a>. The data was provided to HIBP by a source who requested it be attributed to &quot;ZAN @ BF&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Benchmark breach Free Download Link](https://tinyurl.com/2b2k277t)