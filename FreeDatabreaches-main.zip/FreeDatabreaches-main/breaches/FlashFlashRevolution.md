# FlashFlashRevolution database leak

## Description

2016-02-01

In February 2016, the music-based rhythm game known as <a href="http://www.flashflashrevolution.com" target="_blank" rel="noopener">Flash Flash Revolution</a> was hacked and 1.8M accounts were exposed. Along with email and IP addresses, the vBulletin forum also exposed salted MD5 password hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[FlashFlashRevolution breach Free Download Link](https://tinyurl.com/2b2k277t)