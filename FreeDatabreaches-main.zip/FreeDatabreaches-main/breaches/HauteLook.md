# HauteLook database leak

## Description

2018-08-07

In mid-2018, the fashion shopping site <a href="https://www.theregister.co.uk/2019/02/11/620_million_hacked_accounts_dark_web/" target="_blank" rel="noopener">HauteLook was among a raft of sites that were breached and their data then sold in early-2019</a>. The data included over 28 million unique email addresses alongside names, genders, dates of birth and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, Names, Passwords

## Free download Link

[HauteLook breach Free Download Link](https://tinyurl.com/2b2k277t)