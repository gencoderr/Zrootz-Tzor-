# Hub4Tech database leak

## Description

2017-01-01

On an unknown date in approximately 2017, the Indian training and assessment service known as <a href="https://www.forumcommunity.net/" target="_blank" rel="noopener">Hub4Tech</a> suffered a data breach via a SQL injection attack. The incident exposed almost 37k unique email addresses and passwords stored as unsalted MD5 hashes. No response was received from Hub4Tech when contacted about the incident.

## Breached data

Email addresses, Passwords

## Free download Link

[Hub4Tech breach Free Download Link](https://tinyurl.com/2b2k277t)