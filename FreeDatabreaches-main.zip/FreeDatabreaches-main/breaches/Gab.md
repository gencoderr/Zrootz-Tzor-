# Gab database leak

## Description

2021-02-26

In February 2021, the alt-tech social network service <a href="https://www.troyhunt.com/gab-has-been-breached/" target="_blank" rel="noopener">Gab suffered a data breach</a>. The incident exposed almost 70GB of data including 4M user accounts, a small number of private chat logs and a list of public groups and public posts made to the service. Only a small number of accounts included email addresses and / or passwords stored as bcrypt hashes with a total of 66.5k unique email addresses being exposed across the corpus of data.

## Breached data

Avatars, Email addresses, Names, Passwords, Private messages, Usernames

## Free download Link

[Gab breach Free Download Link](https://tinyurl.com/2b2k277t)