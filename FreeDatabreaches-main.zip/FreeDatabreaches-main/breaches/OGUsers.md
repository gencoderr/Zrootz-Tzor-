# OGUsers database leak

## Description

2018-12-26

In May 2019, the account hijacking and SIM swapping forum <a href="https://krebsonsecurity.com/2019/05/account-hijacking-forum-ogusers-hacked/" target="_blank" rel="noopener">OGusers suffered a data breach</a>. The breach exposed a database backup from December 2018 which was published on a rival hacking forum. There were 161k unique email addresses spread across 113k forum users and other tables in the database. The exposed data also included usernames, IP addresses, private messages and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Passwords, Private messages, Usernames

## Free download Link

[OGUsers breach Free Download Link](https://tinyurl.com/2b2k277t)