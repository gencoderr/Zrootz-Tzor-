# NetGalley database leak

## Description

2020-12-21

In December 2020, the book promotion site <a href="https://www.bleepingcomputer.com/news/security/netgalley-discloses-data-breach-after-website-was-hacked/" target="_blank" rel="noopener">NetGalley suffered a data breach</a>. The incident exposed 1.4 million unique email addresses alongside names, usernames, physical and IP addresses, phone numbers, dates of birth and passwords stored as salted SHA-1 hashes. The data was provided to HIBP by a source who requested it be attributed to pom@pompur.in.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses, Usernames

## Free download Link

[NetGalley breach Free Download Link](https://tinyurl.com/2b2k277t)