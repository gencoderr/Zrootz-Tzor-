# Hjedd database leak

## Description

2022-07-18

In July 2022, the Chinese adult website <a href="https://www.bitdefender.com.au/blog/hotforsecurity/leaky-platform-at-chinese-adult-platform-exposed-sensitive-info-of-14-million-users/" target="_blank" rel="noopener">Hjedd was found to be leaking more than 13M customer records which subsequently appeared on a popular hacking forum</a>. The exposed data included email and IP addresses, usernames and passwords stored as bcrypt hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Hjedd breach Free Download Link](https://tinyurl.com/2b2k277t)