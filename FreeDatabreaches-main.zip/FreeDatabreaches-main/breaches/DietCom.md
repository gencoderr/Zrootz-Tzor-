# DietCom database leak

## Description

2014-08-10

In August 2014, the diet and nutrition website <a href="https://diet.com/" target="_blank" rel="noopener">diet.com</a> suffered a data breach resulting in the exposure of 1.4 million unique user records dating back as far as 2004. The data contained email and IP addresses, usernames, plain text passwords and dietary information about the site members including eating habits, BMI and birth date. The site was previously reported as compromised on the <a href="https://vigilante.pw/" target="_blank" rel="noopener">Vigilante.pw</a> breached database directory.

## Breached data

Dates of birth, Eating habits, Email addresses, IP addresses, Names, Passwords, Physical attributes, Usernames

## Free download Link

[DietCom breach Free Download Link](https://tinyurl.com/2b2k277t)