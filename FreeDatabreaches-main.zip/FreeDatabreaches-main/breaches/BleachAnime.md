# BleachAnime database leak

## Description

2015-01-01

In 2015, the now defunct independent forum for the Bleach Anime series suffered a data breach that exposed 144k user records. The impacted data included usernames, email addresses and salted MD5 password hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[BleachAnime breach Free Download Link](https://tinyurl.com/2b2k277t)