# HackingTeam database leak

## Description

2015-07-06

In July 2015, the Italian security firm <a href="http://hackingteam.com" target="_blank" rel="noopener">Hacking Team</a> suffered a major data breach that resulted in over 400GB of their data being <a href="http://www.techtimes.com/articles/68204/20150711/hacking-team-hacked-400gb-data-dump-state-surveillance-exposes-dirty.htm" target="_blank" rel="noopener">posted online via a torrent</a>. The data searchable on &quot;Have I Been Pwned?&quot; is from 189GB worth of PST mail folders in the dump. The contents of the PST files is <a href="https://wikileaks.org/hackingteam/emails" target="_blank" rel="noopener">searchable on Wikileaks</a>.

## Breached data

Email addresses, Email messages

## Free download Link

[HackingTeam breach Free Download Link](https://tinyurl.com/2b2k277t)