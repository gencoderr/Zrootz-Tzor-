# OMGPOP database leak

## Description

2013-01-01

In approximately 2013, the maker of the Draw Something game <a href="https://www.cpomagazine.com/cyber-security/password-breach-of-game-developer-zynga-compromises-170-million-accounts/" target="_blank" rel="noopener">OMGPOP suffered a data breach</a>. Formerly known as i'minlikewithyou or iilwy and later purchased by Zynga, the breach exposed over 7M email address and plain text password pairs which were later leaked in 2019.

## Breached data

Email addresses, Passwords

## Free download Link

[OMGPOP breach Free Download Link](https://tinyurl.com/2b2k277t)