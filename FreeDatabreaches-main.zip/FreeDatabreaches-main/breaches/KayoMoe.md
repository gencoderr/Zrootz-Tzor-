# KayoMoe database leak

## Description

2018-09-11

In September 2018, a collection of almost 42 million email address and plain text password pairs was uploaded to the anonymous file sharing service <a href="https://kayo.moe/" target="_blank" rel="noopener">kayo.moe</a>. The operator of the service contacted HIBP to report the data which, upon further investigation, turned out to be a large credential stuffing list. For more information, read about <a href="https://www.troyhunt.com/the-42m-record-kayo-moe-credential-stuffing-data" target="_blank" rel="noopener">The 42M Record kayo.moe Credential Stuffing Data</a>.

## Breached data

Email addresses, Passwords

## Free download Link

[KayoMoe breach Free Download Link](https://tinyurl.com/2b2k277t)