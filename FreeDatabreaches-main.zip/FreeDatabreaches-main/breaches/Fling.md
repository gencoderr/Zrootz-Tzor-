# Fling database leak

## Description

2011-03-10

In 2011, the self-proclaimed &quot;World's Best Adult Social Network&quot; website known as Fling <a href="http://motherboard.vice.com/read/another-day-another-hack-passwords-and-sexual-desires-for-dating-site-fling" target="_blank" rel="noopener">was hacked and more than 40 million accounts obtained by the attacker</a>. The breached data included highly sensitive personal attributes such as sexual orientation and sexual interests as well as email addresses and passwords stored in plain text.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, IP addresses, Passwords, Phone numbers, Sexual fetishes, Sexual orientations, Usernames, Website activity

## Free download Link

[Fling breach Free Download Link](https://tinyurl.com/2b2k277t)