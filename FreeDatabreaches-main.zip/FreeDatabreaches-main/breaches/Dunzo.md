# Dunzo database leak

## Description

2020-06-19

In approximately June 2019, the Indian delivery service <a href="https://www.thenewsminute.com/article/dunzo-suffers-data-breach-launches-internal-investigation-128415" target="_blank" rel="noopener">Dunzo suffered a data breach</a>. Exposing 3.5 million unique email addresses, the Dunzo breach also included names, phone numbers and IP addresses which were all broadly distributed online via a hacking forum. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Device information, Email addresses, Geographic locations, IP addresses, Names, Phone numbers

## Free download Link

[Dunzo breach Free Download Link](https://tinyurl.com/2b2k277t)