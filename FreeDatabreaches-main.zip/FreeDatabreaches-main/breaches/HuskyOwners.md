# HuskyOwners database leak

## Description

2024-07-04

In July 2024, <a href="https://archive.is/lFPTL" target="_blank" rel="noopener">the Husky Owners forum website was defaced</a> and linked to a breach of user data containing 16k records. The exposed data included usernames, email addresses, dates of birth and time zones.

## Breached data

Dates of birth, Email addresses, Time zones, Usernames

## Free download Link

[HuskyOwners breach Free Download Link](https://tinyurl.com/2b2k277t)