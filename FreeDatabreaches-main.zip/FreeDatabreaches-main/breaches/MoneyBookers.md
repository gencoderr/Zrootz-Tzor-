# MoneyBookers database leak

## Description

2009-01-01

Sometime in 2009, the e-wallet service known as Money Bookers <a href="http://www.forbes.com/sites/thomasbrewster/2015/11/30/paysafe-optimal-neteller-moneybookers-gambling-cyberattacks-data-breach/" target="_blank" rel="noopener">suffered a data breach which exposed almost 4.5M customers</a>. Now called Skrill, the breach was not discovered until October 2015 and included names, email addresses, home addresses and IP addresses.

## Breached data

Dates of birth, Email addresses, IP addresses, Names, Phone numbers, Physical addresses

## Free download Link

[MoneyBookers breach Free Download Link](https://tinyurl.com/2b2k277t)