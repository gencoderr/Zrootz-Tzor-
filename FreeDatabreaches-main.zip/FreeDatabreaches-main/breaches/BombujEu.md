# BombujEu database leak

## Description

2018-12-07

In December 2018, the Slovak website for watching movies online for free <a href="https://www.bombuj.eu" target="_blank" rel="noopener">Bombuj.eu</a> suffered a data breach. The incident exposed over 575k unique email addresses and passwords stored as unsalted MD5 hashes. No response was received from Bombuj.eu when contacted about the incident.

## Breached data

Email addresses, Passwords

## Free download Link

[BombujEu breach Free Download Link](https://tinyurl.com/2b2k277t)