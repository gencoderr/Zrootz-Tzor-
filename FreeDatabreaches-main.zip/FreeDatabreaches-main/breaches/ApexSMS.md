# ApexSMS database leak

## Description

2019-04-15

In May 2019, <a href="https://techcrunch.com/2019/05/09/sms-spammers-doxxed/?guccounter=1" target="_blank" rel="noopener">news broke of a massive SMS spam operation known as &quot;ApexSMS&quot; which was discovered after a MongoDB instance of the same name was found exposed without a password</a>. The incident leaked over 80M records with 23M unique email addresses alongside names, phone numbers and carriers, geographic locations (state and country), genders and IP addresses.

## Breached data

Email addresses, Genders, Geographic locations, IP addresses, Names, Phone numbers, Telecommunications carrier

## Free download Link

[ApexSMS breach Free Download Link](https://tinyurl.com/2b2k277t)