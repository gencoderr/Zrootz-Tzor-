# OGUsers2021 database leak

## Description

2021-04-11

In April 2021, the account hijacking and SIM swapping forum <a href="https://www.bleepingcomputer.com/news/security/fourth-times-a-charm-ogusers-hacking-forum-hacked-again/" target="_blank" rel="noopener">OGusers suffered a data breach</a>, the fourth since December 2018. The breach was subsequently sold on a rival hacking forum and contained usernames, email and IP addresses and passwords stored as either salted MD5 or argon2 hashes. A total of 348k unique email addresses appeared in the breach.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[OGUsers2021 breach Free Download Link](https://tinyurl.com/2b2k277t)