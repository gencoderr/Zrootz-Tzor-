# Comcast database leak

## Description

2015-11-08

In November 2015, the US internet and cable TV provider Comcast <a href="http://www.ibtimes.co.uk/comcast-data-breach-590000-customer-passwords-go-sale-dark-web-1528026" target="_blank" rel="noopener">suffered a data breach that exposed 590k customer email addresses and plain text passwords</a>. A further 27k accounts appeared with home addresses with the entire data set being sold on underground forums.

## Breached data

Email addresses, Passwords, Physical addresses

## Free download Link

[Comcast breach Free Download Link](https://tinyurl.com/2b2k277t)