# Creative database leak

## Description

2018-05-01

In May 2018, <a href="http://forums.creative.com/" target="_blank" rel="noopener">the forum for Singaporean hardware company Creative Technology</a> suffered a data breach which resulted in the disclosure of 483k unique email addresses. Running on an old version of vBulletin, the breach also disclosed usernames, IP addresses and salted MD5 password hashes. After being notified of the incident, Creative permanently shut down the forum.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Creative breach Free Download Link](https://tinyurl.com/2b2k277t)