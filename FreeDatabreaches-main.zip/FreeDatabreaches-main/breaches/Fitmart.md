# Fitmart database leak

## Description

2021-10-01

In October 2021, <a href="https://www.mydealz.de/diskussion/datenleck-bei-fitmart-2214625" target="_blank" rel="noopener">data from the German fitness supplies store Fitmart was obtained and later redistributed online</a>. The data included 214k unique email addresses accompanied by plain text passwords, allegedly &quot;dehashed&quot; from the original stored version.

## Breached data

Email addresses, Passwords

## Free download Link

[Fitmart breach Free Download Link](https://tinyurl.com/2b2k277t)