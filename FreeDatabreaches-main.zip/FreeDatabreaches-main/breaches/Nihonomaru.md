# Nihonomaru database leak

## Description

2015-12-01

In late 2015, the anime community known as Nihonomaru had their vBulletin forum hacked and 1.7 million accounts exposed. The compromised data included email and IP addresses, usernames and salted hashes of passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Nihonomaru breach Free Download Link](https://tinyurl.com/2b2k277t)