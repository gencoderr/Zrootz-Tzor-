# ChrisLeong database leak

## Description

2024-08-10

In August 2024, <a href="https://x.com/DarkWebInformer/status/1822330521147376007" target="_blank" rel="noopener">the website of Master Chris Leong &quot;a leading Tit Tar practitioner in Malaysia&quot; suffered a data breach</a>. The incident exposed 27k unique email addresses along with names, physical addresses, dates of birth, genders, nationalities and in many cases, links to Facebook profiles. The company did not respond when contacted about the breach.

## Breached data

Dates of birth, Email addresses, Genders, Names, Nationalities, Phone numbers, Physical addresses, Purchases, Social media profiles

## Free download Link

[ChrisLeong breach Free Download Link](https://tinyurl.com/2b2k277t)