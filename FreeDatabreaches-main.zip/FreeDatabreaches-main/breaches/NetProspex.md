# NetProspex database leak

## Description

2016-09-01

In 2016, a list of over 33 million individuals in corporate America sourced from Dun & Bradstreet's NetProspex service <a href="https://www.troyhunt.com/weve-lost-control-of-our-personal-data-including-33m-netprospex-records" target="_blank" rel="noopener">was leaked online</a>. D&B believe the targeted marketing data was lost by a customer who purchased it from them. It contained extensive personal and corporate information including names, email addresses, job titles and general information about the employer.

## Breached data

Email addresses, Employers, Job titles, Names, Phone numbers, Physical addresses

## Free download Link

[NetProspex breach Free Download Link](https://tinyurl.com/2b2k277t)