# EverybodyEdits database leak

## Description

2019-03-23

In March 2019, the multiplayer platform game <a href="https://everybodyedits.wordpress.com/2019/03/28/everybody-edits-data-security-breach/" target="_blank" rel="noopener">Everybody Edits suffered a data breach</a>. The incident exposed 871k unique email addresses alongside usernames and IP addresses. The data was subsequently distributed online across a collection of files.

## Breached data

Email addresses, IP addresses, Usernames

## Free download Link

[EverybodyEdits breach Free Download Link](https://tinyurl.com/2b2k277t)