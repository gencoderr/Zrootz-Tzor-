# FlexBooker database leak

## Description

2021-12-23

In December 2021, the online booking service <a href="https://www.flexbooker.com/" target="_blank" rel="noopener">FlexBooker</a> suffered a data breach that exposed 3.7 million accounts. The data included email addresses, names, phone numbers and for a small number of accounts, password hashes and partial credit card data. FlexBooker has identified the breach as originating from a compromised account within their AWS infrastructure. The data was found being actively traded on a popular hacking forum and was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Email addresses, Names, Partial credit card data, Passwords, Phone numbers

## Free download Link

[FlexBooker breach Free Download Link](https://tinyurl.com/2b2k277t)