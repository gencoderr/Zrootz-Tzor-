# GamerzPlanet database leak

## Description

2015-10-23

In approximately October 2015, the online gaming forum known as <a href="http://gamerzplanet.net" target="_blank" rel="noopener">Gamerzplanet</a> was hacked and more than 1.2M accounts were exposed. The vBulletin forum included IP addresses and passwords stored as salted hashes using a weak implementation enabling many to be rapidly cracked.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GamerzPlanet breach Free Download Link](https://tinyurl.com/2b2k277t)