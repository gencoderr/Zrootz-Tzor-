# MastercardPricelessSpecials database leak

## Description

2019-08-20

In August 2019, <a href="https://www.spiegel.de/netzwelt/web/mastercard-datenleck-bei-bonusprogramm-a-1282697.html" target="_blank" rel="noopener">the German Mastercard bonus program &quot;Priceless Specials&quot; suffered a data breach</a>. Personal data on almost 90k program members was subsequently extensively circulated online and included names, email and IP addresses, phone numbers and partial credit card data. Following the incident, the program was subsequently suspended.

## Breached data

Email addresses, IP addresses, Names, Partial credit card data, Phone numbers, Salutations

## Free download Link

[MastercardPricelessSpecials breach Free Download Link](https://tinyurl.com/2b2k277t)