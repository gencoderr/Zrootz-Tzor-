# Mangatoon database leak

## Description

2022-05-13

In May 2022, the Hong Kong based Manga service <a href="https://mangatoon.mobi/" target="_blank" rel="noopener">Mangatoon</a> suffered a data breach that exposed 23M subscriber records. The breach exposed names, email addresses, genders, social media account identities, auth tokens from social logins and passwords stored as salted MD5 hashes. Mangatoon did not respond to multiple attempts to make contact regarding the breach.

## Breached data

Auth tokens, Avatars, Email addresses, Genders, Names, Passwords, Social media profiles, Usernames

## Free download Link

[Mangatoon breach Free Download Link](https://tinyurl.com/2b2k277t)