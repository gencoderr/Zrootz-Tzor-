# CapialEconomics database leak

## Description

2020-12-12

In December 2020, the economic research company <a href="https://securityaffairs.co/wordpress/113581/deep-web/capital-economics-data-leak.html" target="_blank" rel="noopener">Capital Economics suffered a data breach that exposed 263k customer records</a>. The exposed data included email and physical addresses, names, phone numbers, job titles and the employer of impacted customers.

## Breached data

Email addresses, Employers, Job titles, Names, Phone numbers, Physical addresses

## Free download Link

[CapialEconomics breach Free Download Link](https://tinyurl.com/2b2k277t)