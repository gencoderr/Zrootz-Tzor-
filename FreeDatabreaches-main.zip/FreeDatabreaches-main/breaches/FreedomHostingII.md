# FreedomHostingII database leak

## Description

2017-01-31

In January 2017, the free hidden service host <a href="http://www.theverge.com/2017/2/3/14497992/freedom-hosting-ii-hacked-anonymous-dark-web-tor" target="_blank" rel="noopener">Freedom Hosting II suffered a data breach</a>. The attack allegedly took down 20% of dark web sites running behind Tor hidden services with the attacker claiming that of the 10,613 impacted sites, more than 50% of the content was child pornography. The hack led to the exposure of MySQL databases for the sites which included a vast amount of information on the hidden services Freedom Hosting II was managing. The impacted data classes far exceeds those listed for the breach and differ between the thousands of impacted sites.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[FreedomHostingII breach Free Download Link](https://tinyurl.com/2b2k277t)