# Funimation database leak

## Description

2016-07-01

In July 2016, the anime site <a href="https://www.funimation.com/" target="_blank" rel="noopener">Funimation</a> suffered a data breach that impacted 2.5 million accounts. The data contained usernames, email addresses, dates of birth and salted SHA1 hashes of passwords.

## Breached data

Dates of birth, Email addresses, Passwords, Usernames

## Free download Link

[Funimation breach Free Download Link](https://tinyurl.com/2b2k277t)