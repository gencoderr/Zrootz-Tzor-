# HLTV database leak

## Description

2016-06-19

In June 2016, the &quot;home of competitive Counter Strike&quot; website <a href="http://www.hltv.org/news/18087-security-breach" target="_blank" rel="noopener">HLTV was hacked</a> and 611k accounts were exposed. The attack led to the exposure of names, usernames, email addresses and bcrypt hashes of passwords.

## Breached data

Email addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[HLTV breach Free Download Link](https://tinyurl.com/2b2k277t)