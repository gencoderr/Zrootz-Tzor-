# Elanic database leak

## Description

2018-01-01

In January 2020, the Indian fashion marketplace <a href="https://elanic.in/" target="_blank" rel="noopener">Elanic</a> had 2.8M records with 2.3M unique email addresses posted publicly to a popular hacking forum. Elanic confirmed that they had &quot;verified the data and it was pulled from one of our test servers where this data was exposed publicly&quot; and that the data was &quot;old&quot; (the hacking forum reported it as being from 2016-2018). When asked about disclosure to impacted customers, Elanic advised that they had &quot;decided to not have as such any communication and public disclosure&quot;. 

## Breached data

Email addresses, Geographic locations, Usernames

## Free download Link

[Elanic breach Free Download Link](https://tinyurl.com/2b2k277t)