# FurAffinity database leak

## Description

2016-05-17

In May 2016, the Fur Affinity website for people with an interest in anthropomorphic animal characters (also known as "furries") <a href="http://motherboard.vice.com/read/another-day-another-hack-furry-site-hacked-content-deleted" target="_blank" rel="noopener">was hacked</a>. The attack exposed 1.2M email addresses (many accounts had a different "first" and "last" email against them) and hashed passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[FurAffinity breach Free Download Link](https://tinyurl.com/2b2k277t)