# MinecraftWorldMap database leak

## Description

2016-01-15

In approximately January 2016, the Minecraft World Map site designed for sharing maps created for the game was hacked and over 71k user accounts were exposed. The data included usernames, email and IP addresses along with salted and hashed passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MinecraftWorldMap breach Free Download Link](https://tinyurl.com/2b2k277t)