# Emotet database leak

## Description

2021-01-27

In January 2021, <a href="https://www.troyhunt.com/data-from-the-emotet-malware-is-now-searchable-in-have-i-been-pwned-courtesy-of-the-fbi-and-nhtcu" target="_blank" rel="noopener">the FBI in partnership with the Dutch NHTCU, German BKA and other international law enforcement agencies brought down the world's most dangerous malware: Emotet</a>. The agencies obtained data collected by the malware and provided impacted email addresses to HIBP so that impacted individuals and domain owners could assess their exposure. <a href="https://www.troyhunt.com/data-from-the-emotet-malware-is-now-searchable-in-have-i-been-pwned-courtesy-of-the-fbi-and-nhtcu" target="_blank" rel="noopener">Read more about the takedown and recommended actions</a>.

## Breached data

Email addresses, Passwords

## Free download Link

[Emotet breach Free Download Link](https://tinyurl.com/2b2k277t)