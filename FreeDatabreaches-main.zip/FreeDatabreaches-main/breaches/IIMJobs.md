# IIMJobs database leak

## Description

2018-12-31

In December 2018, the Indian job portal <a href="https://www.hackread.com/indian-job-portal-iimjobs-hacked-database-leaked/" target="_blank" rel="noopener">IIMJobs suffered a data breach that exposed 4.1 million unique email addresses</a>. The data also included names, phone numbers, geographic locations, dates of birth, job titles, job applications and cover letters plus passwords stored as unsalted MD5 hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, Geographic locations, IP addresses, Job applications, Job titles, Names, Passwords, Phone numbers

## Free download Link

[IIMJobs breach Free Download Link](https://tinyurl.com/2b2k277t)