# ABFRL database leak

## Description

2021-12-01

In December 2021, Indian retailer <a href="https://restoreprivacy.com/aditya-birla-fashion-and-retail-ltd-abfrl-hack-2022/" target="_blank" rel="noopener">Aditya Birla Fashion and Retail Ltd was breached and ransomed</a>. The ransom demand was allegedly rejected and data containing 5.4M unique email addresses was subsequently dumped publicly on a popular hacking forum the next month. The data contained extensive personal customer information including names, phone numbers, physical addresses, DoBs, order histories and passwords stored as MD5 hashes. Employee data was also dumped publicly and included salary grades, marital statuses and religions. The data was provided to HIBP by a source who requested it be attributed to &quot;white_peacock@riseup.net&quot;.

## Breached data

Email addresses, Genders, Income levels, Job titles, Marital statuses, Names, Passwords, Phone numbers, Physical addresses, Purchases, Religions, Salutations

## Free download Link

[ABFRL breach Free Download Link](https://tinyurl.com/2b2k277t)