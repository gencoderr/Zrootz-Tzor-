# JustDate database leak

## Description

2016-09-29

An alleged breach of the dating website <a href="http://www.justdate.com/" target="_blank" rel="noopener">Justdate.com</a> began circulating in approximately September 2016. Comprised of over 24 million records, the data contained various personal attributes such as email addresses, dates of birth and physical locations. However, upon verification with HIBP subscribers, only a fraction of the data was found to be accurate and no account owners recalled using the Justdate.com service. This breach has consequently been flagged as <a href="https://www.troyhunt.com/introducing-fabricated-data-breaches-to-have-i-been-pwned" target="_blank" rel="noopener">fabricated</a>; it's highly unlikely the data was sourced from Justdate.com.

## Breached data

Dates of birth, Email addresses, Geographic locations, Names

## Free download Link

[JustDate breach Free Download Link](https://tinyurl.com/2b2k277t)