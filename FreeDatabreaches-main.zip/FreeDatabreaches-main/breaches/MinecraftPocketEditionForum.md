# MinecraftPocketEditionForum database leak

## Description

2015-05-24

In May 2015, the <a href="http://www.databreaches.net/minecraft-pocket-edition-forum-hacked-dumped/" target="_blank" rel="noopener">Minecraft Pocket Edition forum was hacked</a> and over 16k accounts were dumped public. Allegedly hacked by <a href="https://twitter.com/rmsg0d" target="_blank" rel="noopener">@rmsg0d</a>, the forum data included numerous personal pieces of data for each user. The forum has subsequently been decommissioned.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MinecraftPocketEditionForum breach Free Download Link](https://tinyurl.com/2b2k277t)