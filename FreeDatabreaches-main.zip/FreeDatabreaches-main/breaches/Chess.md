# Chess database leak

## Description

2023-11-08

In November 2023, <a href="https://www.hackread.com/hacker-leaks-scraped-chess-com-user-records/" target="_blank" rel="noopener">over 800k user records were scraped from the Chess website and posted to a popular hacking forum</a>. The data included email address, name, username and the geographic location of the user.

## Breached data

Email addresses, Geographic locations, Names, Usernames

## Free download Link

[Chess breach Free Download Link](https://tinyurl.com/2b2k277t)