# BiohackMe database leak

## Description

2016-12-02

In December 2016, the forum for the biohacking website <a href="https://forum.biohack.me/index.php?p=/discussion/2101/critical-website-server-compromised-read-this-action-needed" target="_blank" rel="noopener">Biohack.me suffered a data breach</a> that exposed 3.4k accounts. The data included usernames, email addresses and hashed passwords along with the private messages of forum members. The data was self-submitted to HIBP by the Biohack.me operators.

## Breached data

Email addresses, Passwords, Private messages, Usernames

## Free download Link

[BiohackMe breach Free Download Link](https://tinyurl.com/2b2k277t)