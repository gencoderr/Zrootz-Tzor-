# Neopets database leak

## Description

2013-05-05

In May 2016, <a href="http://motherboard.vice.com/read/neopets-hack-another-day-another-hack-tens-of-millions-of-neopets-accounts" target="_blank" rel="noopener">a set of breached data originating from the virtual pet website &quot;Neopets&quot; was found being traded online</a>. Allegedly hacked &quot;several years earlier&quot;, the data contains sensitive personal information including birthdates, genders and names as well as almost 27 million unique email addresses. Passwords were stored in plain text and IP addresses were also present in the breach.

## Breached data

Dates of birth, Email addresses, Genders, Geographic locations, IP addresses, Names, Passwords, Usernames

## Free download Link

[Neopets breach Free Download Link](https://tinyurl.com/2b2k277t)