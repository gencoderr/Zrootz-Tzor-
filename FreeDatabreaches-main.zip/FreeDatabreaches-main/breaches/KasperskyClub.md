# KasperskyClub database leak

## Description

2024-03-24

In March 2024, the independent fan forum <a href="https://www.hackread.com/57000-kaspersky-fan-club-forum-data-breach/" target="_blank" rel="noopener">Kaspersky Club suffered a data breach</a>. The incident exposed 56k unique email addresses alongside usernames, IP addresses and passwords stored as either MD5 or bcrypt hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[KasperskyClub breach Free Download Link](https://tinyurl.com/2b2k277t)