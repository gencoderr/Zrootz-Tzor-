# NapsGear database leak

## Description

2015-10-21

In October 2015, the anabolic steroids retailer <a href="https://thinksteroids.com/community/threads/warning-naps-customer-database-compromised.134375549/" target="_blank" rel="noopener">NapsGear suffered a data breach</a>. An extensive amount of personal information on 287k customers was exposed including email addresses, names, addresses, phone numbers, purchase histories and salted MD5 password hashes.

## Breached data

Dates of birth, Email addresses, Genders, Names, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[NapsGear breach Free Download Link](https://tinyurl.com/2b2k277t)