# LBB database leak

## Description

2019-02-14

In August 2022, customer data of <a href="https://lbb.in/" target="_blank" rel="noopener">the Indian shopping site &quot;LBB&quot; (Little Black Book)</a> was posted to a popular hacking forum. The data contained over 3M records with 39k unique email addresses alongside IP and physical addresses, names and device information with the most recent data dating back to early 2019. LBB advised they believe the data was exposed by a third party service and whilst it contained information they retain on their customers, it had also been enriched with additional data attributes.

## Breached data

Browser user agent details, Email addresses, IP addresses, Names, Physical addresses

## Free download Link

[LBB breach Free Download Link](https://tinyurl.com/2b2k277t)