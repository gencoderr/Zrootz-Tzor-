# Jefit database leak

## Description

2020-08-11

In August 2020, the workout tracking app <a href="https://www.jefit.com/jefit-news-product-updates/jefit-data-incident-public-announcement" target="_blank" rel="noopener">Jefit suffered a data breach</a>. The data was subsequently sold within the hacking community and included over 9 million email and IP addresses, usernames and passwords stored as either vBulletin or argon2 hashes. Several million cracked passwords later appeared in broad circulation.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Jefit breach Free Download Link](https://tinyurl.com/2b2k277t)