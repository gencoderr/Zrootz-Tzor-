# GetRevengeOnYourEx database leak

## Description

2022-09-09

In September 2022, the revenge website <a href="https://getrevengeonyourex.com/" target="_blank" rel="noopener">Get Revenge On Your Ex</a> suffered a data breach that exposed almost 80k unique email addresses. The data spanned both customers and victims including names, IP and physical addresses, phone numbers, purchase histories and plain text passwords. The data was subsequently shared on a public hacking forum, Get Revenge On Your Ex did not reply when contacted.

## Breached data

Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[GetRevengeOnYourEx breach Free Download Link](https://tinyurl.com/2b2k277t)