# DuelingNetwork database leak

## Description

2017-03-29

In March 2017, the Flash game based on the Yu-Gi-Oh trading card game <a href="https://www.vice.com/amp/en_us/article/783dkz/hacker-steals-millions-of-accounts-from-yu-gi-oh-fan-project-dueling-network" target="_blank" rel="noopener">Dueling Network suffered a data breach</a>. The site itself was taken offline in 2016 due to a cease-and-desist order but the forum remained online for another year. The data breach exposed usernames, IP and email addresses and passwords stored as MD5 hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;burger vault&quot;.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[DuelingNetwork breach Free Download Link](https://tinyurl.com/2b2k277t)