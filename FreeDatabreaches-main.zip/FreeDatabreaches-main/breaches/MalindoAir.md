# MalindoAir database leak

## Description

2019-03-01

In early 2019, the Malaysian airline <a href="https://vpnoverview.com/news/malindo-air-data-leak-reveals-info-of-60-million-passengers/" target="_blank" rel="noopener">Malindo Air suffered a data breach that exposed tens of millions of customer records</a>. Containing 4.3M unique email addresses, the breach also exposed extensive personal information including names, dates of birth, genders, physical addresses, phone numbers and passport details. The data was later extensively shared on popular hacking forums.

## Breached data

Dates of birth, Email addresses, Genders, Loyalty program details, Names, Nationalities, Passport numbers, Phone numbers, Physical addresses, Salutations

## Free download Link

[MalindoAir breach Free Download Link](https://tinyurl.com/2b2k277t)