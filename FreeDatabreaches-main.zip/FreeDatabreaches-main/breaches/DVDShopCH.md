# DVDShopCH database leak

## Description

2017-12-05

In December 2017, the online Swiss DVD store known as <a href="https://www.melani.admin.ch/melani/de/home/dokumentation/newsletter/passwoerter-von-70000-e-mail-konten-im-umlauf.html" target="_blank" rel="noopener">dvd-shop.ch suffered a data breach</a>. The incident led to the exposure of 68k email addresses and plain text passwords. The site has since been updated to indicate that it is currently closed.

## Breached data

Email addresses, Passwords

## Free download Link

[DVDShopCH breach Free Download Link](https://tinyurl.com/2b2k277t)