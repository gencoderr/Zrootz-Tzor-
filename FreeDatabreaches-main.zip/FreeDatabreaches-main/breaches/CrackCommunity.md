# CrackCommunity database leak

## Description

2013-09-09

In late 2013, the <a href="http://crackcommunity.com" target="_blank" rel="noopener">Crack Community</a> forum specialising in cracks for games was compromised and over 19k accounts published online. Built on the MyBB forum platform, the compromised data included email addresses, IP addresses and salted MD5 passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[CrackCommunity breach Free Download Link](https://tinyurl.com/2b2k277t)