# MPGH database leak

## Description

2015-10-22

In October 2015, the multiplayer game hacking website <a href="http://www.mpgh.net">MPGH was hacked</a> and 3.1 million user accounts disclosed. The vBulletin forum breach contained usernames, email addresses, IP addresses and salted hashes of passwords.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MPGH breach Free Download Link](https://tinyurl.com/2b2k277t)