# CafeMom database leak

## Description

2014-04-10

In 2014, the social network for mothers <a href="http://www.cafemom.com" target="_blank" rel="noopener">CafeMom</a> suffered a data breach. The data surfaced alongside a number of other historical breaches including Kickstarter, Bitly and Disqus and contained 2.6 million email addresses and plain text passwords.

## Breached data

Email addresses, Passwords

## Free download Link

[CafeMom breach Free Download Link](https://tinyurl.com/2b2k277t)