# Brazzers database leak

## Description

2013-04-01

In April 2013, the adult website known as <a href="https://motherboard.vice.com/read/nearly-800000-brazzers-porn-site-accounts-exposed-in-forum-hack" target="_blank" rel="noopener">Brazzers was hacked</a> and 790k accounts were exposed publicly. Each record included a username, email address and password stored in plain text. The breach was brought to light by the <a href="https://vigilante.pw" target="_blank" rel="noopener">Vigilante.pw</a> data breach reporting site in September 2016.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Brazzers breach Free Download Link](https://tinyurl.com/2b2k277t)