# Locally database leak

## Description

2022-10-01

In October 2022, &quot;The Industry's Leading Online-to-Offline Shopping Solution&quot; <a href="https://twitter.com/troyhunt/status/1677855117960441858" target="_blank" rel="noopener">Locally suffered a data breach</a>. Whilst Locally acknowledged the breach privately, it's unknown whether impacted customers were subsequently notified of the incident which exposed over 362k names, phone numbers, email and physical addresses, purchases, credit card type and last four digits and bcrypt password hashes.

## Breached data

Email addresses, Partial credit card data, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[Locally breach Free Download Link](https://tinyurl.com/2b2k277t)