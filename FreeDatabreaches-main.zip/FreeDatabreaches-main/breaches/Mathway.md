# Mathway database leak

## Description

2020-01-13

In January 2020, the math solving website <a href="https://www.zdnet.com/article/25-million-user-records-leak-online-from-popular-math-app-mathway/" target="_blank" rel="noopener">Mathway suffered a data breach that exposed over 25M records</a>. The data was subsequently sold on a dark web marketplace and included names, Google and Facebook IDs, email addresses and salted password hashes.

## Breached data

Device information, Email addresses, Names, Passwords, Social media profiles

## Free download Link

[Mathway breach Free Download Link](https://tinyurl.com/2b2k277t)