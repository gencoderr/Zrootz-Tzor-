# MoreleNet database leak

## Description

2018-10-10

In October 2018, the Polish e-commerce website <a href="https://niebezpiecznik.pl/post/morele-potwierdza-ze-wykradziono-dane-klientow/" target="_blank" rel="noopener">Morele.net suffered a data breach</a>. The incident exposed almost 2.5 million unique email addresses alongside phone numbers, names and passwords stored as md5crypt hashes.

## Breached data

Email addresses, Names, Passwords, Phone numbers

## Free download Link

[MoreleNet breach Free Download Link](https://tinyurl.com/2b2k277t)