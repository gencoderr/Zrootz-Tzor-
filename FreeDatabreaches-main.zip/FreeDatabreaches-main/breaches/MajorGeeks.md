# MajorGeeks database leak

## Description

2015-11-15

In November 2015, almost 270k accounts from the <a href="http://www.majorgeeks.com" target="_blank" rel="noopener">MajorGeeks</a> support forum were breached. The accounts were being actively sold and traded online and included email addresses, salted password hashes and IP addresses.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MajorGeeks breach Free Download Link](https://tinyurl.com/2b2k277t)