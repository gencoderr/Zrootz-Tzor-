# BulgarianNationalRevenueAgency database leak

## Description

2019-07-15

In July 2019, <a href="https://thenextweb.com/security/2019/07/16/bulgaria-tax-agency-data-leak-hack/" target="_blank" rel="noopener">a massive data breach of the Bulgarian National Revenue Agency began circulating with data on 5 million people</a>. Allegedly obtained in June, the data was broadly shared online and included taxation information alongside names, phone numbers, physical addresses and 471 thousand unique email addresses. The breach is said to have affected &quot;nearly all adults in Bulgaria&quot;.

## Breached data

Email addresses, Names, Phone numbers, Physical addresses, Taxation records

## Free download Link

[BulgarianNationalRevenueAgency breach Free Download Link](https://tinyurl.com/2b2k277t)