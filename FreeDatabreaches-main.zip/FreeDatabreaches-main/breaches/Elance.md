# Elance database leak

## Description

2009-01-01

Sometime in 2009, staffing platform <a href="http://www.ibtimes.co.uk/elance-data-breach-hacker-leaks-1-3-million-accounts-staffing-platform-1605368" target="_blank" rel="noopener">Elance suffered a data breach that impacted 1.3 million accounts</a>. Appearing online 8 years later, the data contained usernames, email addresses, phone numbers and SHA1 hashes of passwords, amongst other personal data.

## Breached data

Email addresses, Employers, Geographic locations, Passwords, Phone numbers, Usernames

## Free download Link

[Elance breach Free Download Link](https://tinyurl.com/2b2k277t)