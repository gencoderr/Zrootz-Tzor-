# 000webhost database leak

## Description

2015-03-01

In approximately March 2015, the free web hosting provider <a href="http://www.troyhunt.com/2015/10/breaches-traders-plain-text-passwords.html" target="_blank" rel="noopener">000webhost suffered a major data breach</a> that exposed almost 15 million customer records. The data was sold and traded before 000webhost was alerted in October. The breach included names, email addresses and plain text passwords.

## Breached data

Email addresses, IP addresses, Names, Passwords

## Free download Link

[000webhost breach Free Download Link](https://tinyurl.com/2b2k277t)