# Animoto database leak

## Description

2018-07-10

In July 2018, the cloud-based video making service <a href="https://techcrunch.com/2018/08/20/animoto-hack-exposes-personal-information-geolocation-data/" target="_blank" rel="noopener">Animoto suffered a data breach</a>. The breach exposed 22 million unique email addresses alongside names, dates of birth, country of origin and salted password hashes. The data was provided to HIBP by a source who requested it be attributed to &quot;JimScott.Sec@protonmail.com&quot;.

## Breached data

Dates of birth, Email addresses, Geographic locations, Names, Passwords

## Free download Link

[Animoto breach Free Download Link](https://tinyurl.com/2b2k277t)