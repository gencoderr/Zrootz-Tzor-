# CutoutPro database leak

## Description

2024-02-26

In February 2024, the AI-powered visual design platform <a href="https://twitter.com/H4ckManac/status/1762387053889675658" target="_blank" rel="noopener">Cutout.Pro suffered a data breach that exposed 20M records</a>. The data included email and IP addresses, names and salted MD5 password hashes which were subsequently broadly distributed on a popular hacking forum and Telegram channels.

## Breached data

Email addresses, IP addresses, Names, Passwords

## Free download Link

[CutoutPro breach Free Download Link](https://tinyurl.com/2b2k277t)