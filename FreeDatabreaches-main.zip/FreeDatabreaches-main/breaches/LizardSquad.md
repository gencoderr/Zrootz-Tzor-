# LizardSquad database leak

## Description

2015-01-16

In January 2015, the hacker collective known as &quot;Lizard Squad&quot; created a DDoS service by the name of &quot;Lizard Stresser&quot; which could be procured to mount attacks against online targets. Shortly thereafter, the service <a href="https://krebsonsecurity.com/2015/01/another-lizard-arrested-lizard-lair-hacked/">suffered a data breach</a> which resulted in the public disclosure of over 13k user accounts including passwords stored in plain text.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[LizardSquad breach Free Download Link](https://tinyurl.com/2b2k277t)