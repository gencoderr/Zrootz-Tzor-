# Catho database leak

## Description

2020-03-01

In approximately March 2020, the Brazilian recruitment website <a href="https://www.binarydefense.com/threat_watch/shinyhunters-serving-up-21-new-compromised-databases/" target="_blank" rel="noopener">Catho was compromised and subsequently appeared alongside 20 other breached websites</a> listed for sale on a dark web marketplace. The breach included almost 11 million records with 1.2 million unique email addresses. Names, usernames and plain text passwords were also exposed. The data was provided to HIBP by <a href="https://breachbase.pw/" target="_blank" rel="noopener">breachbase.pw</a>.

## Breached data

Email addresses, Names, Passwords, Usernames

## Free download Link

[Catho breach Free Download Link](https://tinyurl.com/2b2k277t)