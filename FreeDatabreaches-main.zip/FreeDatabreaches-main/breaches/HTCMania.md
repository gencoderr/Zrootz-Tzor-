# HTCMania database leak

## Description

2020-01-04

In January 2020, the Spanish mobile phone forum <a href="https://www.htcmania.com" target="_blank" rel="noopener">HTC Mania</a> suffered a data breach of the vBulletin based site. The incident exposed 1.5M member email addresses, usernames, IP addresses, dates of birth and salted MD5 password hashes and password histories. Data from the breach was subsequently redistributed on popular hacking websites.

## Breached data

Dates of birth, Email addresses, Historical passwords, IP addresses, Passwords, Usernames

## Free download Link

[HTCMania breach Free Download Link](https://tinyurl.com/2b2k277t)