# MangaDex database leak

## Description

2021-03-22

In March 2021, the manga fan site <a href="https://portswigger.net/daily-swig/mangadex-website-taken-offline-following-cyber-attack-data-breach" target="_blank" rel="noopener">MangaDex suffered a data breach</a> that resulted in the exposure of almost 3 million subscribers. The data included email and IP addresses, usernames and passwords stored as bcrypt hashes. The data was subsequently circulated within hacking groups.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[MangaDex breach Free Download Link](https://tinyurl.com/2b2k277t)