# CannabisForum database leak

## Description

2014-02-05

In February 2014, the vBulletin forum for the Marijuana site cannabis.com was breached and <a href="https://www.google.com/search?q=%22cannabisforum.tar%22" target="_blank" rel="noopener">leaked publicly</a>. Whilst there has been no public attribution of the breach, the leaked data included over 227k accounts and nearly 10k private messages between users of the forum.

## Breached data

Dates of birth, Email addresses, Geographic locations, Historical passwords, Instant messenger identities, IP addresses, Passwords, Private messages, Usernames, Website activity

## Free download Link

[CannabisForum breach Free Download Link](https://tinyurl.com/2b2k277t)