# IDCGames database leak

## Description

2021-03-15

In March 2021, <a href="https://socradar.io/the-week-in-dark-web-19-march-2021-us-law-firms-on-target/" target="_blank" rel="noopener">4 million records sourced from IDC Games were shared on a public hacking forum</a>. The data included usernames, email addresses and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[IDCGames breach Free Download Link](https://tinyurl.com/2b2k277t)