# MortalOnline database leak

## Description

2018-06-17

In June 2018, the massively multiplayer online role-playing game (MMORPG) <a href="https://account.mortalonline.com/breach.html" target="_blank" rel="noopener">Mortal Online suffered a data breach</a>. A file containing 570k email addresses and cracked passwords was subsequently distributed online. A larger more complete file containing 607k email addresses with original unsalted MD5 password hashes along with names, usernames and physical addresses was later provided and the original breach in HIBP was updated accordingly. The data was provided to HIBP by whitehat security researcher and data analyst Adam Davies.

## Breached data

Email addresses, Names, Passwords, Physical addresses, Usernames

## Free download Link

[MortalOnline breach Free Download Link](https://tinyurl.com/2b2k277t)