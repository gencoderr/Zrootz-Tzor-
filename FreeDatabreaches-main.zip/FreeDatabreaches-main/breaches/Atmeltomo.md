# Atmeltomo database leak

## Description

2021-04-16

In April 2021, &quot;Japan's largest e-mail friend search site&quot; <a href="https://socradar.io/the-week-in-dark-web-29-august-2022-access-sales-and-data-leaks/" target="_blank" rel="noopener">Atmeltomo suffered a data breach that was later sold on a popular hacking forum</a>. The breach exposed 1.3M records with 580k unique email addresses along with usernames, IP addresses and unsalted MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Atmeltomo breach Free Download Link](https://tinyurl.com/2b2k277t)