# LimeVPN database leak

## Description

2020-10-08

In October 2020, the VPN provider <a href="https://threatpost.com/hacked-data-limevpn-dark-web/167492/" target="_blank" rel="noopener">LimeVPN suffered a data breach that exposed the personal information of tens of thousands of customers</a>. The data included email, IP and physical addresses, names, phone numbers, purchase histories and passwords stored as salted MD5 hashes.

## Breached data

Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[LimeVPN breach Free Download Link](https://tinyurl.com/2b2k277t)