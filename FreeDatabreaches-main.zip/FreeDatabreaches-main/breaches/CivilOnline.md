# CivilOnline database leak

## Description

2011-07-10

In mid-2011, data was allegedly obtained from the Chinese engineering website known as <a href="http://www.co188.com/" target="_blank" rel="noopener">Civil Online</a> and contained 7.8M accounts. Whilst there is evidence that the data is legitimate, due to the difficulty of emphatically verifying the Chinese breach it has been flagged as &quot;unverified&quot;. The data in the breach contains email and IP addresses, user names and MD5 password hashes. <a href="https://www.troyhunt.com/handling-chinese-data-breaches-in-have-i-been-pwned/" target="_blank" rel="noopener">Read more about Chinese data breaches in Have I Been Pwned.</a>

## Breached data

Email addresses, IP addresses, Passwords, Usernames, Website activity

## Free download Link

[CivilOnline breach Free Download Link](https://tinyurl.com/2b2k277t)