# Mac-Torrents database leak

## Description

2015-10-31

In October 2015, the torrent site <a href="http://www.mac-torrents.com" target="_blank" rel="noopener">Mac-Torrents</a> was hacked and almost 94k usernames, email addresses and passwords were leaked. The passwords were hashed with MD5 and no salt.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[Mac-Torrents breach Free Download Link](https://tinyurl.com/2b2k277t)