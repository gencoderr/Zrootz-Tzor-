# Lazada database leak

## Description

2020-07-30

In October 2020, <a href="https://www.bleepingcomputer.com/news/security/over-1m-lazada-redmart-accounts-sold-online-after-data-breach/" target="_blank" rel="noopener">news broke of Lazada RedMart data breach</a> containing records as recent as July 2020 and being sold via an online marketplace. In all, the data contained 1.1 million customer email addresses alongside names, phone numbers, physical addresses, partial credit card numbers and passwords stored as SHA-1 hashes.

## Breached data

Email addresses, Names, Partial credit card data, Passwords, Phone numbers, Physical addresses

## Free download Link

[Lazada breach Free Download Link](https://tinyurl.com/2b2k277t)