# LaPosteMobile database leak

## Description

2022-07-04

In July 2022, the French telecommunications company <a href="https://securityaffairs.co/wordpress/133080/cyber-crime/la-poste-mobile-ransomware.html" target="_blank" rel="noopener">La Poste Mobile was the target of an attack by the LockBit ransomware</a> which resulted in company data being published publicly. The impacted data included 533k unique email addresses along with names, physical addresses, phone numbers, dates of births, genders and banking information. 10 days after the attack, the La Poste Mobile website remained offline.

## Breached data

Bank account numbers, Dates of birth, Email addresses, Genders, Names, Phone numbers, Physical addresses

## Free download Link

[LaPosteMobile breach Free Download Link](https://tinyurl.com/2b2k277t)