# Dangdang database leak

## Description

2011-06-01

In 2011, the Chinese e-commerce site <a href="https://www.marbridgeconsulting.com/marbridgedaily/2011-12-29/article/52564/rumor_dangdang_alipay_suffer_data_breaches" target="_blank" rel="noopener">Dangdang suffered a data breach</a>. The incident exposed over 4.8 million unique email addresses which were subsequently traded online over the ensuing years.

## Breached data

Email addresses

## Free download Link

[Dangdang breach Free Download Link](https://tinyurl.com/2b2k277t)