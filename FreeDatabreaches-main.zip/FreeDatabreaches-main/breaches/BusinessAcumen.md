# BusinessAcumen database leak

## Description

2014-04-25

In April 2014, the Australian "Business Acumen Magazine" website was <a href="http://1337mir.com/cracked/2014/04/businessacumen-biz-hacked-26000-user-password-leaked/" target="_blank" rel="noopener">hacked by an attacker known as 1337MiR</a>. The breach resulted in over 26,000 accounts being exposed including usernames, email addresses and password stored with a weak cryptographic hashing algorithm (MD5 with no salt).

## Breached data

Email addresses, Names, Passwords, Usernames, Website activity

## Free download Link

[BusinessAcumen breach Free Download Link](https://tinyurl.com/2b2k277t)