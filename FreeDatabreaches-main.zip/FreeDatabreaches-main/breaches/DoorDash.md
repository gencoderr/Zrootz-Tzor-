# DoorDash database leak

## Description

2022-08-02

In August 2022, the food ordering and delivery service <a href="https://mashable.com/article/doordash-hack-customer-details-exposed" target="_blank" rel="noopener">DoorDash disclosed a data breach that impacted a portion of their customers</a>. DoorDash attributed the breach to an unnamed &quot;third-party vendor&quot; they stated was the victim of a phishing campaign. The incident exposed 367k unique personal email addresses alongside names, post codes and partial card data, namely the brand, expiry data and last four digits of the card.

## Breached data

Email addresses, Geographic locations, Names, Partial credit card data

## Free download Link

[DoorDash breach Free Download Link](https://tinyurl.com/2b2k277t)