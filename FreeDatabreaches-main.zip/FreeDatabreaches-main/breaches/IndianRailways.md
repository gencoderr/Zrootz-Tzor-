# IndianRailways database leak

## Description

2019-10-28

In November 2019, <a href="https://medium.com/dvuln/why-you-should-choo-choo-choose-to-have-a-vulnerability-disclosure-policy-2m-accounts-exposed-7cd7eaec4da5" target="_blank" rel="noopener">the website for Indian Rail left more than 2M records exposed on an unprotected Firebase database instance</a>. The exposed data included 583k unique email addresses alongside usernames and passwords stored in plain text.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[IndianRailways breach Free Download Link](https://tinyurl.com/2b2k277t)