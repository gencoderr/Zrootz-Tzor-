# FashionFantasyGame database leak

## Description

2016-12-01

In late 2016, the fashion gaming website <a href="http://www.zdnet.com/article/amid-data-breach-responsibility-thrown-to-the-wind/" target="_blank" rel="noopener">Fashion Fantasy Game suffered a data breach</a>. The incident exposed 2.3 million unique user accounts and corresponding MD5 password hashes with no salt. The data was contributed to Have I Been Pwned courtesy of rip@creep.im.

## Breached data

Email addresses, Passwords

## Free download Link

[FashionFantasyGame breach Free Download Link](https://tinyurl.com/2b2k277t)