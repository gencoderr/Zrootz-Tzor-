# KomplettFritid database leak

## Description

2021-02-01

In January 2023, <a href="https://www.digi.no/artikler/selger-datalekkasje-med-140-000-berorte-kunder-fra-lars-monsens-nettbutikk/525070" target="_blank" rel="noopener">the online Norwegian store KomplettFritid was reported as having had a data breach dating back to February 2021</a>. The incident exposed 140k customer records including physical, email and IP addresses, names, phone numbers and passwords. Most passwords were stored as bcrypt hashes with a small number appearing in plain text.

## Breached data

Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[KomplettFritid breach Free Download Link](https://tinyurl.com/2b2k277t)