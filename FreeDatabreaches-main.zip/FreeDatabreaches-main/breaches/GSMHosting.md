# GSMHosting database leak

## Description

2016-08-01

In August 2016, <a href="https://www.hackread.com/vbulletin-forums-hacked-accounts-sold-on-dark-web/" target="_blank" rel="noopener">breached data from the vBulletin forum for GSM-Hosting appeared for sale alongside dozens of other hacked services</a>. The breach impacted 2.6M users of the service and included email and IP addresses, usernames and salted MD5 password hashes.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[GSMHosting breach Free Download Link](https://tinyurl.com/2b2k277t)