# EpicBot database leak

## Description

2019-09-01

In September 2019, the RuneScape bot provider <a href="https://arstechnica.com/information-technology/2019/11/password-data-dumped-online-for-2-2-million-users-of-currency-and-gaming-sites/" target="_blank" rel="noopener">EpicBot suffered a data breach that impacted 817k subscribers</a>. Data from the breach was subsequently shared on a popular hacking forum and included usernames, email and IP addresses and passwords stored as either salted MD5 or bcrypt hashes. EpicBot did not respond when contacted about the incident.

## Breached data

Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[EpicBot breach Free Download Link](https://tinyurl.com/2b2k277t)