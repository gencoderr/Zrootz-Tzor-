# DivXSubTitles database leak

## Description

2010-01-01

In approximately 2010, the now defunct website DivX SubTitles suffered a data breach that exposed 783k user accounts including email addresses, usernames and plain text passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[DivXSubTitles breach Free Download Link](https://tinyurl.com/2b2k277t)