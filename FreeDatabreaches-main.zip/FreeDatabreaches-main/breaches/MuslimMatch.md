# MuslimMatch database leak

## Description

2016-06-24

In June 2016, <a href="https://motherboard.vice.com/read/hacked-private-messages-from-dating-site-muslim-match" target="_blank" rel="noopener">the Muslim Match dating website had 150k email addresses exposed</a>. The data included private chats and messages between relationship seekers and numerous other personal attributes including passwords hashed with MD5.

## Breached data

Chat logs, Email addresses, Geographic locations, IP addresses, Passwords, Private messages, User statuses, Usernames

## Free download Link

[MuslimMatch breach Free Download Link](https://tinyurl.com/2b2k277t)