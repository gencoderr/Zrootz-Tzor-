# Facepunch database leak

## Description

2016-06-03

In June 2016, the game development studio <a href="https://facepunch.com/" target="_blank" rel="noopener">Facepunch</a> suffered a data breach that exposed 343k users. The breached data included usernames, email and IP addresses, dates of birth and salted MD5 password hashes. Facepunch advised they were aware of the incident and had notified people at the time. The data was provided to HIBP by whitehat security researcher and data analyst Adam Davies.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[Facepunch breach Free Download Link](https://tinyurl.com/2b2k277t)