# Knuddels database leak

## Description

2018-09-05

In September 2018, the German social media website <a href="https://forum.knuddels.de/ubbthreads.php?ubb=showflat&Number=2916081" target="_blank" rel="noopener">Knuddels suffered a data breach</a>. The incident exposed 808k unique email addresses alongside usernames, real names, the city of the person and their password in plain text. Knuddels was <a href="https://blog.avira.com/german-flirting-network-gets-fined-20000e-for-leaking-user-information/" target="_blank" rel="noopener">subsequently fined €20k for the breach</a>.

## Breached data

Email addresses, Geographic locations, Names, Passwords, Usernames

## Free download Link

[Knuddels breach Free Download Link](https://tinyurl.com/2b2k277t)