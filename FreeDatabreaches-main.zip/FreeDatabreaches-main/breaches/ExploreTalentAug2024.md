# ExploreTalentAug2024 database leak

## Description

2024-08-15

In August 2024, <a href="https://maia.crimew.gay/posts/gps-track-deez-nuts/" target="_blank" rel="noopener">a slew of security vulnerabilities were identified with a conglomerate of online services which included the talent network Explore Talent</a>. A vulnerable API exposed the personal records of 11.4M users of the service of which 8.9M unique email addresses were provided to HIBP. This incident is separate to the Explore Talent breach which occurred in 2022 and was loaded into HIBP in July 2024.

## Breached data

Email addresses

## Free download Link

[ExploreTalentAug2024 breach Free Download Link](https://tinyurl.com/2b2k277t)