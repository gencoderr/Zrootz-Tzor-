# ECB database leak

## Description

2024-03-23

In March 2024, <a href="https://www.thecricketer.com/Topics/grassroots/ecb_issue_warning_to_users_of_online_coaching_platform_following_data_breach.html" target="_blank" rel="noopener">English Cricket's icoachcricket website suffered a data breach that exposed over 40k records</a>. The data included email addresses and passwords stored as either bcrypt hashes, salted MD5 hashes or both. The data was provided to HIBP by a source who requested it be attributed to &quot;IntelBroker&quot;.

## Breached data

Email addresses, Passwords

## Free download Link

[ECB breach Free Download Link](https://tinyurl.com/2b2k277t)