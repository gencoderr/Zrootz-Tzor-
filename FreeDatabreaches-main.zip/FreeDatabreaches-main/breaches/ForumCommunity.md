# ForumCommunity database leak

## Description

2016-06-01

In approximately mid-2016, the Italian-based service for creating forums known as <a href="https://www.forumcommunity.net/" target="_blank" rel="noopener">ForumCommunity</a> suffered a data breach. The incident impacted over 776k unique email addresses along with usernames and unsalted MD5 password hashes. No response was received from ForumCommunity when contacted.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[ForumCommunity breach Free Download Link](https://tinyurl.com/2b2k277t)