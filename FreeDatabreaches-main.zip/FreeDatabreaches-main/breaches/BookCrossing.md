# BookCrossing database leak

## Description

2012-11-05

In August 2022, the book social networking site <a href="https://www.bookcrossing.com/forum/9/584194" target="_blank" rel="noopener">BookCrossing disclosed a data breach that dated back to a database backup from November 2012</a>. The incident exposed almost 1.6M records including names, usernames, email and IP addresses, dates of birth and plain text passwords.

## Breached data

Dates of birth, Email addresses, Geographic locations, IP addresses, Names, Passwords, Usernames

## Free download Link

[BookCrossing breach Free Download Link](https://tinyurl.com/2b2k277t)