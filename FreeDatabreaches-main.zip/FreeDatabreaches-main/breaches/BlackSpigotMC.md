# BlackSpigotMC database leak

## Description

2019-07-14

In July 2019, the hacking website <a href="https://blackspigot.com/" target="_blank" rel="noopener">BlackSpigotMC suffered a data breach</a>. The XenForo forum based site was allegedly compromised by a rival hacking website and resulted in 8.5GB of data being leaked including the database and website itself. The exposed data included 140k unique email addresses, usernames, IP addresses, genders, geographic locations and passwords stored as bcrypt hashes.

## Breached data

Device information, Email addresses, Genders, Geographic locations, IP addresses, Passwords, Usernames

## Free download Link

[BlackSpigotMC breach Free Download Link](https://tinyurl.com/2b2k277t)