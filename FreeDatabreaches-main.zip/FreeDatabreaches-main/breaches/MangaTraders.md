# MangaTraders database leak

## Description

2014-06-09

In June 2014, the Manga trading website <a href="http://www.mangatraders.com" target="_blank" rel="noopener">Mangatraders.com</a> had the usernames and passwords of over 900k users <a href="http://boards.4chan.org/a/thread/108603065/mangatraders-has-been-hacked-emails-and-passwords" target="_blank" rel="noopener">leaked on the internet</a> (approximately 855k of the emails were unique). The passwords were weakly hashed with a single iteration of MD5 leaving them vulnerable to being easily cracked.

## Breached data

Email addresses, Passwords

## Free download Link

[MangaTraders breach Free Download Link](https://tinyurl.com/2b2k277t)