# GunsDotCom database leak

## Description

2021-01-12

In January 2021, the firearms website <a href="https://gizmodo.com/guns-com-gets-hacked-spilling-gun-owner-information-al-1846544734" target="_blank" rel="noopener">guns.com suffered a data breach</a>. The breach exposed 376k unique email addresses along with names, phone numbers, physical addresses, gun purchases, partial credit card data, dates of birth and passwords stored as bcrypt hashes.

## Breached data

Dates of birth, Email addresses, Names, Partial credit card data, Passwords, Phone numbers, Physical addresses, Purchases

## Free download Link

[GunsDotCom breach Free Download Link](https://tinyurl.com/2b2k277t)