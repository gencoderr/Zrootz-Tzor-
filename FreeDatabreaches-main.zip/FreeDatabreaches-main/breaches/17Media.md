# 17Media database leak

## Description

2016-04-19

In April 2016, customer data obtained from the streaming app known as &quot;17&quot; <a href="http://motherboard.vice.com/read/another-day-another-hack-millions-of-user-accounts-for-streaming-app-17" target="_blank" rel="noopener">appeared listed for sale on a Tor hidden service marketplace</a>. The data contained over 4 million unique email addresses along with IP addresses, usernames and passwords stored as unsalted MD5 hashes.

## Breached data

Device information, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[17Media breach Free Download Link](https://tinyurl.com/2b2k277t)