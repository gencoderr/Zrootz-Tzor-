# Chatbooks database leak

## Description

2020-03-26

In March 2020, the photo print service <a href="https://www.bleepingcomputer.com/news/security/chatbooks-discloses-data-breach-after-data-sold-on-dark-web/" target="_blank" rel="noopener">Chatbooks suffered a data breach</a> which was subsequently put up for sale on a dark web marketplace. The breach contained 15 million user records with 2.5 million unique email addresses alongside names, phone numbers, social media profiles and salted SHA-512 password hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Social media profiles

## Free download Link

[Chatbooks breach Free Download Link](https://tinyurl.com/2b2k277t)