# JDGroup database leak

## Description

2023-05-31

In May 2023, the South African retailer <a href="https://mybroadband.co.za/news/security/494239-half-a-million-customers-hit-by-incredible-hifi-corp-and-everyshop-data-breach.html" target="_blank" rel="noopener">JD Group announced a data breach affecting a number of their online assets</a> including Bradlows, Everyshop, HiFi Corp, Incredible (Connection), Rochester, Russells, and Sleepmasters. The breach exposed over 520k unique customer records including names, email and physical addresses, phone numbers and South African ID numbers.

## Breached data

Email addresses, Government issued IDs, Names, Phone numbers, Physical addresses

## Free download Link

[JDGroup breach Free Download Link](https://tinyurl.com/2b2k277t)