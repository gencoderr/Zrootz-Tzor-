# FacebookMarketplace database leak

## Description

2023-10-01

In February 2024, <a href="https://www.bleepingcomputer.com/news/security/200-000-facebook-marketplace-user-records-leaked-on-hacking-forum/" target="_blank" rel="noopener">200k Facebook Marketplace records allegedly obtained from a Meta contractor in October 2023 were posted to a popular hacking forum</a>. The data contained 77k unique email addresses alongside names, phone numbers, Facebook profile IDs and geographic locations. The data also contained bcrypt password hashes, although there is no indication these belong to the corresponding Facebook accounts.

## Breached data

Email addresses, Geographic locations, Names, Passwords, Phone numbers, Social media profiles

## Free download Link

[FacebookMarketplace breach Free Download Link](https://tinyurl.com/2b2k277t)