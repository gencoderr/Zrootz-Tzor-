# Dominos database leak

## Description

2014-06-13

In June 2014, <a href="http://www.welivesecurity.com/2014/06/16/dominos-pizza-hacked/" target="_blank" rel="noopener">Domino's Pizza in France and Belgium was hacked</a> by a group going by the name &quot;Rex Mundi&quot; and their customer data held to ransom. Domino's refused to pay the ransom and six months later, the attackers <a href="http://cyberintelligence.in/rex-mundi-hackers-leaked-data-dominos-accord-easypay/" target="_blank" rel="noopener">released the data</a> along with troves of other hacked accounts. Amongst the customer data was passwords stored with a weak MD5 hashing algorithm and no salt.

## Breached data

Email addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[Dominos breach Free Download Link](https://tinyurl.com/2b2k277t)