# Drizly database leak

## Description

2020-07-02

In approximately July 2020, the US-based online alcohol delivery service <a href="https://techcrunch.com/2020/07/28/drizly-data-breach/" target="_blank" rel="noopener">Drizly suffered a data breach</a>. The data was sold online before being extensively redistributed and contained 2.5 million unique email addresses alongside names, physical and IP addresses, phone numbers, dates of birth and passwords stored as bcrypt hashes. The data was provided to HIBP by <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Device information, Email addresses, IP addresses, Names, Passwords, Phone numbers, Physical addresses

## Free download Link

[Drizly breach Free Download Link](https://tinyurl.com/2b2k277t)