# FlashFlashRevolution2019 database leak

## Description

2019-07-16

In July 2019, the music-based rhythm game <a href="http://www.flashflashrevolution.com/" target="_blank" rel="noopener">Flash Flash Revolution</a> suffered a data breach. The 2019 breach imapcted almost 1.9 million members and is <em>in addition to</em> <a href="http://www.flashflashrevolution.com/ffr/information-breach/" target="_blank" rel="noopener">the 2016 data breach of the same service</a>. Email and IP addesses, usernames, dates of birth and salted MD5 hashes were all exposed in the breach. The data was provided with support from <a href="https://dehashed.com/" target="_blank" rel="noopener">dehashed.com</a>.

## Breached data

Dates of birth, Email addresses, IP addresses, Passwords, Usernames

## Free download Link

[FlashFlashRevolution2019 breach Free Download Link](https://tinyurl.com/2b2k277t)