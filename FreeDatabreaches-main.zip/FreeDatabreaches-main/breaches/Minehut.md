# Minehut database leak

## Description

2019-05-17

In May 2019, the Minecraft server website <a href="https://minehut.com/" target="_blank" rel="noopener">Minehut</a> suffered a data breach. The company advised a database backup had been obtained after which they subsequently notified all impacted users. 397k email addresses from the incident were provided to HIBP. A data set with both email addresses and bcrypt password hashes was also later provided to HIBP.

## Breached data

Email addresses, Passwords

## Free download Link

[Minehut breach Free Download Link](https://tinyurl.com/2b2k277t)