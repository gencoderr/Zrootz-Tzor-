# Interpals database leak

## Description

2015-11-04

In late 2015, the online penpal site InterPals had their website hacked and 3.4 million accounts exposed. The compromised data included email addresses, geographical locations, birthdates and salted hashes of passwords.

## Breached data

Dates of birth, Email addresses, Geographic locations, Names, Passwords, Usernames

## Free download Link

[Interpals breach Free Download Link](https://tinyurl.com/2b2k277t)